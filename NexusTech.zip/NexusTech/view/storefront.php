<?php
declare(strict_types=1);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#08111e">
    <link rel="manifest" href="<?= e(app_url('manifest.webmanifest')) ?>">
    <title>NexusTech · Tecnologia em movimento</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css?v=liquid-glass-2')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/app.css?v=liquid-glass-2')) ?>">
    <script type="module" src="<?= e(app_url('assets/js/main.js')) ?>"></script>
</head>
<body data-base-path="<?= e(base_path()) ?>">
    <?php require __DIR__ . '/partials/store-navbar.php'; ?>
    <main id="main-content" tabindex="-1">
        <section class="hero" id="hero" aria-labelledby="hero-title">
            <p class="eyebrow">TECNOLOGIA · SELEÇÃO 2026</p>
            <h1 id="hero-title">O próximo nível<br>começa <em>aqui.</em></h1>
            <p class="hero-copy">Hardware pensado para quem constrói, cria e joga sem limites.</p>
            <a class="button button-primary" href="#catalogo">Explorar produtos <span aria-hidden="true">↗</span></a>
            <div class="hero-index"><span>01</span><span class="index-rule"></span><span>03</span></div>
        </section>
        <section class="catalog" id="catalogo" aria-labelledby="catalog-title">
            <div class="section-heading"><div><p class="eyebrow">CURADORIA NEXUS</p><h2 id="catalog-title">Escolha seu próximo upgrade</h2><p class="muted">Catálogo acadêmico: todos os produtos, preços e avaliações de demonstração são fictícios.</p></div><p data-catalog-status>Carregando catálogo...</p></div>
            <div class="catalog-tools"><input class="field" type="search" placeholder="Buscar por produto ou SKU" aria-label="Buscar produtos" data-search><select class="select-field" aria-label="Filtrar categoria" data-category><option value="">Todas as categorias</option></select><input class="field" type="number" min="0" step="0.01" placeholder="Preço mín." aria-label="Preço mínimo" data-min><input class="field" type="number" min="0" step="0.01" placeholder="Preço máx." aria-label="Preço máximo" data-max><label class="availability-filter"><input type="checkbox" data-available> Em estoque</label><select class="select-field" aria-label="Ordenar produtos" data-sort><option value="recentes-desc">Mais recentes</option><option value="preco-asc">Menor preço</option><option value="preco-desc">Maior preço</option><option value="nome-asc">Nome A-Z</option></select></div>
            <div class="product-grid" data-product-grid aria-live="polite"></div>
            <div class="catalog-more"><button class="button-small" type="button" data-load-more hidden>Carregar mais</button></div>
        </section>
    </main>
    <footer><span class="wordmark">NEXUS<span>TECH</span></span><span>Performance, sem ruído.</span></footer>
</body>
</html>