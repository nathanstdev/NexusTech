<?php
declare(strict_types=1);
$productId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT) ?: 0;
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#08111b">
    <title>Produto · NexusTech</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css?v=liquid-glass-2')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/app.css?v=liquid-glass-2')) ?>">
    <script type="module" src="<?= e(app_url('assets/js/product.js')) ?>"></script>
</head>
<body data-base-path="<?= e(base_path()) ?>" data-product-id="<?= (int) $productId ?>">
    <header class="site-header">
        <a class="wordmark" href="<?= e(app_url()) ?>">NEXUS<span>TECH</span></a>
        <nav aria-label="Navegação da loja">
            <a href="<?= e(app_url()) ?>#catalogo">Catálogo</a>
            <a href="<?= e(app_url('conta')) ?>">Conta</a>
        </nav>
        <a class="icon-button" href="<?= e(app_url('checkout')) ?>">Bag <span data-cart-count>0</span></a>
    </header>
    <main class="page-shell">
        <p><a class="muted" href="<?= e(app_url()) ?>">← Voltar ao catálogo</a></p>
        <section class="product-detail-grid" data-product-detail aria-live="polite">
            <div class="empty-state">Carregando produto...</div>
        </section>
        <section class="admin-section panel review-section" aria-labelledby="reviews-title">
            <div class="chart-actions">
                <div>
                    <p class="eyebrow">EXPERIÊNCIA NEXUS</p>
                    <h2 id="reviews-title">Avaliações</h2>
                </div>
                <p class="review-summary" data-review-summary aria-live="polite">Carregando avaliações...</p>
            </div>
            <p class="muted">Avaliações demonstrativas são fictícias e estão identificadas como exemplos; avaliações de clientes só podem ser enviadas após a entrega de um pedido.</p>
            <div class="review-list" data-review-list aria-live="polite"></div>
            <form class="review-form" data-review-form>
                <h3>Avalie este produto</h3>
                <p class="muted">Avaliações ficam disponíveis após a entrega do pedido.</p>
                <label>Nota
                    <select class="select-field" name="estrelas" required>
                        <option value="5">5 — Excelente</option>
                        <option value="4">4 — Muito bom</option>
                        <option value="3">3 — Bom</option>
                        <option value="2">2 — Regular</option>
                        <option value="1">1 — Ruim</option>
                    </select>
                </label>
                <label>Comentário
                    <textarea class="field" name="comentario" rows="4" maxlength="1500" placeholder="Compartilhe sua experiência"></textarea>
                </label>
                <p class="form-message" data-review-message aria-live="polite"></p>
                <button class="button-small" type="submit">Enviar avaliação</button>
            </form>
        </section>
        <section class="admin-section" aria-labelledby="related-title">
            <p class="eyebrow">VOCÊ TAMBÉM PODE GOSTAR</p>
            <h2 id="related-title">Produtos relacionados</h2>
            <div class="product-grid" data-related></div>
        </section>
    </main>
</body>
</html>
