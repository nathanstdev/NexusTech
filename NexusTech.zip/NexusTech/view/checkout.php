<?php
declare(strict_types=1);
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#08111b">
    <title>Checkout · NexusTech</title>
    <link rel="stylesheet" href="<?= e(app_url('assets/css/style.css?v=liquid-glass-2')) ?>">
    <link rel="stylesheet" href="<?= e(app_url('assets/css/app.css?v=liquid-glass-2')) ?>">
    <script type="module" src="<?= e(app_url('assets/js/checkout.js')) ?>"></script>
</head>
<body data-base-path="<?= e(base_path()) ?>">
    <header class="site-header">
        <a class="wordmark" href="<?= e(app_url()) ?>">NEXUS<span>TECH</span></a>
        <a class="icon-button" href="<?= e(app_url()) ?>">Continuar comprando</a>
    </header>
    <main class="page-shell">
        <header class="page-title">
            <div>
                <p class="eyebrow">FINALIZAÇÃO SEGURA</p>
                <h1>Seu pedido</h1>
                <p class="muted">Checkout em etapas · pagamentos em modo de demonstração.</p>
            </div>
        </header>
        <ol class="checkout-progress" aria-label="Etapas do checkout">
            <li data-step-indicator="1" aria-current="step"><span>1</span> Entrega</li>
            <li data-step-indicator="2"><span>2</span> Pagamento</li>
            <li data-step-indicator="3"><span>3</span> Revisão</li>
        </ol>
        <div class="checkout-layout">
            <section class="panel checkout-panel">
                <form class="form-stack" data-checkout-form>
                    <section data-checkout-step="1" aria-labelledby="delivery-title">
                        <h2 id="delivery-title" tabindex="-1">Endereço de entrega</h2>
                        <label>Usar endereço salvo
                            <select class="select-field saved-address-select" data-saved-address>
                                <option value="">Novo endereço</option>
                            </select>
                        </label>
                        <div class="checkout-fields">
                            <label>Destinatário<input class="field" name="destinatario" required maxlength="120" autocomplete="name"></label>
                            <label>CEP<input class="field" name="cep" required inputmode="numeric" pattern="\d{5}-?\d{3}" placeholder="00000-000" autocomplete="postal-code"></label>
                            <label class="checkout-field-wide">Rua<input class="field" name="logradouro" required maxlength="180" autocomplete="street-address"></label>
                            <label>Número<input class="field" name="numero" required maxlength="20"></label>
                            <label>Complemento<input class="field" name="complemento" maxlength="100"></label>
                            <label>Bairro<input class="field" name="bairro" required maxlength="100"></label>
                            <label>Cidade<input class="field" name="cidade" required maxlength="100" autocomplete="address-level2"></label>
                            <label>Estado (UF)<input class="field" name="estado" required minlength="2" maxlength="2" autocomplete="address-level1"></label>
                        </div>
                        <button class="button button-primary checkout-next" type="button" data-step-next="2">Continuar para pagamento</button>
                    </section>
                    <section data-checkout-step="2" aria-labelledby="payment-title" hidden>
                        <h2 id="payment-title" tabindex="-1">Forma de pagamento</h2>
                        <p class="muted">Esta instalação não processa pagamentos reais. Nenhum dado de cartão é solicitado.</p>
                        <label>Forma de pagamento
                            <select class="select-field" name="pagamento" required>
                                <option value="pix">Pix (simulado)</option>
                                <option value="cartao">Cartão (simulado)</option>
                                <option value="boleto">Boleto (simulado)</option>
                            </select>
                        </label>
                        <div class="checkout-navigation">
                            <button class="button-small" type="button" data-step-back="1">Voltar ao endereço</button>
                            <button class="button button-primary" type="button" data-step-next="3">Revisar pedido</button>
                        </div>
                    </section>
                    <section data-checkout-step="3" aria-labelledby="review-title" hidden>
                        <h2 id="review-title" tabindex="-1">Revise antes de confirmar</h2>
                        <dl class="checkout-review">
                            <div><dt>Entrega</dt><dd data-review-address>—</dd></div>
                            <div><dt>Pagamento</dt><dd data-review-payment>—</dd></div>
                        </dl>
                        <p class="muted">O pedido e o estoque serão atualizados apenas após a confirmação.</p>
                        <p class="form-message" data-checkout-message aria-live="polite"></p>
                        <div class="checkout-navigation">
                            <button class="button-small" type="button" data-step-back="2">Voltar ao pagamento</button>
                            <button class="button button-primary" type="submit">Confirmar pedido</button>
                        </div>
                    </section>
                </form>
            </section>
            <aside class="panel checkout-summary" aria-labelledby="summary-title">
                <h2 id="summary-title">Resumo do pedido</h2>
                <div data-checkout-items></div>
                <p class="form-message" data-cart-message aria-live="polite"></p>
                <p class="muted" data-address-message aria-live="polite"></p>
                <div class="coupon-entry">
                    <label for="checkout-coupon">Cupom</label>
                    <div class="coupon-controls">
                        <input class="field" id="checkout-coupon" data-coupon placeholder="NEXUS10">
                        <button class="button-small" type="button" data-apply-coupon>Aplicar</button>
                    </div>
                    <p class="muted" data-coupon-message aria-live="polite"></p>
                </div>
                <dl class="checkout-totals">
                    <div><dt>Subtotal</dt><dd data-subtotal>—</dd></div>
                    <div><dt>Frete simulado</dt><dd data-shipping>—</dd></div>
                    <div><dt>Desconto</dt><dd data-discount>R$ 0,00</dd></div>
                    <div class="checkout-grand-total"><dt>Total</dt><dd data-total>—</dd></div>
                </dl>
            </aside>
        </div>
    </main>
</body>
</html>
