<?php
declare(strict_types=1);
?>
<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Não encontrado · NexusTech</title><link rel="stylesheet" href="<?= e(app_url('assets/css/style.css?v=liquid-glass-2')) ?>"><link rel="stylesheet" href="<?= e(app_url('assets/css/app.css?v=liquid-glass-2')) ?>"><main class="auth-shell"><section class="auth-panel"><p class="eyebrow">NEXUS / 404</p><h1>Produto não encontrado</h1><a class="button button-primary" href="<?= e(app_url()) ?>">Voltar à loja</a></section></main></html>