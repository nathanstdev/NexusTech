<?php
declare(strict_types=1);

$navbarPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$navbarBase = base_path();
if ($navbarBase !== '' && strcasecmp(substr($navbarPath, 0, strlen($navbarBase)), $navbarBase) === 0) {
    $navbarPath = substr($navbarPath, strlen($navbarBase)) ?: '/';
}
$navbarPath = trim($navbarPath, '/');
$catalogIsCurrent = $navbarPath === '' || str_starts_with($navbarPath, 'produto/');
$navbarUser = $_SESSION['user'] ?? null;
$navbarAuthenticated = is_array($navbarUser) && isset($navbarUser['id']);
$navbarIsAdmin = $navbarAuthenticated && ($navbarUser['role'] ?? null) === 'admin';
?>
<a class="skip-link" href="#main-content">Pular para o conteúdo</a>
<header class="site-header store-navbar" data-site-header>
    <div class="navbar-inner">
        <a class="wordmark navbar-brand" href="<?= e(app_url()) ?>" aria-label="NexusTech início">NEXUS<span>TECH</span></a>
        <nav class="primary-nav" id="store-navigation" aria-label="Navegação principal" data-primary-nav>
            <span class="nav-pill" data-nav-pill aria-hidden="true"></span>
            <a class="nav-link" href="<?= e(app_url()) ?>#catalogo" data-nav-link <?= $catalogIsCurrent ? 'aria-current="page"' : '' ?>>Catálogo</a>
            <a class="nav-link" href="<?= e(app_url('meus-pedidos')) ?>" data-nav-link <?= $navbarPath === 'meus-pedidos' ? 'aria-current="page"' : '' ?>>Pedidos</a>
            <a class="nav-link" href="<?= e(app_url('conta')) ?>" data-nav-link <?= $navbarPath === 'conta' ? 'aria-current="page"' : '' ?>>Conta</a>
            <?php if ($navbarIsAdmin): ?>
                <a class="nav-link" href="<?= e(app_url('admin')) ?>" data-nav-link>Painel ERP</a>
            <?php elseif (!$navbarAuthenticated): ?>
                <a class="nav-link" href="<?= e(app_url('login')) ?>" data-nav-link <?= in_array($navbarPath, ['login', 'cadastro'], true) ? 'aria-current="page"' : '' ?>>Entrar</a>
            <?php endif; ?>
        </nav>
        <button class="menu-toggle" type="button" aria-label="Abrir menu" aria-expanded="false" aria-controls="store-navigation" data-menu-toggle>
            <span aria-hidden="true"></span><span aria-hidden="true"></span><span aria-hidden="true"></span>
        </button>
        <div class="navbar-actions">
            <button class="theme-toggle" type="button" data-theme-toggle aria-pressed="false" aria-label="Alternar tema. Atalho: T.">
                <span class="theme-icon" data-theme-icon aria-hidden="true">☼</span><span data-theme-label>Tema claro</span>
            </button>
            <a class="bag-link" href="<?= e(app_url('checkout')) ?>" aria-label="Sacola de compras, 0 itens" data-bag-link>
                <span>Bag</span><span class="bag-count" data-cart-count aria-hidden="true">0</span>
            </a>
        </div>
    </div>
    <div class="reading-progress" aria-hidden="true"><span data-reading-progress></span></div>
</header>
