<?php
declare(strict_types=1);

use App\Api\Response;
use App\Database;
use App\Middleware\AuthMiddleware;
use App\Services\RelatorioService;

AuthMiddleware::user('admin');
$autoload = dirname(__DIR__) . '/vendor/autoload.php';
if (!is_file($autoload)) {
    Response::error('Instale as dependências do projeto com Composer para gerar o PDF.', 503);
}
require_once $autoload;
$optionsClass = '\\Dompdf\\Options';
$pdfClass = '\\Dompdf\\Dompdf';
if (!class_exists($optionsClass) || !class_exists($pdfClass)) {
    Response::error('Dependência Dompdf indisponível. Execute composer install.', 503);
}

$db = Database::connection();
$orderId = filter_var($_GET['pedido'] ?? null, FILTER_VALIDATE_INT);
if ($orderId) {
    $query = $db->prepare('SELECT o.id, o.status, o.total, o.frete, o.desconto, o.metodo_pagamento, o.endereco_entrega, o.created_at, u.nome AS cliente, u.email FROM pedidos o JOIN usuarios u ON u.id = o.usuario_id WHERE o.id = :id');
    $query->execute(['id' => $orderId]);
    $order = $query->fetch();
    if (!$order) {
        Response::error('Pedido não encontrado.', 404);
    }
    $itemsQuery = $db->prepare('SELECT i.quantidade, i.preco_unitario, p.nome FROM itens_pedido i JOIN produtos p ON p.id = i.produto_id WHERE i.pedido_id = :id');
    $itemsQuery->execute(['id' => $orderId]);
    $items = '';
    foreach ($itemsQuery->fetchAll() as $item) {
        $items .= '<tr><td>' . e((string) $item['nome']) . '</td><td>' . (int) $item['quantidade'] . '</td><td>' . e(number_format((float) $item['preco_unitario'], 2, ',', '.')) . '</td></tr>';
    }
    $address = json_decode((string) $order['endereco_entrega'], true) ?: [];
    $addressText = implode(', ', array_filter([$address['logradouro'] ?? '', $address['numero'] ?? '', $address['bairro'] ?? '', $address['cidade'] ?? '', $address['estado'] ?? '', $address['cep'] ?? '']));
    $html = '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><style>body{font-family:DejaVu Sans,sans-serif;color:#15242b;font-size:11px}h1{font-size:22px}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{text-align:left;padding:8px;border-bottom:1px solid #ced8da}th{background:#eff5f4}.total{text-align:right;font-size:16px;margin-top:18px}</style><h1>NexusTech · Pedido #' . (int) $order['id'] . '</h1><p>Cliente: ' . e((string) $order['cliente']) . ' · ' . e((string) $order['email']) . '</p><p>Status: ' . e((string) $order['status']) . ' · Pagamento: ' . e((string) $order['metodo_pagamento']) . ' · Data: ' . e((new DateTimeImmutable((string) $order['created_at']))->format('d/m/Y H:i')) . '</p><p>Entrega: ' . e($addressText) . '</p><table><thead><tr><th>Produto</th><th>Quantidade</th><th>Preço unitário</th></tr></thead><tbody>' . $items . '</tbody></table><p>Frete: R$ ' . e(number_format((float) $order['frete'], 2, ',', '.')) . ' · Desconto: R$ ' . e(number_format((float) $order['desconto'], 2, ',', '.')) . '</p><p class="total">Total: R$ ' . e(number_format((float) $order['total'], 2, ',', '.')) . '</p></html>';
    $options = new $optionsClass();
    $options->set('isRemoteEnabled', false);
    $options->set('defaultFont', 'DejaVu Sans');
    $pdf = new $pdfClass($options);
    $pdf->loadHtml($html, 'UTF-8');
    $pdf->setPaper('A4', 'portrait');
    $pdf->render();
    $pdf->stream('pedido-' . $orderId . '-nexustech.pdf', ['Attachment' => true]);
    exit;
}

$report = (new RelatorioService($db))->dashboard(30);
$renderTable = static function (array $rows, array $columns): string {
    $html = '<table><thead><tr>';
    foreach ($columns as $label => $key) {
        $html .= '<th>' . e($label) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($rows as $row) {
        $html .= '<tr>';
        foreach ($columns as $key) {
            $value = $row[$key] ?? '';
            $html .= '<td>' . e(is_scalar($value) ? (string) $value : '') . '</td>';
        }
        $html .= '</tr>';
    }
    return $html . '</tbody></table>';
};
$heatRows = array_map(static function (array $row): array {
    $days = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];
    $row['dia_nome'] = $days[(int) $row['dia_semana']] ?? '—';
    return $row;
}, $report['calor']);
$sections = [
    ['Produtos mais vendidos', $renderTable($report['mais_vendidos'], ['Produto' => 'nome', 'Unidades' => 'quantidade'])],
    ['Vendas por dia', $renderTable($report['vendas'], ['Data' => 'dia', 'Faturamento' => 'valor'])],
    ['Faturamento por categoria', $renderTable($report['categorias'], ['Categoria' => 'nome', 'Faturamento' => 'valor'])],
    ['Entradas e saídas de estoque', $renderTable($report['estoque'], ['Data' => 'dia', 'Entradas' => 'entradas', 'Saídas' => 'saidas'])],
    ['Lucro estimado por dia', $renderTable($report['lucro'], ['Data' => 'dia', 'Lucro estimado' => 'lucro'])],
    ['Curva ABC', $renderTable($report['curva_abc'], ['Produto' => 'nome', 'Receita' => 'receita', 'Unidades' => 'unidades', 'Classe' => 'classe'])],
    ['Giro de estoque', $renderTable($report['giro'], ['Produto' => 'nome', 'Estoque atual' => 'estoque', 'Unidades vendidas' => 'vendidos', 'Giro' => 'giro'])],
    ['Vendas por dia da semana e hora', $renderTable($heatRows, ['Dia' => 'dia_nome', 'Hora' => 'hora', 'Pedidos' => 'pedidos'])],
];
$sectionsHtml = '';
foreach ($sections as [$title, $table]) {
    $sectionsHtml .= '<section><h2>' . e($title) . '</h2>' . $table . '</section>';
}
$stagnantNames = array_map(static fn (array $row): string => e((string) $row['nome']), array_slice($report['parados'], 0, 30));
$sectionsHtml .= '<section><h2>Produtos sem venda no período</h2><p>' . ($stagnantNames !== [] ? implode(' · ', $stagnantNames) : 'Nenhum produto parado') . '</p></section>';
$generatedAt = e((new DateTimeImmutable())->format('d/m/Y H:i'));
$html = '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><style>body{font-family:DejaVu Sans,sans-serif;color:#15242b;font-size:10px}h1{font-size:24px}h2{font-size:15px;margin-top:26px}section{page-break-inside:avoid}.kpis{width:100%;margin:18px 0}.kpis td{padding:12px;background:#e8f3ef}.label{font-size:9px;color:#50666d;text-transform:uppercase}.value{font-size:17px;font-weight:bold}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:7px;border-bottom:1px solid #ced8da}th{background:#eff5f4}footer{margin-top:24px;color:#61757b}</style><h1>NexusTech · Relatório de vendas</h1><p>Período: últimos 30 dias · Gerado em ' . $generatedAt . '</p><table class="kpis"><tr><td><div class="label">Faturamento</div><div class="value">' . e(number_format((float) $report['kpis']['faturamento'], 2, ',', '.')) . '</div></td><td><div class="label">Pedidos</div><div class="value">' . (int) $report['kpis']['pedidos'] . '</div></td><td><div class="label">Ticket médio</div><div class="value">' . e(number_format((float) $report['kpis']['ticket_medio'], 2, ',', '.')) . '</div></td><td><div class="label">Estoque crítico</div><div class="value">' . (int) $report['kpis']['estoque_baixo'] . '</div></td></tr></table>' . $sectionsHtml . '<footer>Documento interno · NexusTech ERP</footer></html>';
$options = new $optionsClass();
$options->set('isRemoteEnabled', false);
$options->set('defaultFont', 'DejaVu Sans');
$pdf = new $pdfClass($options);
$pdf->loadHtml($html, 'UTF-8');
$pdf->setPaper('A4', 'portrait');
$pdf->render();
$pdf->stream('relatorio-nexustech.pdf', ['Attachment' => true]);