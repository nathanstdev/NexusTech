CREATE TABLE IF NOT EXISTS armazens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    descricao VARCHAR(500) NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS estoque_armazens (
    armazem_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (armazem_id, produto_id),
    CONSTRAINT fk_estoque_armazem_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_estoque_armazem_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_estoque_armazem_produto (produto_id, quantidade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lotes_estoque (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    armazem_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    numero_lote VARCHAR(100) NOT NULL,
    serie VARCHAR(120) NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 0,
    validade DATE NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_lote_armazem_produto UNIQUE (armazem_id, produto_id, numero_lote, serie),
    CONSTRAINT fk_lote_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_lote_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_lote_validade (validade, quantidade),
    INDEX idx_lote_produto (produto_id, armazem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transferencias_estoque (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    origem_id BIGINT UNSIGNED NOT NULL,
    destino_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('concluida','cancelada') NOT NULL DEFAULT 'concluida',
    motivo VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transferencia_origem FOREIGN KEY (origem_id) REFERENCES armazens(id),
    CONSTRAINT fk_transferencia_destino FOREIGN KEY (destino_id) REFERENCES armazens(id),
    CONSTRAINT fk_transferencia_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_transferencia_data (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_transferencia (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transferencia_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    lote_id BIGINT UNSIGNED NULL,
    quantidade INT UNSIGNED NOT NULL,
    CONSTRAINT fk_item_transferencia_transferencia FOREIGN KEY (transferencia_id) REFERENCES transferencias_estoque(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_transferencia_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT fk_item_transferencia_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL,
    INDEX idx_item_transferencia_lote (lote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventarios_fisicos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    armazem_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('em_contagem','concluido','cancelado') NOT NULL DEFAULT 'em_contagem',
    observacao VARCHAR(500) NULL,
    iniciado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    concluido_em TIMESTAMP NULL,
    CONSTRAINT fk_inventario_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_inventario_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_inventario_armazem_status (armazem_id, status, iniciado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_inventario_fisico (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventario_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    lote_id BIGINT UNSIGNED NULL,
    quantidade_sistema INT UNSIGNED NOT NULL,
    quantidade_contada INT UNSIGNED NULL,
    contado_em TIMESTAMP NULL,
    CONSTRAINT fk_item_inventario_inventario FOREIGN KEY (inventario_id) REFERENCES inventarios_fisicos(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_inventario_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT fk_item_inventario_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL,
    CONSTRAINT uq_inventario_produto_lote UNIQUE (inventario_id, produto_id, lote_id),
    INDEX idx_item_inventario_produto (produto_id, inventario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contas_financeiras (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('receber','pagar') NOT NULL,
    origem_tipo ENUM('pedido','compra','manual') NOT NULL,
    origem_id BIGINT UNSIGNED NULL,
    descricao VARCHAR(255) NOT NULL,
    contraparte VARCHAR(190) NULL,
    valor DECIMAL(12,2) NOT NULL,
    vencimento DATE NOT NULL,
    pago_em DATETIME NULL,
    status ENUM('aberta','paga','cancelada') NOT NULL DEFAULT 'aberta',
    usuario_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_conta_financeira_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    CONSTRAINT uq_conta_origem_tipo UNIQUE (tipo, origem_tipo, origem_id),
    INDEX idx_conta_financeira_status_vencimento (status, vencimento, tipo),
    INDEX idx_conta_financeira_origem (origem_tipo, origem_id, tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO armazens (nome, codigo, descricao)
VALUES ('Armazém principal', 'PRINCIPAL', 'Armazém inicial criado pela migration de expansão do ERP.');

INSERT IGNORE INTO estoque_armazens (armazem_id, produto_id, quantidade)
SELECT a.id, p.id, p.estoque
FROM armazens a
CROSS JOIN produtos p
WHERE a.codigo = 'PRINCIPAL';

ALTER TABLE movimentacoes_estoque
    ADD COLUMN armazem_id BIGINT UNSIGNED NULL;

ALTER TABLE movimentacoes_estoque
    ADD COLUMN lote_id BIGINT UNSIGNED NULL;

ALTER TABLE movimentacoes_estoque
    ADD CONSTRAINT fk_mov_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id) ON DELETE SET NULL;

ALTER TABLE movimentacoes_estoque
    ADD CONSTRAINT fk_mov_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL;

INSERT IGNORE INTO lotes_estoque (armazem_id, produto_id, numero_lote, quantidade)
SELECT s.armazem_id, s.produto_id, 'SALDO-INICIAL', s.quantidade
FROM estoque_armazens s
WHERE s.quantidade > 0
AND NOT EXISTS (
    SELECT 1 FROM lotes_estoque l
    WHERE l.armazem_id = s.armazem_id
      AND l.produto_id = s.produto_id
      AND l.numero_lote = 'SALDO-INICIAL'
      AND l.serie IS NULL
);

INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, pago_em, status, usuario_id)
SELECT 'pagar', 'compra', c.id, CONCAT('Compra #', c.id), f.nome, c.total, DATE_ADD(DATE(c.created_at), INTERVAL 30 DAY), NULL, 'aberta', c.usuario_id
FROM compras c
JOIN fornecedores f ON f.id = c.fornecedor_id
WHERE c.status = 'recebida'
AND NOT EXISTS (
    SELECT 1 FROM contas_financeiras cf
    WHERE cf.tipo = 'pagar' AND cf.origem_tipo = 'compra' AND cf.origem_id = c.id
);

INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, pago_em, status, usuario_id)
SELECT 'receber', 'pedido', p.id, CONCAT('Pedido #', p.id), u.nome, p.total, DATE(p.created_at),
       CASE WHEN p.status = 'pendente' THEN NULL ELSE p.created_at END,
       CASE WHEN p.status = 'pendente' THEN 'aberta' ELSE 'paga' END,
       p.usuario_id
FROM pedidos p
JOIN usuarios u ON u.id = p.usuario_id
WHERE p.status IN ('pendente', 'pago', 'separado', 'enviado', 'entregue')
AND NOT EXISTS (
    SELECT 1 FROM contas_financeiras cf
    WHERE cf.tipo = 'receber' AND cf.origem_tipo = 'pedido' AND cf.origem_id = p.id
);
