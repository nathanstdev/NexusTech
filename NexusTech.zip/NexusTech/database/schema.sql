-- Schema consolidado das migrations 001 a 005.
-- Execute php tools/migrate.php depois da importação para aplicar a migration 006 e os dados de demonstração.

CREATE TABLE IF NOT EXISTS schema_migrations (
    name VARCHAR(190) PRIMARY KEY,
    applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    role ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    avatar_url VARCHAR(500) NULL,
    auth_version INT UNSIGNED NOT NULL DEFAULT 1,
    INDEX idx_usuarios_role_ativo (role, ativo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categorias (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(120) NOT NULL UNIQUE,
    descricao VARCHAR(500) NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fornecedores (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(160) NOT NULL,
    documento VARCHAR(30) NULL UNIQUE,
    email VARCHAR(190) NULL,
    telefone VARCHAR(30) NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS produtos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    categoria_id BIGINT UNSIGNED NULL,
    fornecedor_id BIGINT UNSIGNED NULL,
    sku VARCHAR(80) NOT NULL UNIQUE,
    codigo_barras VARCHAR(80) NULL UNIQUE,
    nome VARCHAR(180) NOT NULL,
    descricao TEXT NULL,
    imagem_url VARCHAR(500) NULL,
    imagens JSON NULL,
    custo DECIMAL(12,2) NOT NULL DEFAULT 0,
    preco DECIMAL(12,2) NOT NULL,
    estoque INT UNSIGNED NOT NULL DEFAULT 0,
    estoque_minimo INT UNSIGNED NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL,
    CONSTRAINT fk_produtos_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL,
    INDEX idx_produtos_catalogo (ativo, categoria_id, preco),
    INDEX idx_produtos_estoque (estoque, estoque_minimo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pedidos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('pendente','pago','separado','enviado','entregue','cancelado') NOT NULL DEFAULT 'pendente',
    total DECIMAL(12,2) NOT NULL,
    frete DECIMAL(10,2) NOT NULL DEFAULT 0,
    desconto DECIMAL(10,2) NOT NULL DEFAULT 0,
    cupom_codigo VARCHAR(40) NULL,
    metodo_pagamento VARCHAR(30) NOT NULL DEFAULT 'simulado',
    endereco_entrega JSON NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_pedidos_status_data (status, created_at),
    INDEX idx_pedidos_usuario_data (usuario_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_pedido (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pedido_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    preco_unitario DECIMAL(12,2) NOT NULL,
    custo_unitario DECIMAL(12,2) NOT NULL DEFAULT 0,
    CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
    CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_itens_produto (produto_id, pedido_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS compras (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    fornecedor_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('recebida','cancelada') NOT NULL DEFAULT 'recebida',
    nota_fiscal VARCHAR(80) NULL,
    total DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_compras_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id),
    CONSTRAINT fk_compras_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_compras_fornecedor_data (fornecedor_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_compra (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    compra_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    custo_unitario DECIMAL(12,2) NOT NULL,
    CONSTRAINT fk_itens_compra FOREIGN KEY (compra_id) REFERENCES compras(id) ON DELETE CASCADE,
    CONSTRAINT fk_itens_compra_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_itens_compra_produto (produto_id, compra_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS armazens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    descricao VARCHAR(500) NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS estoque_armazens (
    armazem_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (armazem_id, produto_id),
    CONSTRAINT fk_estoque_armazem_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_estoque_armazem_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_estoque_armazem_produto (produto_id, quantidade)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lotes_estoque (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    armazem_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    numero_lote VARCHAR(100) NOT NULL,
    serie VARCHAR(120) NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 0,
    validade DATE NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_lote_armazem_produto UNIQUE (armazem_id, produto_id, numero_lote, serie),
    CONSTRAINT fk_lote_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_lote_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    INDEX idx_lote_validade (validade, quantidade),
    INDEX idx_lote_produto (produto_id, armazem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS movimentacoes_estoque (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    produto_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    tipo ENUM('entrada','saida','ajuste') NOT NULL,
    quantidade INT NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    pedido_id BIGINT UNSIGNED NULL,
    compra_id BIGINT UNSIGNED NULL,
    armazem_id BIGINT UNSIGNED NULL,
    lote_id BIGINT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mov_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    CONSTRAINT fk_mov_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE SET NULL,
    CONSTRAINT fk_mov_compra FOREIGN KEY (compra_id) REFERENCES compras(id) ON DELETE SET NULL,
    CONSTRAINT fk_mov_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id) ON DELETE SET NULL,
    CONSTRAINT fk_mov_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL,
    INDEX idx_mov_produto_data (produto_id, created_at),
    INDEX idx_mov_tipo_data (tipo, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS logs_auditoria (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NULL,
    acao VARCHAR(100) NOT NULL,
    entidade VARCHAR(100) NOT NULL,
    entidade_id BIGINT UNSIGNED NULL,
    detalhes JSON NULL,
    ip VARCHAR(45) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_audit_usuario_data (usuario_id, created_at),
    INDEX idx_audit_entidade (entidade, entidade_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_tentativas (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(190) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_login_rate (email, ip, created_at),
    INDEX idx_login_rate_ip (ip, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS enderecos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    apelido VARCHAR(60) NOT NULL DEFAULT 'Principal',
    destinatario VARCHAR(120) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(180) NOT NULL,
    numero VARCHAR(20) NOT NULL,
    complemento VARCHAR(100) NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado CHAR(2) NOT NULL,
    principal TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_enderecos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_enderecos_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE enderecos address
JOIN (
    SELECT usuario_id, MIN(id) AS id
    FROM enderecos
    GROUP BY usuario_id
) first_address ON first_address.id = address.id
SET address.principal = 1;

CREATE TABLE IF NOT EXISTS cupons (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    tipo ENUM('percentual','fixo') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    minimo_pedido DECIMAL(12,2) NOT NULL DEFAULT 0,
    usos_maximos INT UNSIGNED NULL,
    usos INT UNSIGNED NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    expira_em DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_cupons_validade (ativo, expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expira_em DATETIME NOT NULL,
    usado_em DATETIME NULL,
    CONSTRAINT fk_reset_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_reset_validade (expira_em, usado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhook_eventos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    evento_id VARCHAR(120) NOT NULL UNIQUE,
    recebido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processado_em TIMESTAMP NULL,
    INDEX idx_webhook_recebido (recebido_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transferencias_estoque (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    origem_id BIGINT UNSIGNED NOT NULL,
    destino_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('concluida','cancelada') NOT NULL DEFAULT 'concluida',
    motivo VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transferencia_origem FOREIGN KEY (origem_id) REFERENCES armazens(id),
    CONSTRAINT fk_transferencia_destino FOREIGN KEY (destino_id) REFERENCES armazens(id),
    CONSTRAINT fk_transferencia_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_transferencia_data (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_transferencia (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    transferencia_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    lote_id BIGINT UNSIGNED NULL,
    quantidade INT UNSIGNED NOT NULL,
    CONSTRAINT fk_item_transferencia_transferencia FOREIGN KEY (transferencia_id) REFERENCES transferencias_estoque(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_transferencia_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT fk_item_transferencia_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL,
    INDEX idx_item_transferencia_lote (lote_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventarios_fisicos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    armazem_id BIGINT UNSIGNED NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    status ENUM('em_contagem','concluido','cancelado') NOT NULL DEFAULT 'em_contagem',
    observacao VARCHAR(500) NULL,
    iniciado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    concluido_em TIMESTAMP NULL,
    CONSTRAINT fk_inventario_armazem FOREIGN KEY (armazem_id) REFERENCES armazens(id),
    CONSTRAINT fk_inventario_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_inventario_armazem_status (armazem_id, status, iniciado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_inventario_fisico (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventario_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    lote_id BIGINT UNSIGNED NULL,
    quantidade_sistema INT UNSIGNED NOT NULL,
    quantidade_contada INT UNSIGNED NULL,
    contado_em TIMESTAMP NULL,
    CONSTRAINT fk_item_inventario_inventario FOREIGN KEY (inventario_id) REFERENCES inventarios_fisicos(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_inventario_produto FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT fk_item_inventario_lote FOREIGN KEY (lote_id) REFERENCES lotes_estoque(id) ON DELETE SET NULL,
    CONSTRAINT uq_inventario_produto_lote UNIQUE (inventario_id, produto_id, lote_id),
    INDEX idx_item_inventario_produto (produto_id, inventario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS contas_financeiras (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('receber','pagar') NOT NULL,
    origem_tipo ENUM('pedido','compra','manual') NOT NULL,
    origem_id BIGINT UNSIGNED NULL,
    descricao VARCHAR(255) NOT NULL,
    contraparte VARCHAR(190) NULL,
    valor DECIMAL(12,2) NOT NULL,
    vencimento DATE NOT NULL,
    pago_em DATETIME NULL,
    status ENUM('aberta','paga','cancelada') NOT NULL DEFAULT 'aberta',
    usuario_id BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_conta_financeira_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    CONSTRAINT uq_conta_origem_tipo UNIQUE (tipo, origem_tipo, origem_id),
    INDEX idx_conta_financeira_status_vencimento (status, vencimento, tipo),
    INDEX idx_conta_financeira_origem (origem_tipo, origem_id, tipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO categorias (nome, slug, descricao) VALUES
('Computadores', 'computadores', 'Desktops e notebooks de alto desempenho'),
('Periféricos', 'perifericos', 'Equipamentos para seu setup'),
('Componentes', 'componentes', 'Peças para montar e atualizar');

INSERT IGNORE INTO fornecedores (id, nome, email) VALUES
(1, 'NexusTech Distribuição', 'compras@nexustech.local');

INSERT IGNORE INTO produtos (categoria_id, fornecedor_id, sku, nome, descricao, custo, preco, estoque, estoque_minimo, imagem_url) VALUES
(1, 1, 'NT-PC-001', 'Nexus Pro Creator', 'Workstation compacta para criação e desenvolvimento.', 3800.00, 5299.90, 18, 5, 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=900&q=80'),
(2, 1, 'NT-PER-014', 'Teclado Mecânico Signal', 'Teclado mecânico hot-swap com conexão USB-C.', 260.00, 449.90, 42, 8, 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80'),
(3, 1, 'NT-CMP-032', 'SSD NVMe 2 TB Vector', 'Armazenamento PCIe de alta velocidade.', 490.00, 799.90, 27, 6, 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=900&q=80'),
(2, 1, 'NT-PER-022', 'Headset Pulse Studio', 'Áudio espacial e microfone removível.', 310.00, 579.90, 3, 5, 'https://images.unsplash.com/photo-1599669454699-248893623440?auto=format&fit=crop&w=900&q=80'),
(3, 1, 'NT-CMP-041', 'Memória DDR5 32 GB', 'Kit de memória para plataformas atuais.', 380.00, 649.90, 14, 4, 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&w=900&q=80');

INSERT IGNORE INTO cupons (codigo, tipo, valor, minimo_pedido, usos_maximos, expira_em) VALUES
('NEXUS10', 'percentual', 10.00, 100.00, 100, DATE_ADD(NOW(), INTERVAL 90 DAY));

INSERT IGNORE INTO armazens (nome, codigo, descricao)
VALUES ('Armazém principal', 'PRINCIPAL', 'Armazém principal.');
INSERT IGNORE INTO estoque_armazens (armazem_id, produto_id, quantidade)
SELECT a.id, p.id, p.estoque FROM armazens a CROSS JOIN produtos p WHERE a.codigo = 'PRINCIPAL';
INSERT IGNORE INTO lotes_estoque (armazem_id, produto_id, numero_lote, quantidade)
SELECT s.armazem_id, s.produto_id, 'SALDO-INICIAL', s.quantidade
FROM estoque_armazens s
WHERE s.quantidade > 0
AND NOT EXISTS (SELECT 1 FROM lotes_estoque l WHERE l.armazem_id = s.armazem_id AND l.produto_id = s.produto_id AND l.numero_lote = 'SALDO-INICIAL' AND l.serie IS NULL);


CREATE TABLE IF NOT EXISTS avaliacoes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    estrelas TINYINT UNSIGNED NOT NULL,
    comentario VARCHAR(1500) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_avaliacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_avaliacoes_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
    CONSTRAINT uq_avaliacoes_usuario_produto UNIQUE (usuario_id, produto_id),
    CONSTRAINT chk_avaliacoes_estrelas CHECK (estrelas BETWEEN 1 AND 5),
    INDEX idx_avaliacoes_produto (produto_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO schema_migrations (name) VALUES
('001_estoque_admin.sql'),
('002_loja_virtual.sql'),
('003_perfil_avaliacoes.sql'),
('004_auth_version.sql'),
('005_erp_expansion.sql');
