ALTER TABLE usuarios
    ADD COLUMN avatar_url VARCHAR(500) NULL;

ALTER TABLE enderecos
    ADD COLUMN principal TINYINT(1) NOT NULL DEFAULT 0;

UPDATE enderecos address
JOIN (
    SELECT usuario_id, MIN(id) AS id
    FROM enderecos
    GROUP BY usuario_id
) first_address ON first_address.id = address.id
SET address.principal = 1;

CREATE TABLE IF NOT EXISTS avaliacoes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    produto_id BIGINT UNSIGNED NOT NULL,
    estrelas TINYINT UNSIGNED NOT NULL,
    comentario VARCHAR(1500) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_avaliacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_avaliacoes_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
    CONSTRAINT uq_avaliacoes_usuario_produto UNIQUE (usuario_id, produto_id),
    CONSTRAINT chk_avaliacoes_estrelas CHECK (estrelas BETWEEN 1 AND 5),
    INDEX idx_avaliacoes_produto (produto_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
