CREATE TABLE IF NOT EXISTS enderecos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    apelido VARCHAR(60) NOT NULL DEFAULT 'Principal',
    destinatario VARCHAR(120) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(180) NOT NULL,
    numero VARCHAR(20) NOT NULL,
    complemento VARCHAR(100) NULL,
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado CHAR(2) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_enderecos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_enderecos_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cupons (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(40) NOT NULL UNIQUE,
    tipo ENUM('percentual','fixo') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    minimo_pedido DECIMAL(12,2) NOT NULL DEFAULT 0,
    usos_maximos INT UNSIGNED NULL,
    usos INT UNSIGNED NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    expira_em DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_cupons_validade (ativo, expira_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expira_em DATETIME NOT NULL,
    usado_em DATETIME NULL,
    CONSTRAINT fk_reset_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_reset_validade (expira_em, usado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhook_eventos (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    evento_id VARCHAR(120) NOT NULL UNIQUE,
    recebido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processado_em TIMESTAMP NULL,
    INDEX idx_webhook_recebido (recebido_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO categorias (nome, slug, descricao) VALUES
('Computadores', 'computadores', 'Desktops e notebooks de alto desempenho'),
('Periféricos', 'perifericos', 'Equipamentos para seu setup'),
('Componentes', 'componentes', 'Peças para montar e atualizar');

INSERT IGNORE INTO fornecedores (id, nome, email) VALUES
(1, 'NexusTech Distribuição', 'compras@nexustech.local');

INSERT IGNORE INTO produtos (categoria_id, fornecedor_id, sku, nome, descricao, custo, preco, estoque, estoque_minimo, imagem_url) VALUES
(1, 1, 'NT-PC-001', 'Nexus Pro Creator', 'Workstation compacta para criação e desenvolvimento.', 3800.00, 5299.90, 18, 5, 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=900&q=80'),
(2, 1, 'NT-PER-014', 'Teclado Mecânico Signal', 'Teclado mecânico hot-swap com conexão USB-C.', 260.00, 449.90, 42, 8, 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80'),
(3, 1, 'NT-CMP-032', 'SSD NVMe 2 TB Vector', 'Armazenamento PCIe de alta velocidade.', 490.00, 799.90, 27, 6, 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=900&q=80'),
(2, 1, 'NT-PER-022', 'Headset Pulse Studio', 'Áudio espacial e microfone removível.', 310.00, 579.90, 3, 5, 'https://images.unsplash.com/photo-1599669454699-248893623440?auto=format&fit=crop&w=900&q=80'),
(3, 1, 'NT-CMP-041', 'Memória DDR5 32 GB', 'Kit de memória para plataformas atuais.', 380.00, 649.90, 14, 4, 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&w=900&q=80');

INSERT IGNORE INTO cupons (codigo, tipo, valor, minimo_pedido, usos_maximos, expira_em) VALUES
('NEXUS10', 'percentual', 10.00, 100.00, 100, DATE_ADD(NOW(), INTERVAL 90 DAY));