import { api, appPath, escapeHtml, money, notify } from './api-client.js';
import './navbar.js';

const id = Number(document.body.dataset.productId);
const root = document.querySelector('[data-product-detail]');
const relatedRoot = document.querySelector('[data-related]');
const reviewList = document.querySelector('[data-review-list]');
const reviewSummary = document.querySelector('[data-review-summary]');
const reviewForm = document.querySelector('[data-review-form]');
const reviewMessage = document.querySelector('[data-review-message]');
const cartKey = 'nexus-cart-v1';

function safeImage(value) {
  return typeof value === 'string' && /^https?:\/\//i.test(value) ? escapeHtml(value) : '';
}

function updateCartCount() {
  let items = [];
  try { items = JSON.parse(localStorage.getItem(cartKey) ?? '[]'); } catch {}
  window.NexusBag?.set(items.reduce((sum, item) => sum + Number(item.quantidade), 0));
}

async function loadProduct() {
  const product = (await api(`/api/v1/produtos/${id}`)).data;
  const images = [...new Set([product.imagem_url, ...(product.imagens ?? [])].map(safeImage).filter(Boolean))];
  root.innerHTML = `<div class="product-gallery"><div class="product-gallery-main"><img class="product-image" src="${images[0] ?? ''}" alt="${escapeHtml(product.nome)}" data-main-image></div><div class="product-thumbs">${images.map((image, index) => `<button type="button" data-image="${image}" aria-label="Ver imagem ${index + 1}"><img src="${image}" alt=""></button>`).join('')}</div></div><div class="product-detail-copy"><p class="eyebrow">${escapeHtml(product.categoria ?? 'NEXUSTECH')}</p><h1>${escapeHtml(product.nome)}</h1><span class="demo-product-tag">Produto demonstrativo · TCC</span><p class="product-description">${escapeHtml(product.descricao ?? '')}</p>${Number(product.avaliacoes_total) ? `<p class="product-rating"><span class="product-rating-stars">★ ${Number(product.avaliacao_media).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} / 5</span><span>${Number(product.avaliacoes_demo) ? `${Number(product.avaliacoes_demo)} avaliações demonstrativas${Number(product.avaliacoes_clientes) ? ` · ${Number(product.avaliacoes_clientes)} de clientes` : ''}` : `${Number(product.avaliacoes_clientes)} avaliações de clientes`}</span></p>` : ''}<p class="product-price product-detail-price">${money(product.preco)}</p><p class="muted" data-stock-status>${Number(product.estoque) > 0 ? `${Number(product.estoque)} unidades disponíveis` : 'Produto indisponível'}</p><button class="button button-primary" type="button" data-add-product ${Number(product.estoque) < 1 ? 'disabled' : ''}>Adicionar ao carrinho</button></div>`;
  document.title = `${product.nome} · NexusTech`;
  root.dataset.stock = String(product.estoque);
  root.dataset.productName = product.nome;
  root.dataset.price = String(product.preco);
  await Promise.all([
    loadRelated().catch((error) => {
      relatedRoot.innerHTML = `<p class="empty-state">${escapeHtml(error.message)}</p>`;
    }),
    loadReviews().catch((error) => {
      reviewSummary.textContent = 'Avaliações indisponíveis';
      reviewList.innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
    }),
  ]);
}

async function loadRelated() {
  const products = (await api(`/api/v1/produtos/${id}/relacionados`)).data;
  relatedRoot.innerHTML = products.map((product) => `<article class="product-card"><a href="${appPath(`produto/${Number(product.id)}`)}"><div class="product-art">${safeImage(product.imagem_url) ? `<img src="${safeImage(product.imagem_url)}" alt="" loading="lazy">` : 'NEXUS / TECH'}</div><div class="product-info"><h3>${escapeHtml(product.nome)}</h3><span class="demo-product-tag">Produto demonstrativo · TCC</span><p class="product-description-preview">${escapeHtml(product.descricao ?? '')}</p><div class="product-rating"><span class="product-rating-stars">${Number(product.avaliacoes_total) ? `★ ${Number(product.avaliacao_media).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}` : '☆ Sem nota'}</span><span>${Number(product.avaliacoes_demo) ? 'Avaliações demonstrativas' : Number(product.avaliacoes_clientes) ? `${Number(product.avaliacoes_clientes)} avaliações` : 'Sem avaliações'}</span></div><span class="product-price">${money(product.preco)}</span></div></a></article>`).join('');
}

async function loadReviews() {
  const { data } = await api(`/api/v1/produtos/${id}/avaliacoes`);
  const count = Number(data.resumo.total);
  const average = Number(data.resumo.media);
  reviewSummary.textContent = count
    ? `${average.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} / 5 · ${Number(data.resumo.clientes)} de clientes · ${Number(data.resumo.demonstracoes)} demonstrativas`
    : 'Ainda sem avaliações';
  reviewList.innerHTML = data.itens.length
    ? data.itens.map((review) => `<article class="review-item${Number(review.demonstracao) ? ' review-item-demo' : ''}"><div class="review-item-heading"><strong>${escapeHtml(review.autor)}</strong><span class="review-stars" aria-label="${Number(review.estrelas)} de 5 estrelas">${'★'.repeat(Number(review.estrelas))}${'☆'.repeat(5 - Number(review.estrelas))}</span></div>${Number(review.demonstracao) ? '<span class="demo-review-tag">Conteúdo fictício de demonstração</span>' : ''}<p>${escapeHtml(review.comentario || 'Sem comentário.')}</p><time class="muted" datetime="${escapeHtml(review.created_at)}">${new Date(review.created_at).toLocaleDateString('pt-BR')}</time></article>`).join('')
    : '<p class="muted">Seja o primeiro cliente a avaliar este produto após recebê-lo.</p>';
}

root.addEventListener('click', (event) => {
  const thumbnail = event.target.closest('[data-image]');
  if (thumbnail) root.querySelector('[data-main-image]').src = thumbnail.dataset.image;
  const addButton = event.target.closest('[data-add-product]');
  if (!addButton) return;
  let cart = [];
  try { cart = JSON.parse(localStorage.getItem(cartKey) ?? '[]'); } catch { cart = []; }
  const item = cart.find((entry) => Number(entry.produto_id) === id);
  if (item) item.quantidade += 1;
  else cart.push({ produto_id: id, quantidade: 1, nome: root.dataset.productName, preco: Number(root.dataset.price) });
  localStorage.setItem(cartKey, JSON.stringify(cart));
  updateCartCount();
  notify(`${root.dataset.productName} adicionado ao carrinho.`);
  addButton.textContent = 'Adicionado ao carrinho';
});

reviewForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = reviewForm.querySelector('[type="submit"]');
  submit.disabled = true;
  reviewMessage.textContent = 'Enviando avaliação...';
  const values = Object.fromEntries(new FormData(reviewForm));
  try {
    await api(`/api/v1/produtos/${id}/avaliacoes`, {
      method: 'POST',
      body: JSON.stringify({ estrelas: Number(values.estrelas), comentario: values.comentario }),
    });
    reviewMessage.textContent = 'Avaliação salva.';
    await loadReviews();
  } catch (error) {
    reviewMessage.textContent = error.message;
    if (error.message === 'Autenticação necessária.') {
      reviewMessage.innerHTML = `Entre na sua conta para avaliar. <a href="${appPath('login')}">Fazer login</a>`;
    }
  } finally {
    submit.disabled = false;
  }
});

async function refreshStock() {
  try {
    const product = (await api(`/api/v1/produtos/${id}`)).data;
    root.dataset.stock = String(product.estoque);
    root.querySelector('[data-stock-status]').textContent = Number(product.estoque) > 0 ? `${Number(product.estoque)} unidades disponíveis` : 'Produto indisponível';
    root.querySelector('[data-add-product]').disabled = Number(product.estoque) < 1;
  } catch {}
}

updateCartCount();
loadProduct().catch(() => { root.textContent = 'Produto não encontrado ou indisponível.'; });
window.setInterval(refreshStock, 30000);