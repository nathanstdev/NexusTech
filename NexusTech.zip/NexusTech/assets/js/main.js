import { api, appPath, escapeHtml, money, notify } from './api-client.js';
import './navbar.js';

const grid = document.querySelector('[data-product-grid]');
const status = document.querySelector('[data-catalog-status]');
const search = document.querySelector('[data-search]');
const sort = document.querySelector('[data-sort]');
const category = document.querySelector('[data-category]');
const minimum = document.querySelector('[data-min]');
const maximum = document.querySelector('[data-max]');
const available = document.querySelector('[data-available]');
const loadMore = document.querySelector('[data-load-more]');
const storageKey = 'nexus-cart-v1';
let debounce;
let page = 1;

async function loadProducts(append = false) {
  if (!grid) return;
  try {
    const params = new URLSearchParams({ per_page: '24', page: String(page) });
    if (search?.value.trim()) params.set('q', search.value.trim());
    if (category?.value) params.set('categoria', category.value);
    if (minimum?.value) params.set('min', minimum.value);
    if (maximum?.value) params.set('max', maximum.value);
    if (available?.checked) params.set('disponivel', '1');
    const [order, direction] = (sort?.value ?? 'recentes-desc').split('-');
    params.set('ordenar', order);
    params.set('direcao', direction ?? 'desc');
    const payload = await api(`/api/v1/produtos?${params}`);
    const products = payload.data;
    status.textContent = `${payload.meta.total} produtos disponíveis`;
    const markup = products.map((product) => `
      <article class="product-card">
        <div class="product-art" aria-hidden="true">${product.imagem_url && /^https?:\/\//i.test(product.imagem_url) ? `<img src="${escapeHtml(product.imagem_url)}" alt="" loading="lazy">` : escapeHtml(product.categoria ?? 'NEXUS / TECH')}</div>
        <div class="product-info"><h3><a class="product-title-link" href="${appPath(`produto/${Number(product.id)}`)}">${escapeHtml(product.nome)}</a></h3>
          <span class="demo-product-tag">Produto demonstrativo · TCC</span>
          <p class="product-description-preview">${escapeHtml(product.descricao ?? '')}</p>
          <div class="product-rating" aria-label="${Number(product.avaliacoes_demo) ? 'Inclui avaliações demonstrativas fictícias' : ''}">
            <span class="product-rating-stars">${Number(product.avaliacoes_total) ? `★ ${Number(product.avaliacao_media).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}` : '☆ Sem nota'}</span>
            <span>${Number(product.avaliacoes_demo) ? `${Number(product.avaliacoes_demo)} avaliações demonstrativas${Number(product.avaliacoes_clientes) ? ` · ${Number(product.avaliacoes_clientes)} de clientes` : ''}` : Number(product.avaliacoes_clientes) ? `${Number(product.avaliacoes_clientes)} avaliações de clientes` : 'Seja o primeiro a avaliar'}</span>
          </div>
          <div class="product-meta"><span>${Number(product.estoque) > 0 ? 'Em estoque' : 'Indisponível'}</span><span class="product-price">${money(product.preco)}</span></div>
          <a class="product-details-link" href="${appPath(`produto/${Number(product.id)}`)}">Ver detalhes e biografia <span aria-hidden="true">→</span></a>
          <button class="product-add" type="button" data-add="${Number(product.id)}" ${Number(product.estoque) < 1 ? 'disabled' : ''}>Adicionar ao carrinho</button>
        </div>
      </article>`).join('');
    if (append) grid.insertAdjacentHTML('beforeend', markup);
    else grid.innerHTML = markup || '<p class="empty-state">Nenhum produto disponível no momento.</p>';
    loadMore.hidden = page >= payload.meta.pages;
  } catch {
    status.textContent = 'Catálogo indisponível';
    grid.innerHTML = '<p class="empty-state">Não foi possível carregar o catálogo. Verifique o banco de dados.</p>';
  }
}

function readCart() {
  try { return JSON.parse(localStorage.getItem(storageKey) ?? '[]'); } catch { return []; }
}

function updateCartCount() {
  const total = readCart().reduce((sum, item) => sum + item.quantidade, 0);
  window.NexusBag?.set(total);
}

grid?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-add]');
  if (!button) return;
  button.disabled = true;
  try {
    const product = (await api(`/api/v1/produtos/${button.dataset.add}`)).data;
    const cart = readCart();
    const entry = cart.find((item) => Number(item.produto_id) === Number(product.id));
    if (entry) entry.quantidade += 1;
    else cart.push({ produto_id: product.id, quantidade: 1, nome: product.nome, preco: product.preco });
    localStorage.setItem(storageKey, JSON.stringify(cart));
    updateCartCount();
    notify(`${product.nome} adicionado ao carrinho.`);
    button.textContent = 'Adicionado ao carrinho';
    window.setTimeout(() => { button.textContent = 'Adicionar ao carrinho'; button.disabled = false; }, 1100);
  } catch {
    button.textContent = 'Indisponível';
    button.disabled = false;
  }
});

function resetSearch() {
  page = 1;
  loadProducts();
}

search?.addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(resetSearch, 250); });
for (const control of [sort, category, available]) control?.addEventListener('change', resetSearch);
for (const control of [minimum, maximum]) control?.addEventListener('change', resetSearch);
loadMore?.addEventListener('click', () => { page += 1; loadProducts(true); });

async function loadCategories() {
  if (!category) return;
  const categories = (await api('/api/v1/categorias')).data;
  category.insertAdjacentHTML('beforeend', categories.map((item) => `<option value="${escapeHtml(item.slug)}">${escapeHtml(item.nome)}</option>`).join(''));
}

updateCartCount();
loadCategories().then(loadProducts).catch(loadProducts);
if ('serviceWorker' in navigator) navigator.serviceWorker.register(appPath('service-worker.js')).catch(() => {});