import { api, escapeHtml, money } from './api-client.js';

const chartInstances = new Map();
const colors = ['#8be8d1', '#d2f36b', '#6aa6d8', '#f0a970', '#c7a9ed', '#f17c84', '#8ebc73', '#dfb95d'];

function chartTheme() {
  const styles = getComputedStyle(document.documentElement);
  return {
    ink: styles.getPropertyValue('--ink').trim(),
    muted: styles.getPropertyValue('--muted').trim(),
    line: styles.getPropertyValue('--line').trim(),
    surface: styles.getPropertyValue('--surface-solid').trim(),
    tooltip: styles.getPropertyValue('--chart-tooltip-bg').trim(),
  };
}

const period = document.querySelector('[data-period]');
const refreshLabel = document.querySelector('[data-refresh]');
const categoryPanel = document.createElement('section');
categoryPanel.className = 'admin-section split-layout';
categoryPanel.id = 'categorias';
categoryPanel.innerHTML = '<article class="panel"><h2>Criar categoria</h2><form class="form-stack" data-category-form><label>Nome<input class="field" name="nome" required maxlength="100"></label><label>Slug (ex.: componentes-pc)<input class="field" name="slug" pattern="[a-z0-9]+(-[a-z0-9]+)*" required maxlength="120"></label><label>Descrição<input class="field" name="descricao" maxlength="500"></label><p class="form-message" data-category-message aria-live="polite"></p><button class="button-small" type="submit">Criar categoria</button></form></article><article class="panel"><div class="chart-actions"><h2>Categorias</h2><button class="button-small" type="button" data-export-categories>Exportar CSV</button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Categoria</th><th>Slug</th><th>Status</th><th>Ação</th></tr></thead><tbody data-admin-categories></tbody></table></div></article><article class="panel"><div class="chart-actions"><h2>Compras recebidas</h2><button class="button-small" type="button" data-export-purchases>Exportar CSV</button></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Compra</th><th>Fornecedor</th><th>Nota fiscal</th><th>Total</th><th>Operador</th><th>Data</th></tr></thead><tbody data-purchases></tbody></table></div></article></section>';
document.querySelector('.page-shell').append(categoryPanel);
document.querySelector('[data-purchases]')?.closest('.panel')?.setAttribute('id', 'compras-recebidas');
const operationsPanel = document.createElement('section');
operationsPanel.id = 'erp-operacoes';
operationsPanel.className = 'admin-section erp-operations';
operationsPanel.innerHTML = `
  <section class="panel">
    <div class="chart-actions"><div><p class="eyebrow">ESTOQUE DISTRIBUÍDO</p><h2>Armazéns, lotes e séries</h2></div><button class="button-small" type="button" data-refresh-warehouses>Atualizar</button></div>
    <div class="erp-split">
      <form class="form-stack erp-form" data-warehouse-form>
        <h3>Novo armazém</h3>
        <label>Nome<input class="field" name="nome" required maxlength="120"></label>
        <label>Código<input class="field" name="codigo" required maxlength="40" pattern="[A-Za-z0-9][A-Za-z0-9_-]{1,39}"></label>
        <label>Descrição<input class="field" name="descricao" maxlength="500"></label>
        <p class="form-message" data-warehouse-message aria-live="polite"></p>
        <button class="button-small" type="submit">Criar armazém</button>
      </form>
      <div>
        <h3>Armazéns ativos</h3>
        <div class="table-wrap"><table class="data-table"><thead><tr><th>Armazém</th><th>Código</th><th>Produtos</th><th>Unidades</th></tr></thead><tbody data-warehouses></tbody></table></div>
      </div>
    </div>
    <div class="chart-actions erp-subheading"><h3>Saldo por local</h3><select class="select-field" data-stock-warehouse aria-label="Filtrar estoque por armazém"><option value="">Todos os armazéns</option></select></div>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Armazém</th><th>SKU</th><th>Produto</th><th>Quantidade</th><th>Mínimo global</th></tr></thead><tbody data-warehouse-stock></tbody></table></div>
    <div class="chart-actions erp-subheading"><h3>Lotes e números de série</h3><button class="button-small" type="button" data-export-lots>Exportar CSV</button></div>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Armazém</th><th>Produto</th><th>Lote</th><th>Série</th><th>Unidades</th><th>Validade</th></tr></thead><tbody data-lots></tbody></table></div>
  </section>
  <div class="erp-split">
    <section class="panel">
      <h2>Transferência entre armazéns</h2>
      <form class="form-stack" data-transfer-form>
        <label>Origem<select class="select-field" name="origem_id" data-transfer-source required></select></label>
        <label>Destino<select class="select-field" name="destino_id" data-transfer-destination required></select></label>
        <label>Produto<select class="select-field" name="produto_id" data-transfer-product required></select></label>
        <label>Quantidade<input class="field" name="quantidade" type="number" min="1" required></label>
        <label>Motivo<input class="field" name="motivo" maxlength="255" required></label>
        <p class="form-message" data-transfer-message aria-live="polite"></p>
        <button class="button-small" type="submit">Transferir com rastreio de lote</button>
      </form>
    </section>
    <section class="panel">
      <h2>Inventário físico</h2>
      <form class="form-stack" data-inventory-start>
        <label>Armazém<select class="select-field" name="armazem_id" data-inventory-warehouse required></select></label>
        <label>Observação<input class="field" name="observacao" maxlength="500"></label>
        <p class="form-message" data-inventory-message aria-live="polite"></p>
        <button class="button-small" type="submit">Iniciar contagem</button>
      </form>
      <label class="form-stack">Contagem em andamento<select class="select-field" data-inventory-select><option value="">Selecione</option></select></label>
      <div class="table-wrap"><table class="data-table"><thead><tr><th>Produto / SKU</th><th>Sistema</th><th>Contado</th><th>Ação</th></tr></thead><tbody data-inventory-items></tbody></table></div>
      <button class="button-small" type="button" data-inventory-complete disabled>Aplicar contagem e concluir</button>
    </section>
  </div>
  <section class="panel" id="financeiro">
    <div class="chart-actions"><div><p class="eyebrow">CONTAS A PAGAR E RECEBER</p><h2>Financeiro</h2></div><button class="button-small" type="button" data-refresh-finance>Atualizar</button></div>
    <div class="dashboard-grid" data-finance-summary></div>
    <form class="form-stack finance-form" data-finance-form>
      <label>Tipo<select class="select-field" name="tipo"><option value="pagar">A pagar</option><option value="receber">A receber</option></select></label>
      <label>Descrição<input class="field" name="descricao" required maxlength="255"></label>
      <label>Contraparte<input class="field" name="contraparte" maxlength="190"></label>
      <label>Valor<input class="field" name="valor" type="number" min="0.01" step="0.01" required></label>
      <label>Vencimento<input class="field" name="vencimento" type="date" required></label>
      <p class="form-message" data-finance-message aria-live="polite"></p>
      <button class="button-small" type="submit">Registrar conta</button>
    </form>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Tipo</th><th>Descrição</th><th>Contraparte</th><th>Valor</th><th>Vencimento</th><th>Status</th><th>Ação</th></tr></thead><tbody data-finance-accounts></tbody></table></div>
  </section>
  <section class="panel" id="assistente">
    <div class="chart-actions"><div><p class="eyebrow">REGRAS OPERACIONAIS · DADOS INTERNOS</p><h2>Insights do ERP</h2></div><button class="button-small" type="button" data-refresh-insights>Atualizar insights</button></div>
    <p class="muted">Alertas explicáveis gerados a partir de estoque, lotes e contas. Esta tela não envia dados a serviços externos nem se apresenta como um modelo generativo.</p>
    <div class="insight-list" data-insights aria-live="polite"></div>
  </section>`;
document.querySelector('.page-shell').append(operationsPanel);
document.querySelector('[data-product-form]').insertAdjacentHTML('afterbegin', '<label>Categoria<select class="select-field" name="categoria_id" data-product-category><option value="">Sem categoria</option></select></label>');
document.querySelector('[data-product-form] [data-product-category]').insertAdjacentHTML('afterend', '<label>Fornecedor<select class="select-field" name="fornecedor_id" data-product-supplier><option value="">Sem fornecedor</option></select></label>');
const purchaseProductField = document.querySelector('[data-purchase-form] input[name="produto_id"]');
purchaseProductField.outerHTML = '<select class="select-field" name="produto_id" data-purchase-product required><option value="">Selecione o produto</option></select>';
document.querySelector('[data-purchase-form] [name="nota_fiscal"]').insertAdjacentHTML('afterend', `
  <label>Armazém de recebimento<select class="select-field" name="armazem_id" data-purchase-warehouse required></select></label>
  <label>Número do lote<input class="field" name="numero_lote" maxlength="100"></label>
  <label>Número de série (unidade única)<input class="field" name="serie" maxlength="120"></label>
  <label>Validade<input class="field" name="validade" type="date"></label>`);
const exportData = (filename, rows, headings) => {
  const quote = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
  const csv = [headings, ...rows].map((row) => row.map(quote).join(',')).join('\r\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob(['\ufeff', csv], { type: 'text/csv;charset=utf-8' }));
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
};
const fetchAllPages = async (endpoint) => {
  const pageSize = 100;
  let page = 1;
  let rows = [];
  let pages = 1;
  do {
    const query = new URLSearchParams({ page: String(page), per_page: String(pageSize) });
    const result = await api(`${endpoint}?${query}`);
    rows = rows.concat(result.data);
    pages = Number(result.meta.pages ?? Math.ceil(Number(result.meta.total ?? rows.length) / pageSize));
    page += 1;
  } while (page <= pages);
  return rows;
};

function animateKpi(element) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  element.animate([{ opacity: 0.25, transform: 'translateY(5px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 360, easing: 'ease-out' });
}

function chart(canvas, type, labels, datasets, options = {}) {
  if (chartInstances.has(canvas.dataset.chart)) chartInstances.get(canvas.dataset.chart).destroy();
  const theme = chartTheme();
  const defaultPlugins = {
    legend: { labels: { color: theme.muted, usePointStyle: true } },
    tooltip: {
      enabled: true,
      backgroundColor: theme.tooltip,
      titleColor: theme.ink,
      bodyColor: theme.ink,
      borderColor: theme.line,
      borderWidth: 1,
      padding: 12,
      cornerRadius: 14,
      displayColors: true,
    },
  };
  const defaultScales = type === 'doughnut' ? {} : {
    x: { ticks: { color: theme.muted }, grid: { color: theme.line } },
    y: { beginAtZero: true, ticks: { color: theme.muted }, grid: { color: theme.line } },
  };
  const scales = { ...defaultScales, ...options.scales };
  ['x', 'y'].forEach((axis) => {
    if (!defaultScales[axis] || !options.scales?.[axis]) return;
    const defaults = defaultScales[axis];
    const custom = options.scales[axis];
    scales[axis] = {
      ...defaults,
      ...custom,
      ticks: { ...defaults.ticks, ...custom.ticks },
      grid: { ...defaults.grid, ...custom.grid },
      title: { ...defaults.title, ...custom.title },
    };
  });
  const instance = new Chart(canvas, {
    type,
    data: { labels, datasets },
    options: {
      ...options,
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 650 },
      interaction: { intersect: false, mode: 'index' },
      plugins: {
        ...defaultPlugins,
        ...options.plugins,
        legend: {
          ...defaultPlugins.legend,
          ...options.plugins?.legend,
          labels: { ...defaultPlugins.legend.labels, ...options.plugins?.legend?.labels },
        },
        tooltip: { ...defaultPlugins.tooltip, ...options.plugins?.tooltip },
      },
      scales,
    },
  });
  chartInstances.set(canvas.dataset.chart, instance);
}

const chartThemeObserver = new MutationObserver(() => {
  const theme = chartTheme();
  chartInstances.forEach((instance) => {
    const legend = instance.options.plugins.legend;
    if (legend?.labels) legend.labels.color = theme.muted;
    const tooltip = instance.options.plugins.tooltip;
    if (tooltip) {
      tooltip.backgroundColor = theme.tooltip;
      tooltip.titleColor = theme.ink;
      tooltip.bodyColor = theme.ink;
      tooltip.borderColor = theme.line;
    }
    Object.values(instance.options.scales ?? {}).forEach((scale) => {
      if (scale.ticks) scale.ticks.color = theme.muted;
      if (scale.grid) scale.grid.color = theme.line;
      if (scale.title) scale.title.color = theme.muted;
    });
    instance.update('none');
  });
});
chartThemeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

function renderCharts(report) {
  if (!window.Chart) return;
  const theme = chartTheme();
  const byId = (id) => document.querySelector(`[data-chart="${id}"]`);
  const sales = report.vendas;
  chart(byId('sales'), 'line', sales.map((row) => row.dia), [{ label: 'Faturamento', data: sales.map((row) => Number(row.valor)), borderColor: colors[0], backgroundColor: '#8be8d126', fill: true, tension: 0.34, pointRadius: 2 }]);
  chart(byId('top'), 'bar', report.mais_vendidos.map((row) => row.nome), [{ label: 'Unidades', data: report.mais_vendidos.map((row) => Number(row.quantidade)), backgroundColor: colors[0], borderRadius: 3 }], { indexAxis: 'y' });
  chart(byId('categories'), 'doughnut', report.categorias.map((row) => row.nome), [{ label: 'Faturamento', data: report.categorias.map((row) => Number(row.valor)), backgroundColor: colors, borderColor: theme.surface, borderWidth: 3 }], { plugins: { legend: { position: 'bottom' } } });
  chart(byId('stock'), 'bar', report.estoque.map((row) => row.dia), [{ label: 'Entradas', data: report.estoque.map((row) => Number(row.entradas)), backgroundColor: colors[0] }, { label: 'Saídas', data: report.estoque.map((row) => Number(row.saidas)), backgroundColor: colors[3] }], { scales: { x: { stacked: false, ticks: { color: theme.muted }, grid: { color: theme.line } }, y: { beginAtZero: true, ticks: { color: theme.muted }, grid: { color: theme.line } } } });
  chart(byId('abc'), 'bar', report.curva_abc.map((row) => row.nome), [{ label: 'Receita', data: report.curva_abc.map((row) => Number(row.receita)), backgroundColor: report.curva_abc.map((row) => ({ A: colors[0], B: colors[1], C: colors[3] })[row.classe]), borderRadius: 3 }], { indexAxis: 'y', plugins: { tooltip: { callbacks: { afterLabel: (context) => `Classe ${report.curva_abc[context.dataIndex]?.classe ?? ''}` } } } });
  let turnoverTitle = document.querySelector('[data-turnover-title]');
  if (!turnoverTitle) {
    turnoverTitle = document.createElement('h3');
    turnoverTitle.dataset.turnoverTitle = '';
    turnoverTitle.textContent = 'Giro por produto';
    const turnoverExport = document.createElement('button');
    turnoverExport.type = 'button';
    turnoverExport.dataset.export = 'turnover';
    turnoverExport.setAttribute('aria-label', 'Exportar giro de estoque como imagem');
    turnoverExport.textContent = 'PNG';
    byId('abc').after(turnoverTitle);
    turnoverTitle.after(turnoverExport);
    const turnoverCanvas = document.createElement('canvas');
    turnoverCanvas.dataset.chart = 'turnover';
    turnoverCanvas.setAttribute('aria-label', 'Giro de estoque por produto');
    turnoverExport.after(turnoverCanvas);
  }
  const classByName = new Map(report.curva_abc.map((row) => [row.nome, row.classe]));
  chart(byId('turnover'), 'bar', report.giro.map((row) => row.nome), [{ label: 'Unidades vendidas / estoque atual', data: report.giro.map((row) => Number(row.giro ?? 0)), backgroundColor: report.giro.map((row) => ({ A: colors[0], B: colors[1], C: colors[3] })[classByName.get(row.nome)] ?? theme.muted), borderRadius: 3 }], { indexAxis: 'y', plugins: { legend: { position: 'bottom' } } });
  let staleList = document.querySelector('[data-stale-products]');
  if (!staleList) {
    staleList = document.createElement('div');
    staleList.dataset.staleProducts = '';
    staleList.className = 'stale-list';
    byId('abc').after(staleList);
  }
  staleList.innerHTML = `<p class="muted">Sem vendas no período: ${report.parados.slice(0, 6).map((row) => escapeHtml(row.nome)).join(' · ') || 'nenhum produto'}</p>`;
  chart(byId('profit'), 'line', report.lucro.map((row) => row.dia), [{ label: 'Lucro estimado', data: report.lucro.map((row) => Number(row.lucro)), borderColor: colors[1], backgroundColor: '#d2f36b22', fill: true, tension: 0.3 }]);
  const heatMap = new Map(report.calor.map((row) => [`${row.dia_semana}-${row.hora}`, Number(row.pedidos)]));
  const heatPoints = Array.from({ length: 7 * 24 }, (_, index) => {
    const day = Math.floor(index / 24);
    const hour = index % 24;
    return { x: hour, y: day, r: Math.min(13, 3 + (heatMap.get(`${day}-${hour}`) ?? 0) * 2), volume: heatMap.get(`${day}-${hour}`) ?? 0 };
  });
  chart(byId('heat'), 'bubble', [], [{ label: 'Pedidos', data: heatPoints, backgroundColor: (context) => `rgba(139,232,209,${0.12 + (context.raw?.volume ?? 0) * 0.16})` }], {
    interaction: { intersect: true },
    plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'][context.raw.y]} · ${context.raw.x}h · ${context.raw.volume} pedido(s)` } } },
    scales: { x: { min: -1, max: 24, title: { display: true, text: 'Hora', color: theme.muted }, ticks: { stepSize: 2, color: theme.muted }, grid: { color: theme.line } }, y: { min: -0.6, max: 6.6, reverse: true, title: { display: true, text: 'Dia da semana', color: theme.muted }, ticks: { stepSize: 1, color: theme.muted, callback: (value) => ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'][value] ?? '' }, grid: { color: theme.line } } },
  });
}

async function loadDashboard() {
  const params = new URLSearchParams({ periodo: period.value === 'custom' ? '30' : period.value });
  if (period.value === 'custom') {
    const from = document.querySelector('[data-date-from]').value;
    const to = document.querySelector('[data-date-to]').value;
    if (!from || !to) return;
    params.set('de', from);
    params.set('ate', to);
  }
  const payload = (await api(`/api/v1/admin/dashboard?${params}`)).data;
  for (const key of ['faturamento', 'pedidos', 'ticket_medio', 'estoque_baixo']) {
    const node = document.querySelector(`[data-kpi="${key}"]`);
    node.textContent = key === 'faturamento' || key === 'ticket_medio' ? money(payload.kpis[key]) : Number(payload.kpis[key]).toLocaleString('pt-BR');
    animateKpi(node);
  }
  renderCharts(payload);
  refreshLabel.textContent = `Atualizado às ${new Date().toLocaleTimeString('pt-BR')}`;
}

async function loadInventory() {
  const rows = (await api('/api/v1/admin/produtos')).data;
  const productSelect = document.querySelector('[data-purchase-product]');
  if (productSelect) {
    const previous = productSelect.value;
    productSelect.innerHTML = '<option value="">Selecione o produto</option>' + rows.map((product) => `<option value="${Number(product.id)}">${escapeHtml(product.nome)} · ${escapeHtml(product.sku)}</option>`).join('');
    productSelect.value = previous;
  }
  document.querySelector('[data-inventory]').innerHTML = rows.map((product) => `<tr><td>${escapeHtml(product.nome)}<br><span class="muted">${escapeHtml(product.sku)}</span></td><td>${Number(product.estoque)}</td><td>${Number(product.estoque_minimo)}</td><td><div class="toolbar"><select class="select-field" aria-label="Tipo da movimentação" data-stock-type><option value="entrada">Entrada</option><option value="saida">Saída</option><option value="ajuste">Ajuste (+/-)</option></select><input class="field" type="number" step="1" value="1" aria-label="Quantidade"><input class="field" type="text" maxlength="255" placeholder="Motivo" aria-label="Motivo da movimentação"><button class="table-action" data-stock="${Number(product.id)}" type="button">Aplicar</button><input class="field" type="number" min="0" step="0.01" value="${Number(product.preco)}" aria-label="Preço rápido"><button class="table-action" data-price="${Number(product.id)}" type="button">Preço</button><button class="table-action" data-deactivate="${Number(product.id)}" type="button">Desativar</button></div></td></tr>`).join('');
}

async function loadOrders() {
  const rows = (await api('/api/v1/pedidos')).data;
  document.querySelector('[data-orders]').innerHTML = rows.map((order) => `<tr><td>#${Number(order.id)}</td><td>${escapeHtml(order.cliente)}</td><td><span class="status-pill">${escapeHtml(order.status)}</span></td><td>${money(order.total)}</td><td>${new Date(order.created_at).toLocaleDateString('pt-BR')}</td><td><div class="toolbar"><select class="select-field" data-order-status="${Number(order.id)}" aria-label="Status do pedido"><option value="">Atualizar</option>${['pago', 'separado', 'enviado', 'entregue', 'cancelado'].map((status) => `<option value="${status}">${status}</option>`).join('')}</select><a class="table-action" href="${document.body.dataset.basePath}/admin/gerar_pdf.php?pedido=${Number(order.id)}">PDF</a></div></td></tr>`).join('');
}

async function loadSuppliers() {
  const rows = (await api('/api/v1/admin/fornecedores')).data;
  document.querySelector('[data-suppliers]').innerHTML = rows.map((row) => `<tr><td>${escapeHtml(row.nome)}</td><td>${escapeHtml(row.email ?? '')}</td><td>${escapeHtml(row.documento ?? '')}</td><td>${Number(row.ativo) ? 'Ativo' : 'Inativo'}</td><td><button class="table-action" type="button" data-supplier-toggle="${Number(row.id)}" data-active="${Number(row.ativo)}">${Number(row.ativo) ? 'Desativar' : 'Ativar'}</button></td></tr>`).join('');
  document.querySelector('[data-supplier-select]').innerHTML = '<option value="">Selecione</option>' + rows.filter((row) => Number(row.ativo)).map((row) => `<option value="${Number(row.id)}">${escapeHtml(row.nome)}</option>`).join('');
  document.querySelector('[data-product-supplier]').innerHTML = '<option value="">Sem fornecedor</option>' + rows.filter((row) => Number(row.ativo)).map((row) => `<option value="${Number(row.id)}">${escapeHtml(row.nome)}</option>`).join('');
}

async function loadUsers() {
  const rows = (await api('/api/v1/admin/usuarios?per_page=100')).data;
  document.querySelector('[data-users]').innerHTML = rows.map((row) => `<tr><td>${escapeHtml(row.nome)}<br><span class="muted">${escapeHtml(row.email)}</span></td><td>${escapeHtml(row.role)}</td><td>${Number(row.ativo) ? 'Ativo' : 'Bloqueado'}</td><td><div class="toolbar"><button class="table-action" type="button" data-user-active="${Number(row.id)}" data-active="${Number(row.ativo)}">${Number(row.ativo) ? 'Bloquear' : 'Ativar'}</button><button class="table-action" type="button" data-user-reset="${Number(row.id)}">Enviar redefinição</button></div></td></tr>`).join('');
}

async function loadMovements() {
  const rows = (await api('/api/v1/admin/estoque/movimentacoes')).data;
  document.querySelector('[data-movements]').innerHTML = rows.map((row) => `<tr><td>${new Date(row.created_at).toLocaleString('pt-BR')}</td><td>${escapeHtml(row.produto)}<br><span class="muted">${escapeHtml(row.sku)}</span></td><td>${escapeHtml(row.armazem ?? '—')}</td><td>${escapeHtml(row.numero_lote ?? '—')}${row.serie ? `<br><span class="muted">${escapeHtml(row.serie)}</span>` : ''}</td><td>${escapeHtml(row.tipo)}</td><td>${Number(row.quantidade)}</td><td>${escapeHtml(row.motivo)}</td><td>${escapeHtml(row.usuario)}</td></tr>`).join('');
}

async function loadCategories() {
  const rows = (await api('/api/v1/admin/categorias')).data;
  const categorySelect = document.querySelector('[data-product-category]');
  if (categorySelect) {
    categorySelect.innerHTML = '<option value="">Sem categoria</option>' + rows.filter((row) => Number(row.ativo)).map((row) => `<option value="${Number(row.id)}">${escapeHtml(row.nome)}</option>`).join('');
  }
  document.querySelector('[data-admin-categories]').innerHTML = rows.map((row) => `<tr><td>${escapeHtml(row.nome)}</td><td>${escapeHtml(row.slug)}</td><td>${Number(row.ativo) ? 'Ativa' : 'Inativa'}</td><td><button class="table-action" data-category-toggle="${Number(row.id)}" data-active="${Number(row.ativo)}" type="button">${Number(row.ativo) ? 'Desativar' : 'Ativar'}</button></td></tr>`).join('');
}

async function loadPurchases() {
  const rows = (await api('/api/v1/admin/compras')).data;
  document.querySelector('[data-purchases]').innerHTML = rows.map((row) => `<tr><td>#${Number(row.id)}</td><td>${escapeHtml(row.fornecedor)}</td><td>${escapeHtml(row.nota_fiscal ?? '')}</td><td>${money(row.total)}</td><td>${escapeHtml(row.operador)}</td><td>${new Date(row.created_at).toLocaleDateString('pt-BR')}</td></tr>`).join('');
}

let warehouseRows = [];
let warehouseStockRows = [];

async function loadWarehouseStock() {
  warehouseStockRows = (await api('/api/v1/admin/armazens/estoque')).data;
  const warehouseId = document.querySelector('[data-stock-warehouse]').value;
  const rows = warehouseId ? warehouseStockRows.filter((row) => String(row.armazem_id) === warehouseId) : warehouseStockRows;
  document.querySelector('[data-warehouse-stock]').innerHTML = rows.map((row) => `<tr><td>${escapeHtml(row.armazem)}</td><td>${escapeHtml(row.sku)}</td><td>${escapeHtml(row.produto)}</td><td>${Number(row.quantidade)}</td><td>${Number(row.estoque_minimo)}</td></tr>`).join('');
  loadTransferProducts();
}

async function loadLots() {
  const warehouseId = document.querySelector('[data-stock-warehouse]').value;
  const params = warehouseId ? `?armazem_id=${encodeURIComponent(warehouseId)}` : '';
  const rows = (await api(`/api/v1/admin/lotes${params}`)).data;
  document.querySelector('[data-lots]').innerHTML = rows.map((row) => `<tr><td>${escapeHtml(row.armazem)}</td><td>${escapeHtml(row.produto)}<br><span class="muted">${escapeHtml(row.sku)}</span></td><td>${escapeHtml(row.numero_lote)}</td><td>${escapeHtml(row.serie ?? '—')}</td><td>${Number(row.quantidade)}</td><td>${escapeHtml(row.validade ?? '—')}</td></tr>`).join('');
}

function fillWarehouseSelect(selector, includeEmpty = false) {
  const select = document.querySelector(selector);
  if (!select) return;
  const previous = select.value;
  select.innerHTML = `${includeEmpty ? '<option value="">Todos os armazéns</option>' : ''}${warehouseRows.map((row) => `<option value="${Number(row.id)}">${escapeHtml(row.nome)} · ${escapeHtml(row.codigo)}</option>`).join('')}`;
  if (warehouseRows.some((row) => String(row.id) === previous)) select.value = previous;
}

async function loadWarehouses() {
  warehouseRows = (await api('/api/v1/admin/armazens')).data;
  fillWarehouseSelect('[data-stock-warehouse]', true);
  fillWarehouseSelect('[data-transfer-source]');
  fillWarehouseSelect('[data-transfer-destination]');
  fillWarehouseSelect('[data-inventory-warehouse]');
  fillWarehouseSelect('[data-purchase-warehouse]');
  document.querySelector('[data-warehouses]').innerHTML = warehouseRows.map((row) => `<tr><td>${escapeHtml(row.nome)}</td><td>${escapeHtml(row.codigo)}</td><td>${Number(row.produtos)}</td><td>${Number(row.unidades)}</td></tr>`).join('');
  await Promise.all([loadWarehouseStock(), loadLots()]);
}

function loadTransferProducts() {
  const sourceId = document.querySelector('[data-transfer-source]').value;
  const select = document.querySelector('[data-transfer-product]');
  const products = warehouseStockRows.filter((row) => String(row.armazem_id) === sourceId && Number(row.quantidade) > 0);
  select.innerHTML = products.map((row) => `<option value="${Number(row.produto_id)}">${escapeHtml(row.produto)} · ${escapeHtml(row.sku)} · ${Number(row.quantidade)} un.</option>`).join('');
  if (products.length === 0) select.innerHTML = '<option value="">Sem produtos neste armazém</option>';
}

async function loadInventories() {
  const rows = (await api('/api/v1/admin/inventarios')).data;
  const active = rows.filter((row) => row.status === 'em_contagem');
  const select = document.querySelector('[data-inventory-select]');
  const previous = select.value;
  select.innerHTML = `<option value="">Selecione</option>${active.map((row) => `<option value="${Number(row.id)}">#${Number(row.id)} · ${escapeHtml(row.armazem)} · ${Number(row.pendentes)} pendentes</option>`).join('')}`;
  if (active.some((row) => String(row.id) === previous)) select.value = previous;
  else if (active.length) select.value = String(active[0].id);
  await loadInventoryItems();
}

async function loadInventoryItems() {
  const inventoryId = document.querySelector('[data-inventory-select]').value;
  const body = document.querySelector('[data-inventory-items]');
  const complete = document.querySelector('[data-inventory-complete]');
  if (!inventoryId) {
    body.replaceChildren();
    complete.disabled = true;
    return;
  }
  const { data } = await api(`/api/v1/admin/inventarios?id=${encodeURIComponent(inventoryId)}`);
  const items = data.itens;
  body.innerHTML = items.map((row) => `<tr><td>${escapeHtml(row.produto)}<br><span class="muted">${escapeHtml(row.sku)}</span></td><td>${Number(row.quantidade_sistema)}</td><td><input class="field" type="number" min="0" max="100000000" step="1" value="${row.quantidade_contada === null ? '' : Number(row.quantidade_contada)}" aria-label="Quantidade contada para ${escapeHtml(row.produto)}" data-count-value="${Number(row.produto_id)}"></td><td><button class="table-action" type="button" data-count-save="${Number(row.produto_id)}">Salvar</button></td></tr>`).join('');
  complete.disabled = items.some((row) => row.quantidade_contada === null);
}

async function loadFinance() {
  const { data } = await api('/api/v1/admin/financeiro');
  document.querySelector('[data-finance-summary]').innerHTML = data.resumo.map((row) => `<article class="kpi"><span>${row.tipo === 'pagar' ? 'A PAGAR' : 'A RECEBER'} · ${escapeHtml(row.status)}</span><strong>${money(row.valor)}</strong><small>${Number(row.quantidade)} conta(s)</small></article>`).join('');
  document.querySelector('[data-finance-accounts]').innerHTML = data.contas.map((row) => `<tr><td>${row.tipo === 'pagar' ? 'A pagar' : 'A receber'}</td><td>${escapeHtml(row.descricao)}</td><td>${escapeHtml(row.contraparte ?? '—')}</td><td>${money(row.valor)}</td><td>${new Date(`${row.vencimento}T12:00:00`).toLocaleDateString('pt-BR')}</td><td><span class="status-pill">${escapeHtml(row.status)}</span></td><td>${row.status === 'aberta' ? `<button class="table-action" type="button" data-finance-settle="${Number(row.id)}">Baixar</button>` : '—'}</td></tr>`).join('');
}

async function loadInsights() {
  const { data } = await api('/api/v1/admin/insights');
  const root = document.querySelector('[data-insights]');
  root.innerHTML = data.insights.length ? data.insights.map((item) => `<article class="insight-card insight-${escapeHtml(item.prioridade)}"><span class="status-pill">${escapeHtml(item.prioridade)}</span><strong>${escapeHtml(item.resumo)}</strong>${Array.isArray(item.itens) ? `<ul>${item.itens.map((row) => `<li>${escapeHtml(row.nome ?? row.produto ?? row.descricao ?? '')}${row.sku ? ` · ${escapeHtml(row.sku)}` : ''}${row.quantidade !== undefined ? ` · ${Number(row.quantidade)} un.` : ''}</li>`).join('')}</ul>` : ''}</article>`).join('') : '<p class="muted">Nenhum alerta operacional neste momento.</p>';
}

async function loadErpOperations() {
  try {
    await Promise.all([loadWarehouses(), loadInventories(), loadFinance(), loadInsights()]);
  } catch (error) {
    document.querySelector('[data-warehouse-message]').textContent = error.message;
  }
}

async function loadAll() {
  try {
    await Promise.all([loadDashboard(), loadInventory(), loadOrders(), loadSuppliers(), loadUsers(), loadMovements(), loadCategories(), loadPurchases()]);
  } catch (error) {
    refreshLabel.textContent = error.message;
  }
}

const customRange = document.querySelector('[data-custom-range]');
period.addEventListener('change', () => {
  customRange.hidden = period.value !== 'custom';
  if (period.value === 'custom') {
    const today = new Date();
    const start = new Date(today);
    start.setDate(today.getDate() - 29);
    const localDate = (date) => new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    document.querySelector('[data-date-from]').value ||= localDate(start);
    document.querySelector('[data-date-to]').value ||= localDate(today);
  }
  loadDashboard();
});
for (const input of document.querySelectorAll('[data-date-from], [data-date-to]')) input.addEventListener('change', loadDashboard);
document.querySelector('[data-product-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-product-message]');
  try {
    await api('/api/v1/admin/produtos', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    message.textContent = 'Produto cadastrado. Registre uma entrada para disponibilizar estoque.';
    form.reset();
    await loadInventory();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-inventory]').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-stock]');
  if (!button) return;
  const row = button.closest('tr');
  const quantity = Number(row.querySelector('[aria-label="Quantidade"]').value);
  const tipo = row.querySelector('[data-stock-type]').value;
  const motivo = row.querySelector('[aria-label="Motivo da movimentação"]').value.trim();
  button.disabled = true;
  try {
    await api(`/api/v1/admin/estoque/${button.dataset.stock}`, { method: 'POST', body: JSON.stringify({ tipo, quantidade, motivo }) });
    await Promise.all([loadInventory(), loadDashboard(), loadMovements()]);
  } catch (error) { button.title = error.message; button.disabled = false; }
});

document.querySelector('[data-orders]').addEventListener('change', async (event) => {
  const select = event.target.closest('[data-order-status]');
  if (!select?.value) return;
  try {
    await api(`/api/v1/admin/pedidos/${select.dataset.orderStatus}/status`, { method: 'POST', body: JSON.stringify({ status: select.value }) });
    await Promise.all([loadOrders(), loadDashboard(), loadInventory()]);
  } catch (error) { select.title = error.message; }
});

document.querySelector('[data-inventory]').addEventListener('click', async (event) => {
  const deactivateButton = event.target.closest('[data-deactivate]');
  if (deactivateButton) {
    if (!window.confirm('Desativar este produto no catálogo?')) return;
    try {
      await api(`/api/v1/admin/produtos/${deactivateButton.dataset.deactivate}`, { method: 'DELETE' });
      await loadInventory();
    } catch (error) { deactivateButton.title = error.message; }
    return;
  }
  const button = event.target.closest('[data-price]');
  if (!button) return;
  const price = Number(button.closest('tr').querySelector('[aria-label="Preço rápido"]').value);
  if (!Number.isFinite(price) || price < 0) return;
  button.disabled = true;
  try {
    await api(`/api/v1/admin/produtos/${button.dataset.price}`, { method: 'PATCH', body: JSON.stringify({ preco: price }) });
    button.textContent = 'Salvo';
    window.setTimeout(() => { button.textContent = 'Preço'; button.disabled = false; }, 900);
  } catch (error) { button.title = error.message; button.disabled = false; }
});

document.querySelector('[data-supplier-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-supplier-message]');
  try {
    await api('/api/v1/admin/fornecedores', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    form.reset();
    message.textContent = 'Fornecedor cadastrado.';
    await loadSuppliers();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-category-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-category-message]');
  try {
    await api('/api/v1/admin/categorias', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    form.reset();
    message.textContent = 'Categoria criada.';
    await loadCategories();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-admin-categories]').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-category-toggle]');
  if (!button) return;
  try {
    await api(`/api/v1/admin/categorias/${button.dataset.categoryToggle}`, { method: 'PATCH', body: JSON.stringify({ ativo: button.dataset.active !== '1' }) });
    await loadCategories();
  } catch (error) { button.title = error.message; }
});

document.querySelector('[data-suppliers]').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-supplier-toggle]');
  if (!button) return;
  try {
    await api(`/api/v1/admin/fornecedores/${button.dataset.supplierToggle}`, { method: 'PATCH', body: JSON.stringify({ ativo: button.dataset.active !== '1' }) });
    await loadSuppliers();
  } catch (error) { button.title = error.message; }
});

document.querySelector('[data-purchase-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form));
  const message = document.querySelector('[data-purchase-message]');
  try {
    await api('/api/v1/admin/compras', { method: 'POST', body: JSON.stringify({ fornecedor_id: values.fornecedor_id, armazem_id: values.armazem_id, nota_fiscal: values.nota_fiscal, itens: [{ produto_id: values.produto_id, quantidade: values.quantidade, custo_unitario: values.custo_unitario, numero_lote: values.numero_lote, serie: values.serie, validade: values.validade }] }) });
    form.reset();
    message.textContent = 'Compra recebida e estoque atualizado.';
    await Promise.all([loadInventory(), loadDashboard(), loadMovements(), loadWarehouses(), loadFinance(), loadInsights()]);
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-refresh-warehouses]').addEventListener('click', () => loadWarehouses().catch((error) => { document.querySelector('[data-warehouse-message]').textContent = error.message; }));
document.querySelector('[data-stock-warehouse]').addEventListener('change', () => Promise.all([loadWarehouseStock(), loadLots()]).catch((error) => { document.querySelector('[data-warehouse-message]').textContent = error.message; }));
document.querySelector('[data-transfer-source]').addEventListener('change', () => loadWarehouseStock().catch((error) => { document.querySelector('[data-transfer-message]').textContent = error.message; }));
document.querySelector('[data-warehouse-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-warehouse-message]');
  try {
    await api('/api/v1/admin/armazens', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    form.reset();
    message.textContent = 'Armazém criado.';
    await loadWarehouses();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-transfer-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form));
  const message = document.querySelector('[data-transfer-message]');
  try {
    await api('/api/v1/admin/armazens/transferencias', {
      method: 'POST',
      body: JSON.stringify({ origem_id: values.origem_id, destino_id: values.destino_id, motivo: values.motivo, itens: [{ produto_id: values.produto_id, quantidade: values.quantidade }] }),
    });
    form.elements.quantidade.value = '';
    form.elements.motivo.value = '';
    message.textContent = 'Transferência concluída com rastreio dos lotes.';
    await Promise.all([loadWarehouses(), loadInventory(), loadMovements()]);
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-inventory-start]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-inventory-message]');
  try {
    const result = await api('/api/v1/admin/inventarios', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    message.textContent = `Inventário #${Number(result.data.id)} iniciado.`;
    form.elements.observacao.value = '';
    await loadInventories();
    document.querySelector('[data-inventory-select]').value = String(result.data.id);
    await loadInventoryItems();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-inventory-select]').addEventListener('change', () => loadInventoryItems().catch((error) => { document.querySelector('[data-inventory-message]').textContent = error.message; }));
document.querySelector('[data-inventory-items]').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-count-save]');
  if (!button) return;
  const inventoryId = document.querySelector('[data-inventory-select]').value;
  const input = document.querySelector(`[data-count-value="${button.dataset.countSave}"]`);
  try {
    await api(`/api/v1/admin/inventarios/${Number(inventoryId)}/itens/${Number(button.dataset.countSave)}`, {
      method: 'PATCH',
      body: JSON.stringify({ quantidade_contada: input.value }),
    });
    await loadInventoryItems();
    document.querySelector('[data-inventory-message]').textContent = 'Contagem salva.';
  } catch (error) { document.querySelector('[data-inventory-message]').textContent = error.message; }
});

document.querySelector('[data-inventory-complete]').addEventListener('click', async () => {
  const inventoryId = document.querySelector('[data-inventory-select]').value;
  const message = document.querySelector('[data-inventory-message]');
  if (!inventoryId || !window.confirm('Aplicar os ajustes de estoque desta contagem?')) return;
  try {
    await api(`/api/v1/admin/inventarios/${Number(inventoryId)}/concluir`, { method: 'POST', body: '{}' });
    message.textContent = 'Inventário aplicado; os saldos e movimentos foram atualizados.';
    await Promise.all([loadInventories(), loadWarehouseStock(), loadInventory(), loadMovements(), loadDashboard(), loadInsights()]);
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-finance-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-finance-message]');
  try {
    await api('/api/v1/admin/financeiro', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    form.reset();
    message.textContent = 'Conta financeira registrada.';
    await loadFinance();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-finance-accounts]').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-finance-settle]');
  if (!button) return;
  try {
    await api(`/api/v1/admin/financeiro/${Number(button.dataset.financeSettle)}/pagar`, { method: 'POST', body: '{}' });
    await Promise.all([loadFinance(), loadOrders(), loadDashboard()]);
  } catch (error) { button.title = error.message; }
});

document.querySelector('[data-refresh-finance]').addEventListener('click', () => loadFinance().catch((error) => { document.querySelector('[data-finance-message]').textContent = error.message; }));
document.querySelector('[data-refresh-insights]').addEventListener('click', () => loadInsights().catch((error) => { document.querySelector('[data-insights]').textContent = error.message; }));

document.querySelector('[data-export-lots]').addEventListener('click', async () => {
  const rows = (await api('/api/v1/admin/lotes')).data;
  exportData('lotes-nexustech.csv', rows.map((row) => [row.armazem, row.sku, row.produto, row.numero_lote, row.serie, row.quantidade, row.validade]), ['Armazém', 'SKU', 'Produto', 'Lote', 'Série', 'Quantidade', 'Validade']);
});

document.querySelector('[data-user-form]').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('[data-user-message]');
  try {
    await api('/api/v1/admin/usuarios', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form))) });
    form.reset();
    message.textContent = 'Usuário criado.';
    await loadUsers();
  } catch (error) { message.textContent = error.message; }
});

document.querySelector('[data-users]').addEventListener('click', async (event) => {
  const activeButton = event.target.closest('[data-user-active]');
  const resetButton = event.target.closest('[data-user-reset]');
  try {
    if (activeButton) {
      await api(`/api/v1/admin/usuarios/${activeButton.dataset.userActive}`, { method: 'PATCH', body: JSON.stringify({ ativo: activeButton.dataset.active !== '1' ? 1 : 0 }) });
      await loadUsers();
    }
    if (resetButton) {
      await api(`/api/v1/admin/usuarios/${resetButton.dataset.userReset}/recuperar-senha`, { method: 'POST', body: '{}' });
      resetButton.textContent = 'Link enviado';
    }
  } catch (error) {
    const button = activeButton ?? resetButton;
    if (button) button.title = error.message;
  }
});

document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-export]');
  if (!button) return;
  const canvas = document.querySelector(`[data-chart="${button.dataset.export}"]`);
  if (!canvas) return;
  const link = document.createElement('a');
  link.download = `nexustech-${button.dataset.export}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
});

document.querySelector('[data-export-products]').addEventListener('click', async () => {
  const rows = (await api('/api/v1/admin/produtos')).data;
  exportData('produtos-nexustech.csv', rows.map((row) => [row.sku, row.nome, row.categoria, row.custo, row.preco, row.estoque, row.estoque_minimo, row.ativo]), ['SKU', 'Produto', 'Categoria', 'Custo', 'Preço', 'Estoque', 'Mínimo', 'Ativo']);
});
document.querySelector('[data-export-orders]').addEventListener('click', async () => {
  const rows = await fetchAllPages('/api/v1/pedidos');
  exportData('pedidos-nexustech.csv', rows.map((row) => [row.id, row.cliente, row.status, row.total, row.created_at]), ['Pedido', 'Cliente', 'Status', 'Total', 'Data']);
});

document.querySelector('[data-export-suppliers]').addEventListener('click', async () => {
  const rows = (await api('/api/v1/admin/fornecedores')).data;
  exportData('fornecedores-nexustech.csv', rows.map((row) => [row.nome, row.documento, row.email, row.telefone, row.ativo]), ['Nome', 'Documento', 'E-mail', 'Telefone', 'Ativo']);
});

document.querySelector('[data-export-users]').addEventListener('click', async () => {
  const rows = await fetchAllPages('/api/v1/admin/usuarios');
  exportData('usuarios-nexustech.csv', rows.map((row) => [row.nome, row.email, row.role, row.ativo, row.created_at]), ['Nome', 'E-mail', 'Perfil', 'Ativo', 'Cadastro']);
});

document.querySelector('[data-export-movements]').addEventListener('click', async () => {
  const rows = await fetchAllPages('/api/v1/admin/estoque/movimentacoes');
  exportData('movimentacoes-nexustech.csv', rows.map((row) => [row.created_at, row.produto, row.sku, row.armazem, row.numero_lote, row.serie, row.tipo, row.quantidade, row.motivo, row.usuario]), ['Data', 'Produto', 'SKU', 'Armazém', 'Lote', 'Série', 'Tipo', 'Quantidade', 'Motivo', 'Operador']);
});

document.querySelector('[data-export-categories]').addEventListener('click', async () => {
  const rows = (await api('/api/v1/admin/categorias')).data;
  exportData('categorias-nexustech.csv', rows.map((row) => [row.nome, row.slug, row.descricao, row.ativo]), ['Nome', 'Slug', 'Descrição', 'Ativo']);
});

document.querySelector('[data-export-purchases]').addEventListener('click', async () => {
  const rows = await fetchAllPages('/api/v1/admin/compras');
  exportData('compras-nexustech.csv', rows.map((row) => [row.id, row.fornecedor, row.nota_fiscal, row.total, row.operador, row.created_at]), ['Compra', 'Fornecedor', 'Nota fiscal', 'Total', 'Operador', 'Data']);
});

document.querySelector('[data-logout]').addEventListener('click', async () => {
  await api('/api/v1/auth/logout', { method: 'POST', body: '{}' });
  window.location.assign(document.body.dataset.basePath || '/');
});

loadAll();
loadErpOperations();
window.setInterval(loadAll, 30000);
window.setInterval(loadErpOperations, 60000);