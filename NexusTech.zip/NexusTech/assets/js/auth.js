import { api, appPath } from './api-client.js';

const form = document.querySelector('[data-auth-form]');
const message = document.querySelector('[data-form-message]');

form?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = form.querySelector('[type="submit"]');
  submit.disabled = true;
  message.textContent = 'Validando seus dados...';
  const data = Object.fromEntries(new FormData(form));
  try {
    const result = await api(form.dataset.endpoint, { method: 'POST', body: JSON.stringify(data) });
    if (result.data?.csrf) window.location.assign(appPath(result.data.user.role === 'admin' ? 'admin' : 'meus-pedidos'));
    else message.textContent = result.data?.message ?? 'Se os dados estiverem cadastrados, enviaremos instruções.';
  } catch (error) {
    message.textContent = error.message;
  } finally {
    submit.disabled = false;
  }
});