import { api, appPath } from './api-client.js';

const profileForm = document.querySelector('[data-profile-form]');
const addressForm = document.querySelector('[data-address-form]');
const addressList = document.querySelector('[data-address-list]');

document.querySelector('[data-logout]')?.addEventListener('click', async () => {
  await api('/api/v1/auth/logout', { method: 'POST', body: '{}' });
  window.location.assign(appPath(''));
});

if (profileForm) {
  const profile = (await api('/api/v1/conta')).data;
  profileForm.elements.nome.value = profile.nome;
  profileForm.elements.email.value = profile.email;
  profileForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const message = document.querySelector('[data-profile-message]');
    try {
      await api('/api/v1/conta', { method: 'PATCH', body: JSON.stringify(Object.fromEntries(new FormData(profileForm))) });
      message.textContent = 'Perfil atualizado.';
    } catch (error) { message.textContent = error.message; }
  });
}

async function loadAddresses() {
  if (!addressList) return;
  const addresses = (await api('/api/v1/enderecos')).data;
  addressList.innerHTML = addresses.length ? addresses.map((address) => `<article class="order-card"><h3>${escapeHtml(address.apelido)}</h3><p class="muted">${escapeHtml(address.destinatario)} · ${escapeHtml(address.logradouro)}, ${escapeHtml(address.numero)} · ${escapeHtml(address.bairro)}, ${escapeHtml(address.cidade)} - ${escapeHtml(address.estado)} · ${escapeHtml(address.cep)}</p><button class="button-small" type="button" data-delete-address="${Number(address.id)}">Remover</button></article>`).join('') : '<p class="muted">Nenhum endereço salvo.</p>';
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char]);
}

addressForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = document.querySelector('[data-address-message]');
  try {
    await api('/api/v1/enderecos', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(addressForm))) });
    addressForm.reset();
    message.textContent = 'Endereço salvo.';
    await loadAddresses();
  } catch (error) { message.textContent = error.message; }
});

addressList?.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-delete-address]');
  if (!button) return;
  try {
    await api(`/api/v1/enderecos/${button.dataset.deleteAddress}`, { method: 'DELETE' });
    await loadAddresses();
  } catch (error) { button.title = error.message; }
});

if (addressList) loadAddresses().catch((error) => { addressList.textContent = error.message; });