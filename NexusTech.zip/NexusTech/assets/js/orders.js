import { api, escapeHtml, money } from './api-client.js';

const root = document.querySelector('[data-order-list]');
const statuses = ['pendente', 'pago', 'separado', 'enviado', 'entregue'];

async function load() {
  try {
    const orders = (await api('/api/v1/pedidos')).data;
    root.innerHTML = orders.length ? orders.map((order) => {
      const current = statuses.indexOf(order.status);
      const timeline = statuses.map((status, index) => `<span class="status-pill ${index <= current ? 'is-complete' : 'is-upcoming'}">${status}</span>`).join(' ');
      return `<article class="order-card"><h3>Pedido #${Number(order.id)} <span class="status-pill">${escapeHtml(order.status)}</span></h3><p class="muted">${new Date(order.created_at).toLocaleString('pt-BR')} · ${money(order.total)}</p><div class="toolbar">${timeline}</div>${['pendente', 'pago'].includes(order.status) ? `<p><button class="button-small" type="button" data-cancel="${Number(order.id)}">Cancelar pedido</button></p>` : ''}</article>`;
    }).join('') : '<p class="muted">Você ainda não possui pedidos.</p>';
  } catch (error) {
    root.textContent = error.message;
  }
}

root.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-cancel]');
  if (!button) return;
  button.disabled = true;
  try {
    await api(`/api/v1/pedidos/${button.dataset.cancel}/cancelar`, { method: 'POST', body: '{}' });
    await load();
  } catch (error) {
    button.disabled = false;
    button.textContent = error.message;
  }
});

load();