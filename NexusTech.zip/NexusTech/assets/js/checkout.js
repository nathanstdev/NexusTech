import { api, appPath, escapeHtml, money } from './api-client.js';

const key = 'nexus-cart-v1';
const cartNode = document.querySelector('[data-checkout-items]');
const form = document.querySelector('[data-checkout-form]');
const message = document.querySelector('[data-checkout-message]');
const cartMessage = document.querySelector('[data-cart-message]');
const stepPanels = [...form.querySelectorAll('[data-checkout-step]')];
const stepIndicators = [...document.querySelectorAll('[data-step-indicator]')];
let coupon = '';
let savedAddresses = [];
let currentStep = 1;
let cartAvailable = false;

function cart() {
  try {
    const stored = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(stored)
      ? stored.filter((item) => item && typeof item === 'object'
        && Number.isSafeInteger(Number(item.produto_id))
        && Number(item.produto_id) > 0
        && Number.isSafeInteger(Number(item.quantidade))
        && Number(item.quantidade) > 0
        && Number(item.quantidade) <= 100)
      : [];
  } catch {
    return [];
  }
}

function subtotal() {
  return cart().reduce((sum, item) => sum + Number(item.preco) * Number(item.quantidade), 0);
}

function showStep(step) {
  currentStep = step;
  for (const panel of stepPanels) panel.hidden = Number(panel.dataset.checkoutStep) !== step;
  for (const indicator of stepIndicators) {
    const active = Number(indicator.dataset.stepIndicator) === step;
    if (active) indicator.setAttribute('aria-current', 'step');
    else indicator.removeAttribute('aria-current');
  }
  if (step === 3) updateReviewSummary();
  stepPanels.find((panel) => Number(panel.dataset.checkoutStep) === step)?.querySelector('h2')?.focus({ preventScroll: true });
}

function updateReviewSummary() {
  const values = Object.fromEntries(new FormData(form));
  const address = [
    values.destinatario,
    `${values.logradouro}, ${values.numero}`,
    values.complemento,
    values.bairro,
    `${values.cidade} - ${values.estado}`,
    values.cep,
  ].filter(Boolean).join(', ');
  document.querySelector('[data-review-address]').textContent = address;
  const paymentLabels = { pix: 'Pix (simulado)', cartao: 'Cartão (simulado)', boleto: 'Boleto (simulado)' };
  document.querySelector('[data-review-payment]').textContent = paymentLabels[values.pagamento] ?? '—';
}

function clearCoupon() {
  coupon = '';
  window.discount = 0;
  document.querySelector('[data-discount]').textContent = money(0);
  document.querySelector('[data-coupon-message]').textContent = '';
}

function render() {
  const items = cart();
  const submitButton = form.querySelector('[type="submit"]');
  if (!items.length) {
    cartNode.innerHTML = `<p class="muted">Seu carrinho está vazio. <a href="${appPath()}">Explorar produtos</a></p>`;
    submitButton.disabled = true;
    for (const button of form.querySelectorAll('[data-step-next]')) button.disabled = true;
    document.querySelector('[data-subtotal]').textContent = money(0);
    document.querySelector('[data-shipping]').textContent = money(0);
    document.querySelector('[data-total]').textContent = money(0);
    cartMessage.textContent = '';
    return;
  }

  cartAvailable = items.every((item) => Number(item.estoque) >= Number(item.quantidade));
  cartNode.innerHTML = items.map((item) => `
    <article class="order-card checkout-item">
      <h3>${escapeHtml(item.nome)}</h3>
      <div class="product-meta">
        <span>${Number(item.quantidade)} × ${money(item.preco)}</span>
        <button class="button-small" type="button" data-remove="${Number(item.produto_id)}">Remover</button>
      </div>
      ${Number(item.estoque) < Number(item.quantidade) ? '<p class="form-message">Estoque insuficiente para esta quantidade.</p>' : ''}
    </article>`).join('');
  const totalItems = subtotal();
  const shipping = totalItems >= 500 ? 0 : 19.9;
  document.querySelector('[data-subtotal]').textContent = money(totalItems);
  document.querySelector('[data-shipping]').textContent = shipping === 0 ? 'Grátis' : money(shipping);
  document.querySelector('[data-total]').textContent = money(totalItems + shipping - Number(window.discount ?? 0));
  submitButton.disabled = !cartAvailable;
  for (const button of form.querySelectorAll('[data-step-next]')) button.disabled = !cartAvailable;
  if (!cartAvailable) {
    cartMessage.textContent = 'Revise a disponibilidade dos produtos antes de continuar.';
  } else cartMessage.textContent = '';
}

form.addEventListener('click', (event) => {
  const next = event.target.closest('[data-step-next]');
  const back = event.target.closest('[data-step-back]');
  if (next) {
    const currentPanel = stepPanels.find((panel) => Number(panel.dataset.checkoutStep) === currentStep);
    const invalid = [...currentPanel.querySelectorAll('input, select, textarea')].find((field) => !field.checkValidity());
    if (invalid) {
      invalid.reportValidity();
      return;
    }
    if (!cartAvailable) {
      message.textContent = 'Há itens sem estoque suficiente. Revise seu carrinho.';
      return;
    }
    message.textContent = '';
    showStep(Number(next.dataset.stepNext));
  } else if (back) {
    message.textContent = '';
    showStep(Number(back.dataset.stepBack));
  }
});

cartNode.addEventListener('click', (event) => {
  const button = event.target.closest('[data-remove]');
  if (!button) return;
  localStorage.setItem(key, JSON.stringify(cart().filter((item) => item.produto_id !== Number(button.dataset.remove))));
  clearCoupon();
  render();
});

document.querySelector('[data-saved-address]').addEventListener('change', (event) => {
  const address = savedAddresses.find((item) => Number(item.id) === Number(event.target.value));
  for (const field of ['destinatario', 'cep', 'logradouro', 'numero', 'complemento', 'bairro', 'cidade', 'estado']) {
    form.elements[field].value = address?.[field] ?? '';
  }
});

document.querySelector('[data-apply-coupon]').addEventListener('click', async () => {
  const code = document.querySelector('[data-coupon]').value.trim();
  const output = document.querySelector('[data-coupon-message]');
  try {
    const result = await api('/api/v1/cupons/validar', {
      method: 'POST',
      body: JSON.stringify({ codigo: code, subtotal: subtotal() }),
    });
    coupon = code;
    window.discount = Number(result.data.desconto);
    document.querySelector('[data-discount]').textContent = `-${money(window.discount)}`;
    output.textContent = 'Cupom aplicado.';
    render();
  } catch (error) {
    clearCoupon();
    output.textContent = error.message;
    render();
  }
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!cart().length || !cartAvailable) return;
  const button = form.querySelector('[type="submit"]');
  button.disabled = true;
  message.textContent = 'Confirmando pedido e reservando os produtos...';
  const values = Object.fromEntries(new FormData(form));
  const { pagamento, ...endereco } = values;
  try {
    const result = await api('/api/v1/pedidos', {
      method: 'POST',
      body: JSON.stringify({
        itens: cart().map(({ produto_id, quantidade }) => ({ produto_id, quantidade })),
        endereco,
        pagamento,
        cupom: coupon,
      }),
    });
    localStorage.removeItem(key);
    window.location.assign(`${appPath('meus-pedidos')}?pedido=${result.data.id}`);
  } catch (error) {
    message.textContent = error.message;
    button.disabled = false;
  }
});

async function loadCartProducts() {
  const items = cart();
  if (!items.length) {
    render();
    return;
  }
  try {
    const refreshed = await Promise.all(items.map(async (item) => {
      const { data } = await api(`/api/v1/produtos/${Number(item.produto_id)}`);
      return { ...item, nome: data.nome, preco: Number(data.preco), estoque: Number(data.estoque) };
    }));
    localStorage.setItem(key, JSON.stringify(refreshed));
    render();
  } catch (error) {
    render();
    cartAvailable = false;
    message.textContent = `Não foi possível validar os produtos do carrinho: ${error.message}`;
    cartMessage.textContent = `Não foi possível validar o carrinho: ${error.message}`;
    for (const button of form.querySelectorAll('[data-step-next], [type="submit"]')) button.disabled = true;
  }
}

render();
showStep(1);
loadCartProducts();
api('/api/v1/enderecos').then(({ data }) => {
  savedAddresses = data;
  document.querySelector('[data-saved-address]').insertAdjacentHTML(
    'beforeend',
    data.map((address) => `<option value="${Number(address.id)}">${escapeHtml(address.apelido)} · ${escapeHtml(address.cidade)}</option>`).join(''),
  );
}).catch((error) => {
  document.querySelector('[data-address-message]').textContent = `Endereços salvos indisponíveis: ${error.message}`;
});
