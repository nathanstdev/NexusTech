const header = document.querySelector('[data-site-header]');

if (header) {
  const nav = header.querySelector('[data-primary-nav]');
  const menuButton = header.querySelector('[data-menu-toggle]');
  const progress = header.querySelector('[data-reading-progress]');
  const pill = header.querySelector('[data-nav-pill]');
  const links = [...(nav?.querySelectorAll('[data-nav-link]') ?? [])];
  const desktop = window.matchMedia('(min-width: 821px)');
  let menuOpen = false;
  let framePending = false;
  let previousScrollY = window.scrollY;

  function activeLink() {
    return links.find((link) => link.getAttribute('aria-current') === 'page') ?? null;
  }

  function movePill(link) {
    if (!pill || !nav || !link) {
      if (pill) pill.style.opacity = '0';
      return;
    }
    const index = links.indexOf(link);
    if (index < 0) return;
    pill.style.opacity = '1';
    pill.style.transform = desktop.matches
      ? `translate3d(${index * 100}%, 0, 0)`
      : `translate3d(0, ${index * 44}px, 0)`;
  }

  function closeMenu(restoreFocus = false) {
    menuOpen = false;
    header.classList.remove('menu-open');
    menuButton?.setAttribute('aria-expanded', 'false');
    menuButton?.setAttribute('aria-label', 'Abrir menu');
    if (!desktop.matches && nav) nav.hidden = true;
    if (restoreFocus) menuButton?.focus();
  }

  function syncMenu() {
    if (!nav) return;
    if (desktop.matches) {
      if (pill && links.length) pill.style.width = `${100 / links.length}%`;
      nav.hidden = false;
      header.classList.remove('menu-open');
      menuOpen = false;
      menuButton?.setAttribute('aria-expanded', 'false');
    } else {
      pill?.style.removeProperty('width');
      nav.hidden = !menuOpen;
      if (!menuOpen) closeMenu();
    }
    requestAnimationFrame(() => movePill(activeLink()));
  }

  function updateScrollState() {
    framePending = false;
    const currentScrollY = window.scrollY;
    const scrollRange = document.documentElement.scrollHeight - window.innerHeight;
    const ratio = scrollRange > 0 ? Math.min(1, Math.max(0, currentScrollY / scrollRange)) : 0;
    if (progress) progress.style.transform = `scaleX(${ratio})`;

    header.classList.toggle('is-scrolled', currentScrollY > 12);
    if (currentScrollY < 24 || menuOpen || currentScrollY < previousScrollY - 6) {
      header.classList.remove('is-hidden');
    } else if (currentScrollY > previousScrollY + 6 && currentScrollY > header.offsetHeight) {
      header.classList.add('is-hidden');
    }
    previousScrollY = currentScrollY;
  }

  function scheduleScrollUpdate() {
    if (framePending) return;
    framePending = true;
    requestAnimationFrame(updateScrollState);
  }

  header.classList.add('navbar-enhanced');
  syncMenu();
  scheduleScrollUpdate();
  window.addEventListener('scroll', scheduleScrollUpdate, { passive: true });
  window.addEventListener('resize', syncMenu, { passive: true });
  desktop.addEventListener?.('change', syncMenu);

  menuButton?.addEventListener('click', () => {
    menuOpen = !menuOpen;
    header.classList.toggle('menu-open', menuOpen);
    menuButton.setAttribute('aria-expanded', String(menuOpen));
    menuButton.setAttribute('aria-label', menuOpen ? 'Fechar menu' : 'Abrir menu');
    nav.hidden = !menuOpen;
    if (menuOpen) {
      header.classList.remove('is-hidden');
      requestAnimationFrame(() => movePill(activeLink()));
    }
  });

  nav?.addEventListener('pointerover', (event) => {
    const link = event.target.closest('[data-nav-link]');
    if (link) movePill(link);
  });
  nav?.addEventListener('pointerleave', () => movePill(activeLink()));
  nav?.addEventListener('focusin', (event) => {
    const link = event.target.closest('[data-nav-link]');
    if (link) movePill(link);
  });
  nav?.addEventListener('focusout', (event) => {
    if (!nav.contains(event.relatedTarget)) movePill(activeLink());
  });
  nav?.addEventListener('click', (event) => {
    if (event.target.closest('[data-nav-link]') && !desktop.matches) closeMenu();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && menuOpen) closeMenu(true);
  });
}
