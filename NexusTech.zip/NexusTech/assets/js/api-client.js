const basePath = document.body.dataset.basePath ?? '';
let csrfToken;
const themeKey = 'nexus-theme-choice-v1';
let savedTheme = null;
try {
  const storedTheme = localStorage.getItem(themeKey);
  const previousTheme = localStorage.getItem('nexus-theme');
  if (storedTheme === 'light' || storedTheme === 'dark') savedTheme = storedTheme;
  else if (previousTheme === 'light' || previousTheme === 'dark') savedTheme = previousTheme;
} catch {}

const colorPreference = window.matchMedia('(prefers-color-scheme: light)');
let themeChoiceIsSaved = savedTheme !== null;

function applyTheme(theme, saveChoice = true) {
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#08111b' : '#f2f7f5');
  if (saveChoice) {
    themeChoiceIsSaved = true;
    try { localStorage.setItem(themeKey, theme); } catch {}
  }
  document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
    const label = button.querySelector('[data-theme-label]');
    const icon = button.querySelector('[data-theme-icon]');
    if (label) label.textContent = theme === 'dark' ? 'Tema claro' : 'Tema escuro';
    else button.textContent = theme === 'dark' ? 'Tema claro' : 'Tema escuro';
    if (icon) icon.textContent = theme === 'dark' ? '☼' : '◐';
    button.setAttribute('aria-label', `Alternar tema. Tema atual: ${theme === 'dark' ? 'escuro' : 'claro'}. Atalho: T.`);
    button.setAttribute('aria-pressed', String(theme === 'light'));
  });
}

applyTheme(savedTheme ?? (colorPreference.matches ? 'light' : 'dark'), false);
const header = document.querySelector('.site-header');
if (header && !header.querySelector('[data-theme-toggle]')) {
  const button = document.createElement('button');
  button.className = 'icon-button theme-toggle';
  button.type = 'button';
  button.dataset.themeToggle = '';
  button.title = 'Alternar tema (T)';
  button.innerHTML = '<span class="theme-icon" data-theme-icon aria-hidden="true"></span><span data-theme-label></span>';
  header.insertBefore(button, header.lastElementChild);
  applyTheme(document.documentElement.dataset.theme);
}

document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
  if (button.dataset.themeBound) return;
  button.dataset.themeBound = 'true';
  button.addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
});

colorPreference.addEventListener?.('change', (event) => {
  if (!themeChoiceIsSaved) applyTheme(event.matches ? 'light' : 'dark', false);
});

document.addEventListener('keydown', (event) => {
  if (event.key.toLowerCase() !== 't' || event.ctrlKey || event.metaKey || event.altKey) return;
  if (event.target.closest('input, textarea, select, [contenteditable="true"], dialog[open]')) return;
  event.preventDefault();
  applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
});

function setBagCount(value) {
  const count = Math.max(0, Math.floor(Number(value) || 0));
  document.querySelectorAll('[data-cart-count]').forEach((node) => {
    if (node.textContent !== String(count)) {
      node.textContent = String(count);
      node.classList.remove('bag-count-pop');
      void node.offsetWidth;
      node.classList.add('bag-count-pop');
    }
  });
  document.querySelectorAll('[data-bag-link]').forEach((link) => {
    link.setAttribute('aria-label', `Sacola de compras, ${count} ${count === 1 ? 'item' : 'itens'}`);
  });
}

window.NexusBag = Object.freeze({ set: setBagCount });
try {
  const storedCart = JSON.parse(localStorage.getItem('nexus-cart-v1') ?? '[]');
  setBagCount(storedCart.reduce((total, item) => total + (Number(item.quantidade) || 0), 0));
} catch { setBagCount(0); }

const toastRegion = document.createElement('div');
toastRegion.className = 'toast-region';
toastRegion.setAttribute('role', 'status');
toastRegion.setAttribute('aria-live', 'polite');
document.body.append(toastRegion);

export function notify(message) {
  toastRegion.textContent = message;
  toastRegion.classList.add('toast-visible');
  window.clearTimeout(notify.timeout);
  notify.timeout = window.setTimeout(() => toastRegion.classList.remove('toast-visible'), 2400);
}

const commandDialog = document.createElement('dialog');
commandDialog.className = 'command-dialog';
commandDialog.setAttribute('aria-labelledby', 'command-label');
commandDialog.innerHTML = '<form method="dialog"><label id="command-label" for="command-input">Busca rápida</label><input id="command-input" class="field" type="search" placeholder="Buscar uma ação" autocomplete="off"><div class="command-results" data-command-results></div><button class="button-small" value="close">Fechar</button></form>';
document.body.append(commandDialog);
const commandInput = commandDialog.querySelector('#command-input');
const commandResults = commandDialog.querySelector('[data-command-results]');
const adminContext = window.location.pathname.startsWith(`${basePath}/admin`);
const commands = [
  { label: 'Ir para a loja', path: '' },
  { label: 'Abrir catálogo', path: '#catalogo' },
  { label: 'Minha conta', path: 'conta' },
  { label: 'Meus pedidos', path: 'meus-pedidos' },
  { label: 'Finalizar compra', path: 'checkout' },
  ...(adminContext ? [
    { label: 'Visão geral ERP', path: 'admin' },
    { label: 'Gerenciar estoque', path: 'admin#estoque' },
    { label: 'Ver pedidos', path: 'admin#pedidos' },
    { label: 'Cadastrar produto', action: () => document.querySelector('[data-product-form]')?.elements.nome.focus() },
  ] : []),
];

function renderCommands() {
  const query = commandInput.value.trim().toLocaleLowerCase('pt-BR');
  commandResults.replaceChildren();
  commands.filter((command) => command.label.toLocaleLowerCase('pt-BR').includes(query)).forEach((command) => {
    const button = document.createElement('button');
    button.className = 'command-item';
    button.type = 'button';
    button.textContent = command.label;
    button.addEventListener('click', () => {
      commandDialog.close();
      if (command.action) command.action();
      else window.location.assign(appPath(command.path));
    });
    commandResults.append(button);
  });
}

document.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    commandDialog.showModal();
    commandInput.value = '';
    renderCommands();
    commandInput.focus();
  }
});
commandInput.addEventListener('input', renderCommands);

export async function api(path, options = {}) {
  const method = (options.method ?? 'GET').toUpperCase();
  const headers = new Headers(options.headers ?? {});
  headers.set('Accept', 'application/json');
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    csrfToken ??= (await api('/api/v1/csrf')).data.token;
    headers.set('X-CSRF-Token', csrfToken);
  }
  const response = await fetch(`${basePath}${path}`, { ...options, method, headers, credentials: 'same-origin' });
  const contentType = response.headers.get('content-type') ?? '';
  if (!contentType.includes('application/json')) {
    throw new Error(`O servidor retornou uma resposta inválida (HTTP ${response.status}).`);
  }
  const payload = await response.json();
  if (!response.ok || payload.success === false) throw new Error(payload.error?.message ?? 'Não foi possível concluir a operação.');
  return payload;
}

export function appPath(path) {
  return `${basePath}/${path.replace(/^\//, '')}`;
}

export function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char]);
}

export function money(value) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value));
}