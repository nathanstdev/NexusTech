<?php
declare(strict_types=1);

$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$projectRoot = dirname(__DIR__);
$assetPrefix = '/assets/';
$staticFiles = ['/manifest.webmanifest', '/service-worker.js'];
$isPublicAsset = str_starts_with($path, $assetPrefix) || in_array($path, $staticFiles, true);

if ($isPublicAsset) {
    $file = realpath($projectRoot . $path);
    $assetRoot = realpath($projectRoot . '/assets');
    $isAsset = $file !== false && $assetRoot !== false && str_starts_with($file, $assetRoot . DIRECTORY_SEPARATOR);
    $isRootStatic = in_array($path, $staticFiles, true) && $file !== false && str_starts_with($file, $projectRoot . DIRECTORY_SEPARATOR);
    if (($isAsset || $isRootStatic) && is_file($file)) {
        return false;
    }
    http_response_code(404);
    return true;
}

require $projectRoot . '/index.php';