<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Database;

$db = Database::connection();
$db->prepare('CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(190) PRIMARY KEY, applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4')->execute();
$files = glob(dirname(__DIR__) . '/database/[0-9][0-9][0-9]_*.sql') ?: [];
sort($files, SORT_STRING);
$appliedQuery = $db->prepare('SELECT name FROM schema_migrations');
$appliedQuery->execute();
$applied = array_fill_keys($appliedQuery->fetchAll(PDO::FETCH_COLUMN), true);

foreach ($files as $file) {
    $name = basename($file);
    if (isset($applied[$name])) {
        printf("Já aplicada: %s\n", $name);
        continue;
    }

    $sql = file_get_contents($file);
    if ($sql === false) {
        throw new RuntimeException("Não foi possível ler {$name}.");
    }
    try {
        foreach (preg_split('/;\s*/', $sql) ?: [] as $statement) {
            $statement = trim($statement);
            if ($statement === '') {
                continue;
            }

            if (preg_match('/^ALTER\s+TABLE\s+([a-zA-Z0-9_]+)\s+ADD\s+COLUMN\s+([a-zA-Z0-9_]+)/i', $statement, $alterColumn) === 1) {
                $columnExists = $db->prepare(
                    'SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table AND COLUMN_NAME = :column'
                );
                $columnExists->execute(['table' => $alterColumn[1], 'column' => $alterColumn[2]]);
                if ($columnExists->fetchColumn()) {
                    printf("Coluna já existe, ignorando: %s.%s (%s)\n", $alterColumn[1], $alterColumn[2], $name);
                    continue;
                }
            }

            if (preg_match('/^ALTER\s+TABLE\s+([a-zA-Z0-9_]+)\s+ADD\s+CONSTRAINT\s+([a-zA-Z0-9_]+)/i', $statement, $alterConstraint) === 1) {
                $constraintExists = $db->prepare(
                    'SELECT 1 FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = :table AND CONSTRAINT_NAME = :constraint'
                );
                $constraintExists->execute(['table' => $alterConstraint[1], 'constraint' => $alterConstraint[2]]);
                if ($constraintExists->fetchColumn()) {
                    printf("Restrição já existe, ignorando: %s.%s (%s)\n", $alterConstraint[1], $alterConstraint[2], $name);
                    continue;
                }
            }

            $db->prepare($statement)->execute();
        }
        $record = $db->prepare('INSERT INTO schema_migrations (name) VALUES (:name)');
        $record->execute(['name' => $name]);
        printf("Aplicada: %s\n", $name);
    } catch (Throwable $error) {
        throw new RuntimeException("Falha na migration {$name}: {$error->getMessage()}", 0, $error);
    }
}