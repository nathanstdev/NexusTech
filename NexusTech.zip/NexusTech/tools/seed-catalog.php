<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Database;

$db = Database::connection();
$categories = [
    ['Placas de vídeo', 'placas-de-video'],
    ['Processadores', 'processadores'],
    ['Memórias', 'memorias'],
    ['Armazenamento', 'armazenamento'],
    ['Placas-mãe', 'placas-mae'],
    ['Fontes', 'fontes'],
    ['Gabinetes', 'gabinetes'],
    ['Refrigeração', 'refrigeracao'],
    ['Monitores', 'monitores'],
    ['Teclados', 'teclados'],
    ['Mouses', 'mouses'],
    ['Headsets', 'headsets'],
    ['Notebooks', 'notebooks'],
];
$categoryInsert = $db->prepare('INSERT IGNORE INTO categorias (nome, slug, descricao) VALUES (:name, :slug, :description)');
foreach ($categories as [$name, $slug]) {
    $categoryInsert->execute(['name' => $name, 'slug' => $slug, 'description' => 'Produtos de ' . mb_strtolower($name) . ' para seu setup.']);
}

$products = [
    ['NT-GPU-101', 'GeForce RTX 5070 Nova', 'Placa de vídeo para jogos em alta resolução e criação de conteúdo.', 'placas-de-video', 3899.00, 5299.90, 8],
    ['NT-GPU-102', 'Radeon RX 9060 XT Pulse', 'GPU com arquitetura atual e refrigeração de duas ventoinhas.', 'placas-de-video', 2499.00, 3499.90, 12],
    ['NT-CPU-201', 'Ryzen 7 9700X', 'Processador de oito núcleos para jogos e produtividade.', 'processadores', 1750.00, 2399.90, 10],
    ['NT-CPU-202', 'Core Ultra 7 265K', 'Processador desbloqueado para desktops de alto desempenho.', 'processadores', 2100.00, 2899.90, 7],
    ['NT-RAM-301', 'Memória DDR5 16 GB 6000 MHz', 'Módulo DDR5 com dissipador térmico para plataformas atuais.', 'memorias', 210.00, 329.90, 24],
    ['NT-SSD-401', 'SSD NVMe 1 TB Gen4', 'Armazenamento M.2 PCIe 4.0 para sistema e jogos.', 'armazenamento', 280.00, 429.90, 20],
    ['NT-MB-501', 'Placa-mãe B850 Wi-Fi', 'Placa AM5 com Wi-Fi integrado, DDR5 e slots M.2.', 'placas-mae', 1050.00, 1499.90, 6],
    ['NT-PSU-601', 'Fonte 750 W 80 Plus Gold', 'Fonte modular com eficiência Gold para GPUs atuais.', 'fontes', 590.00, 849.90, 9],
    ['NT-CASE-701', 'Gabinete Airflow Mesh', 'Gabinete mid tower com painel mesh e espaço para radiador.', 'gabinetes', 390.00, 599.90, 13],
    ['NT-COOL-801', 'Water Cooler 240 mm RGB', 'Refrigeração líquida AIO com radiador de 240 mm.', 'refrigeracao', 450.00, 699.90, 5],
    ['NT-MON-901', 'Monitor 27 pol. QHD 165 Hz', 'Painel IPS QHD com taxa de atualização de 165 Hz.', 'monitores', 1150.00, 1699.90, 8],
    ['NT-MON-902', 'Monitor 24 pol. Full HD 100 Hz', 'Monitor IPS compacto para trabalho e entretenimento.', 'monitores', 620.00, 899.90, 14],
    ['NT-KEY-1001', 'Teclado Mecânico TKL Aurora', 'Teclado compacto hot-swap com iluminação RGB configurável.', 'teclados', 240.00, 389.90, 18],
    ['NT-MOUSE-1101', 'Mouse Gamer 26000 DPI', 'Sensor óptico de alta precisão, seis botões e cabo leve.', 'mouses', 145.00, 249.90, 22],
    ['NT-MOUSE-1102', 'Mouse sem fio Ergo', 'Formato ergonômico com conexão sem fio e bateria recarregável.', 'mouses', 180.00, 299.90, 16],
    ['NT-HEAD-1201', 'Headset USB Surround', 'Headset fechado com microfone removível e áudio virtual.', 'headsets', 220.00, 359.90, 11],
    ['NT-NB-1301', 'Notebook Creator 16', 'Notebook com tela 16 pol., SSD rápido e GPU dedicada.', 'notebooks', 5200.00, 6999.90, 4],
    ['NT-NB-1302', 'Notebook Pro 14', 'Notebook leve para desenvolvimento e produtividade móvel.', 'notebooks', 4100.00, 5599.90, 6],
    ['NT-SSD-402', 'SSD SATA 2 TB', 'SSD de 2 TB para expansão de armazenamento em desktops.', 'armazenamento', 390.00, 589.90, 15],
];

$categoryQuery = $db->prepare('SELECT id FROM categorias WHERE slug = :slug AND ativo = 1 LIMIT 1');
$insert = $db->prepare('INSERT IGNORE INTO produtos (categoria_id, fornecedor_id, sku, nome, descricao, custo, preco, estoque, estoque_minimo, imagem_url) VALUES (:category, 1, :sku, :name, :description, :cost, :price, :stock, 3, :image)');
$images = [
    'placas-de-video' => 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=900&q=80',
    'processadores' => 'https://images.unsplash.com/photo-1555617981-dac3880eac6e?auto=format&fit=crop&w=900&q=80',
    'memorias' => 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&w=900&q=80',
    'armazenamento' => 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?auto=format&fit=crop&w=900&q=80',
    'placas-mae' => 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80',
    'fontes' => 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=900&q=80',
    'gabinetes' => 'https://images.unsplash.com/photo-1587202372634-32705e3bf49c?auto=format&fit=crop&w=900&q=80',
    'refrigeracao' => 'https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=900&q=80',
    'monitores' => 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=900&q=80',
    'teclados' => 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80',
    'mouses' => 'https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=80',
    'headsets' => 'https://images.unsplash.com/photo-1599669454699-248893623440?auto=format&fit=crop&w=900&q=80',
    'notebooks' => 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80',
];

foreach ($products as [$sku, $name, $description, $slug, $cost, $price, $stock]) {
    $categoryQuery->execute(['slug' => $slug]);
    $categoryId = $categoryQuery->fetchColumn();
    if (!$categoryId) {
        throw new RuntimeException('Categoria ausente: ' . $slug);
    }
    $insert->execute([
        'category' => $categoryId,
        'sku' => $sku,
        'name' => $name,
        'description' => $description,
        'cost' => $cost,
        'price' => $price,
        'stock' => $stock,
        'image' => $images[$slug],
    ]);
}

$total = (int) $db->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1')->fetchColumn();
printf("Catálogo carregado. Produtos ativos: %d\n", $total);
