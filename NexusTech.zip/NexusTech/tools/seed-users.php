<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Database;

if (($_ENV['APP_ENV'] ?? 'local') !== 'local') {
    throw new RuntimeException('A criação de contas de teste só é permitida com APP_ENV=local.');
}

$accounts = [
    ['nome' => 'Administrador Nexus', 'email' => $_ENV['SEED_ADMIN_EMAIL'] ?? '', 'password' => $_ENV['SEED_ADMIN_PASSWORD'] ?? '', 'role' => 'admin'],
    ['nome' => 'Cliente de Teste', 'email' => $_ENV['SEED_CUSTOMER_EMAIL'] ?? '', 'password' => $_ENV['SEED_CUSTOMER_PASSWORD'] ?? '', 'role' => 'cliente'],
];
$db = Database::connection();
$statement = $db->prepare('INSERT INTO usuarios (nome, email, senha, role, ativo) VALUES (:name, :email, :password, :role, 1) ON DUPLICATE KEY UPDATE nome = VALUES(nome), senha = VALUES(senha), role = VALUES(role), ativo = 1');

foreach ($accounts as $account) {
    if (!filter_var($account['email'], FILTER_VALIDATE_EMAIL) || strlen($account['password']) < 12) {
        throw new RuntimeException('Configure e-mails válidos e senhas de teste com pelo menos 12 caracteres no .env.');
    }
    $statement->execute(['name' => $account['nome'], 'email' => $account['email'], 'password' => password_hash($account['password'], PASSWORD_ARGON2ID), 'role' => $account['role']]);
    printf("Conta local pronta: %s (%s)\n", $account['email'], $account['role']);
}