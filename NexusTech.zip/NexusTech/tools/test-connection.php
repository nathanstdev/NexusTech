<?php
declare(strict_types=1);

use App\Database;

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/app/bootstrap.php';

try {
    Database::connection()->query('SELECT 1')->fetchColumn();
    fwrite(STDOUT, "Conexão com o banco de dados estabelecida com sucesso.\n");
} catch (PDOException $error) {
    error_log(sprintf('[NexusTech] Teste de conexão ao banco falhou: %s', $error->getMessage()));
    fwrite(STDERR, "Não foi possível conectar ao banco. Verifique as configurações DB_* e se o servidor MySQL está acessível.\n");
    exit(1);
}
