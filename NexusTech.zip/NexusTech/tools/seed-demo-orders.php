<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require dirname(__DIR__) . '/app/bootstrap.php';

use App\Database;
use App\Services\OrderService;

if (($_ENV['APP_ENV'] ?? 'local') !== 'local') {
    throw new RuntimeException('Dados de demonstração só podem ser criados com APP_ENV=local.');
}

$db = Database::connection();
$customer = $db->prepare("SELECT id FROM usuarios WHERE email = :email AND role = 'cliente' AND ativo = 1");
$customer->execute(['email' => $_ENV['SEED_CUSTOMER_EMAIL'] ?? '']);
$customerId = filter_var($customer->fetchColumn(), FILTER_VALIDATE_INT);
if (!$customerId) {
    throw new RuntimeException('Execute tools/seed-users.php antes de criar pedidos de demonstração.');
}

$marker = $db->prepare("SELECT COUNT(*) FROM logs_auditoria WHERE entidade = 'seed' AND acao = 'demo_vendas_criadas'");
$marker->execute();
if ((int) $marker->fetchColumn() > 0) {
    fwrite(STDOUT, "Pedidos de demonstração já foram criados.\n");
    exit(0);
}

$productsQuery = $db->prepare("SELECT id FROM produtos WHERE ativo = 1 AND estoque > 0 AND sku IN ('NT-PC-001','NT-PER-014','NT-CMP-032','NT-CMP-041') ORDER BY id");
$productsQuery->execute();
$products = $productsQuery->fetchAll(PDO::FETCH_COLUMN);
if ($products === []) {
    throw new RuntimeException('Aplique as migrations com os produtos de exemplo antes de continuar.');
}

$service = new OrderService($db);
$updateOrder = $db->prepare("UPDATE pedidos SET status = 'pago', created_at = :created, updated_at = :updated WHERE id = :id");
$updateMovement = $db->prepare('UPDATE movimentacoes_estoque SET created_at = :created WHERE pedido_id = :id');
$updateReceivable = $db->prepare("UPDATE contas_financeiras SET status = 'paga', pago_em = :paid WHERE tipo = 'receber' AND origem_tipo = 'pedido' AND origem_id = :order");
$checkout = [
    'pagamento' => 'pix',
    'endereco' => ['destinatario' => 'Cliente de Teste', 'cep' => '01000-000', 'logradouro' => 'Rua Demonstração', 'numero' => '100', 'complemento' => '', 'bairro' => 'Centro', 'cidade' => 'São Paulo', 'estado' => 'SP'],
];

for ($day = 29; $day >= 0; $day--) {
    $productId = (int) $products[$day % count($products)];
    $orderId = $service->create($customerId, [['produto_id' => $productId, 'quantidade' => 1]], $checkout);
    $createdAt = (new DateTimeImmutable())->modify('-' . $day . ' days')->setTime(9 + ($day % 10), 15)->format('Y-m-d H:i:s');
    $updateOrder->execute(['created' => $createdAt, 'updated' => $createdAt, 'id' => $orderId]);
    $updateMovement->execute(['created' => $createdAt, 'id' => $orderId]);
    $updateReceivable->execute(['paid' => $createdAt, 'order' => $orderId]);
}

$audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, detalhes, ip) VALUES (:user, 'demo_vendas_criadas', 'seed', :details, '127.0.0.1')");
$audit->execute(['user' => $customerId, 'details' => json_encode(['pedidos' => 30, 'periodo_dias' => 30], JSON_THROW_ON_ERROR)]);
fwrite(STDOUT, "30 pedidos de demonstração foram criados para alimentar as análises.\n");