<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class OrderService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function create(int $userId, array $items, array $checkout = []): int
    {
        if ($items === [] || count($items) > 50) {
            throw new RuntimeException('O pedido deve conter entre 1 e 50 produtos.');
        }

        $quantities = [];
        foreach ($items as $item) {
            $id = filter_var($item['produto_id'] ?? null, FILTER_VALIDATE_INT);
            $quantity = filter_var($item['quantidade'] ?? null, FILTER_VALIDATE_INT);
            if (!$id || !$quantity || $quantity < 1 || $quantity > 100) {
                throw new RuntimeException('Itens do pedido inválidos.');
            }
            $quantities[$id] = ($quantities[$id] ?? 0) + $quantity;
            if ($quantities[$id] > 1000) {
                throw new RuntimeException('Quantidade máxima por produto excedida.');
            }
        }
        $payment = (string) ($checkout['pagamento'] ?? 'pix');
        if (!in_array($payment, ['pix', 'cartao', 'boleto'], true)) {
            throw new RuntimeException('Método de pagamento inválido.');
        }
        try {
            $address = sanitize_address(is_array($checkout['endereco'] ?? null) ? $checkout['endereco'] : []);
        } catch (\InvalidArgumentException $error) {
            throw new RuntimeException($error->getMessage(), 0, $error);
        }
        $shipping = 19.90;
        $couponCode = strtoupper(trim((string) ($checkout['cupom'] ?? '')));

        $this->db->beginTransaction();
        try {
            $warehouses = $this->db->query('SELECT id FROM armazens WHERE ativo = 1 ORDER BY id FOR UPDATE');
            if ($warehouses->fetchAll() === []) {
                throw new RuntimeException('Nenhum armazém ativo está disponível para atender o pedido.');
            }
            $ids = array_keys($quantities);
            sort($ids);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $statement = $this->db->prepare("SELECT id, nome, preco, custo, estoque FROM produtos WHERE id IN ($placeholders) AND ativo = 1 ORDER BY id FOR UPDATE");
            $statement->execute($ids);
            $products = $statement->fetchAll();
            if (count($products) !== count($ids)) {
                throw new RuntimeException('Um ou mais produtos não estão disponíveis.');
            }

            $total = 0.0;
            foreach ($products as $product) {
                $quantity = $quantities[(int) $product['id']];
                if ((int) $product['estoque'] < $quantity) {
                    throw new RuntimeException('Estoque insuficiente para ' . $product['nome'] . '.');
                }
                $total += (float) $product['preco'] * $quantity;
            }
            if ($total > 9999999999.99) {
                throw new RuntimeException('O valor do pedido excede o limite permitido.');
            }

            if ($total >= 500) {
                $shipping = 0.0;
            }
            $discount = 0.0;
            if ($couponCode !== '') {
                $coupon = $this->db->prepare('SELECT id, tipo, valor, minimo_pedido, usos_maximos, usos FROM cupons WHERE codigo = :code AND ativo = 1 AND (expira_em IS NULL OR expira_em > NOW()) FOR UPDATE');
                $coupon->execute(['code' => $couponCode]);
                $couponData = $coupon->fetch();
                if (!$couponData || $total < (float) $couponData['minimo_pedido'] || ($couponData['usos_maximos'] !== null && (int) $couponData['usos'] >= (int) $couponData['usos_maximos'])) {
                    throw new RuntimeException('Cupom inválido ou indisponível para este pedido.');
                }
                $discount = $couponData['tipo'] === 'percentual' ? $total * (float) $couponData['valor'] / 100 : (float) $couponData['valor'];
                $discount = min($total, $discount);
                $use = $this->db->prepare('UPDATE cupons SET usos = usos + 1 WHERE id = :id');
                $use->execute(['id' => $couponData['id']]);
            }
            $grandTotal = max(0, $total + $shipping - $discount);
            $savedAddress = $this->db->prepare('SELECT id FROM enderecos WHERE usuario_id = :user AND destinatario = :recipient AND cep = :zip AND logradouro = :street AND numero = :number AND COALESCE(complemento, "") = :complement AND bairro = :district AND cidade = :city AND estado = :state LIMIT 1');
            $savedAddress->execute(['user' => $userId, 'recipient' => $address['destinatario'], 'zip' => $address['cep'], 'street' => $address['logradouro'], 'number' => $address['numero'], 'complement' => $address['complemento'], 'district' => $address['bairro'], 'city' => $address['cidade'], 'state' => $address['estado']]);
            if (!$savedAddress->fetch()) {
                $save = $this->db->prepare('INSERT INTO enderecos (usuario_id, destinatario, cep, logradouro, numero, complemento, bairro, cidade, estado) VALUES (:user, :recipient, :zip, :street, :number, :complement, :district, :city, :state)');
                $save->execute(['user' => $userId, 'recipient' => $address['destinatario'], 'zip' => $address['cep'], 'street' => $address['logradouro'], 'number' => $address['numero'], 'complement' => $address['complemento'] !== '' ? $address['complemento'] : null, 'district' => $address['bairro'], 'city' => $address['cidade'], 'state' => $address['estado']]);
            }
            $order = $this->db->prepare("INSERT INTO pedidos (usuario_id, status, total, frete, desconto, cupom_codigo, metodo_pagamento, endereco_entrega) VALUES (:user, 'pendente', :total, :shipping, :discount, :coupon, :payment, :address)");
            $order->execute(['user' => $userId, 'total' => number_format($grandTotal, 2, '.', ''), 'shipping' => number_format($shipping, 2, '.', ''), 'discount' => number_format($discount, 2, '.', ''), 'coupon' => $couponCode !== '' ? $couponCode : null, 'payment' => $payment, 'address' => json_encode($address, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
            $orderId = (int) $this->db->lastInsertId();
            $itemInsert = $this->db->prepare('INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario, custo_unitario) VALUES (:order, :product, :quantity, :price, :cost)');

            foreach ($products as $product) {
                $productId = (int) $product['id'];
                $quantity = $quantities[$productId];
                $itemInsert->execute(['order' => $orderId, 'product' => $productId, 'quantity' => $quantity, 'price' => $product['preco'], 'cost' => $product['custo']]);
                $this->consumeWarehouseStock($productId, $quantity, $userId, $orderId);
            }
            $receivable = $this->db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, status, usuario_id) SELECT 'receber', 'pedido', p.id, CONCAT('Pedido #', p.id), u.nome, p.total, DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY), 'aberta', p.usuario_id FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = :order");
            $receivable->execute(['order' => $orderId]);
            $audit = $this->db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'pedido_criado', 'pedido', :order, :details, :ip)");
            $audit->execute(['user' => $userId, 'order' => $orderId, 'details' => json_encode(['total' => $grandTotal, 'itens' => count($products)]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);

            $this->db->commit();
            return $orderId;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function cancel(int $orderId, int $userId, bool $isAdmin = false): void
    {
        $this->db->beginTransaction();
        try {
            $sql = 'SELECT id, usuario_id, status FROM pedidos WHERE id = :id FOR UPDATE';
            $query = $this->db->prepare($sql);
            $query->execute(['id' => $orderId]);
            $order = $query->fetch();
            if (!$order || (!$isAdmin && (int) $order['usuario_id'] !== $userId)) {
                throw new RuntimeException('Pedido não encontrado.');
            }
            if ($order['status'] === 'cancelado') {
                $this->db->commit();
                return;
            }
            if (!in_array($order['status'], ['pendente', 'pago'], true)) {
                throw new RuntimeException('Este pedido não pode ser cancelado nesta etapa.');
            }

            $items = $this->db->prepare('SELECT produto_id, quantidade FROM itens_pedido WHERE pedido_id = :order');
            $items->execute(['order' => $orderId]);
            $warehouseQuery = $this->db->query("SELECT id FROM armazens WHERE codigo = 'PRINCIPAL' AND ativo = 1 FOR UPDATE");
            $warehouseId = (int) $warehouseQuery->fetchColumn();
            if (!$warehouseId) {
                throw new RuntimeException('Armazém principal não encontrado. Aplique a migration do ERP.');
            }
            $activeInventory = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE armazem_id = :warehouse AND status = 'em_contagem' LIMIT 1 FOR UPDATE");
            $activeInventory->execute(['warehouse' => $warehouseId]);
            if ($activeInventory->fetchColumn()) {
                throw new RuntimeException('Finalize o inventário físico antes de cancelar este pedido.');
            }
            foreach ($items->fetchAll() as $item) {
                $productId = (int) $item['produto_id'];
                $quantity = (int) $item['quantidade'];
                $stock = $this->db->prepare('INSERT INTO estoque_armazens (armazem_id, produto_id, quantidade) VALUES (:warehouse, :product, :quantity) ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)');
                $stock->execute(['warehouse' => $warehouseId, 'product' => $productId, 'quantity' => $quantity]);
                $lot = $this->db->prepare('INSERT INTO lotes_estoque (armazem_id, produto_id, numero_lote, quantidade) VALUES (:warehouse, :product, :lot, :quantity) ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)');
                $lot->execute(['warehouse' => $warehouseId, 'product' => $productId, 'lot' => 'DEVOLUCAO-' . $orderId . '-' . $productId, 'quantity' => $quantity]);
                $lotId = (int) $this->db->lastInsertId();
                if ($lotId < 1) {
                    $findLot = $this->db->prepare('SELECT id FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND numero_lote = :lot AND serie IS NULL ORDER BY id DESC LIMIT 1');
                    $findLot->execute(['warehouse' => $warehouseId, 'product' => $productId, 'lot' => 'DEVOLUCAO-' . $orderId . '-' . $productId]);
                    $lotId = (int) $findLot->fetchColumn();
                }
                $sync = $this->db->prepare('UPDATE produtos p SET p.estoque = (SELECT COALESCE(SUM(s.quantidade), 0) FROM estoque_armazens s WHERE s.produto_id = p.id), p.updated_at = NOW() WHERE p.id = :product');
                $sync->execute(['product' => $productId]);
                $movement = $this->db->prepare("INSERT INTO movimentacoes_estoque (produto_id, usuario_id, armazem_id, lote_id, tipo, quantidade, motivo, pedido_id) VALUES (:product, :user, :warehouse, :lot, 'entrada', :quantity, 'Estorno de cancelamento', :order)");
                $movement->execute(['product' => $productId, 'user' => $userId, 'warehouse' => $warehouseId, 'lot' => $lotId > 0 ? $lotId : null, 'quantity' => $quantity, 'order' => $orderId]);
            }
            $cancelReceivable = $this->db->prepare("UPDATE contas_financeiras SET status = 'cancelada' WHERE tipo = 'receber' AND origem_tipo = 'pedido' AND origem_id = :order AND status = 'aberta'");
            $cancelReceivable->execute(['order' => $orderId]);
            if ($order['status'] === 'pago') {
                $refund = $this->db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, status, usuario_id) SELECT 'pagar', 'pedido', p.id, CONCAT('Estorno do pedido #', p.id), u.nome, p.total, CURRENT_DATE, 'aberta', p.usuario_id FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = :order");
                $refund->execute(['order' => $orderId]);
            }
            $update = $this->db->prepare("UPDATE pedidos SET status = 'cancelado', updated_at = NOW() WHERE id = :id");
            $update->execute(['id' => $orderId]);
            $audit = $this->db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'pedido_cancelado', 'pedido', :order, NULL, :ip)");
            $audit->execute(['user' => $userId, 'order' => $orderId, 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    private function consumeWarehouseStock(int $productId, int $quantity, int $userId, int $orderId): void
    {
        $stock = $this->db->prepare("SELECT s.armazem_id, s.quantidade FROM estoque_armazens s JOIN armazens a ON a.id = s.armazem_id WHERE s.produto_id = :product AND a.ativo = 1 AND s.quantidade > 0 AND NOT EXISTS (SELECT 1 FROM inventarios_fisicos f WHERE f.armazem_id = a.id AND f.status = 'em_contagem') ORDER BY a.id FOR UPDATE");
        $stock->execute(['product' => $productId]);
        $rows = $stock->fetchAll();
        $available = array_sum(array_map(static fn (array $row): int => (int) $row['quantidade'], $rows));
        if ($available < $quantity) {
            throw new RuntimeException('Estoque por armazém insuficiente. Confira a distribuição do produto ' . $productId . '.');
        }

        $remaining = $quantity;
        foreach ($rows as $row) {
            if ($remaining === 0) {
                break;
            }
            $warehouseId = (int) $row['armazem_id'];
            $taken = min($remaining, (int) $row['quantidade']);
            $lots = $this->db->prepare('SELECT id, quantidade FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND quantidade > 0 ORDER BY validade IS NULL, validade, id FOR UPDATE');
            $lots->execute(['warehouse' => $warehouseId, 'product' => $productId]);
            $lotsRemaining = $taken;
            $lotAllocations = $lots->fetchAll();
            $movement = $this->db->prepare("INSERT INTO movimentacoes_estoque (produto_id, usuario_id, armazem_id, lote_id, tipo, quantidade, motivo, pedido_id) VALUES (:product, :user, :warehouse, :lot, 'saida', :quantity, 'Venda', :order)");
            foreach ($lotAllocations as $lot) {
                if ($lotsRemaining === 0) {
                    break;
                }
                $lotQuantity = min($lotsRemaining, (int) $lot['quantidade']);
                $lotUpdate = $this->db->prepare('UPDATE lotes_estoque SET quantidade = quantidade - :quantity WHERE id = :id');
                $lotUpdate->execute(['quantity' => $lotQuantity, 'id' => $lot['id']]);
                $movement->execute(['product' => $productId, 'user' => $userId, 'warehouse' => $warehouseId, 'lot' => $lot['id'], 'quantity' => -$lotQuantity, 'order' => $orderId]);
                $lotsRemaining -= $lotQuantity;
            }
            if ($lotsRemaining > 0) {
                throw new RuntimeException('Os lotes não reconciliam com o estoque; execute um inventário físico.');
            }
            $update = $this->db->prepare('UPDATE estoque_armazens SET quantidade = quantidade - :quantity WHERE armazem_id = :warehouse AND produto_id = :product AND quantidade >= :quantity');
            $update->execute(['quantity' => $taken, 'warehouse' => $warehouseId, 'product' => $productId]);
            if ($update->rowCount() !== 1) {
                throw new RuntimeException('O estoque do armazém foi alterado durante a venda; tente novamente.');
            }
            $remaining -= $taken;
        }
        $sync = $this->db->prepare('UPDATE produtos p SET p.estoque = (SELECT COALESCE(SUM(s.quantidade), 0) FROM estoque_armazens s WHERE s.produto_id = p.id), p.updated_at = NOW() WHERE p.id = :product');
        $sync->execute(['product' => $productId]);
    }
}