<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class InventoryService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function change(int $productId, int $quantity, string $reason, int $userId, string $type = 'ajuste'): void
    {
        $reason = trim($reason);
        if ($quantity === 0 || abs($quantity) > 100000 || $reason === '' || mb_strlen($reason) > 255 || !in_array($type, ['entrada', 'saida', 'ajuste'], true)) {
            throw new RuntimeException('Movimentação inválida.');
        }

        $this->db->beginTransaction();
        try {
            $warehouseQuery = $this->db->query("SELECT id FROM armazens WHERE codigo = 'PRINCIPAL' AND ativo = 1 FOR UPDATE");
            $warehouseId = (int) $warehouseQuery->fetchColumn();
            if (!$warehouseId) {
                throw new RuntimeException('Armazém principal não encontrado. Aplique a migration do ERP.');
            }
            $activeInventory = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE armazem_id = :warehouse AND status = 'em_contagem' LIMIT 1 FOR UPDATE");
            $activeInventory->execute(['warehouse' => $warehouseId]);
            if ($activeInventory->fetchColumn()) {
                throw new RuntimeException('Finalize o inventário físico antes de alterar o estoque.');
            }
            $query = $this->db->prepare('SELECT estoque FROM produtos WHERE id = :id FOR UPDATE');
            $query->execute(['id' => $productId]);
            $product = $query->fetch();
            if (!$product) {
                throw new RuntimeException('Produto não encontrado.');
            }

            $delta = $type === 'saida' ? -abs($quantity) : ($type === 'entrada' ? abs($quantity) : $quantity);
            $newStock = (int) $product['estoque'] + $delta;
            if ($newStock < 0) {
                throw new RuntimeException('Estoque insuficiente para esta movimentação.');
            }
            $warehouseStock = $this->db->prepare('SELECT quantidade FROM estoque_armazens WHERE armazem_id = :warehouse AND produto_id = :product FOR UPDATE');
            $warehouseStock->execute(['warehouse' => $warehouseId, 'product' => $productId]);
            $warehouseQuantity = $warehouseStock->fetchColumn();
            if ($warehouseQuantity === false) {
                if ($delta < 0) {
                    throw new RuntimeException('Estoque insuficiente no armazém principal.');
                }
                $insertStock = $this->db->prepare('INSERT INTO estoque_armazens (armazem_id, produto_id, quantidade) VALUES (:warehouse, :product, :quantity)');
                $insertStock->execute(['warehouse' => $warehouseId, 'product' => $productId, 'quantity' => $delta]);
            } else {
                $warehouseNewQuantity = (int) $warehouseQuantity + $delta;
                if ($warehouseNewQuantity < 0) {
                    throw new RuntimeException('Estoque insuficiente no armazém principal.');
                }
                $updateWarehouse = $this->db->prepare('UPDATE estoque_armazens SET quantidade = :quantity WHERE armazem_id = :warehouse AND produto_id = :product');
                $updateWarehouse->execute(['quantity' => $warehouseNewQuantity, 'warehouse' => $warehouseId, 'product' => $productId]);
            }
            if ($delta > 0) {
                $lot = $this->db->prepare('INSERT INTO lotes_estoque (armazem_id, produto_id, numero_lote, quantidade) VALUES (:warehouse, :product, :lot, :quantity) ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)');
                $lot->execute(['warehouse' => $warehouseId, 'product' => $productId, 'lot' => 'AJUSTE-' . bin2hex(random_bytes(6)), 'quantity' => $delta]);
                $allocations = [['id' => (int) $this->db->lastInsertId(), 'quantity' => $delta]];
            } else {
                $allocations = $this->consumeLots($warehouseId, $productId, abs($delta));
            }
            $update = $this->db->prepare('UPDATE produtos SET estoque = :stock, updated_at = NOW() WHERE id = :id');
            $update->execute(['stock' => $newStock, 'id' => $productId]);
            $movement = $this->db->prepare('INSERT INTO movimentacoes_estoque (produto_id, usuario_id, armazem_id, lote_id, tipo, quantidade, motivo) VALUES (:product, :user, :warehouse, :lot, :type, :quantity, :reason)');
            foreach ($allocations as $lot) {
                $movement->execute(['product' => $productId, 'user' => $userId, 'warehouse' => $warehouseId, 'lot' => $lot['id'], 'type' => $type, 'quantity' => ($delta > 0 ? 1 : -1) * (int) $lot['quantity'], 'reason' => $reason]);
            }
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    private function consumeLots(int $warehouseId, int $productId, int $quantity): array
    {
        $query = $this->db->prepare('SELECT id, quantidade FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND quantidade > 0 ORDER BY validade IS NULL, validade, id FOR UPDATE');
        $query->execute(['warehouse' => $warehouseId, 'product' => $productId]);
        $remaining = $quantity;
        $allocations = [];
        foreach ($query->fetchAll() as $lot) {
            if ($remaining === 0) {
                break;
            }
            $taken = min($remaining, (int) $lot['quantidade']);
            $update = $this->db->prepare('UPDATE lotes_estoque SET quantidade = quantidade - :quantity WHERE id = :id');
            $update->execute(['quantity' => $taken, 'id' => $lot['id']]);
            $allocations[] = ['id' => (int) $lot['id'], 'quantity' => $taken];
            $remaining -= $taken;
        }
        if ($remaining > 0) {
            throw new RuntimeException('Os lotes não reconciliam com o saldo. Execute um inventário físico.');
        }
        return $allocations;
    }
}