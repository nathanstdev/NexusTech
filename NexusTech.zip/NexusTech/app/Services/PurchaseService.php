<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class PurchaseService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function receive(int $supplierId, int $userId, array $items, ?string $invoice = null, ?int $warehouseId = null): int
    {
        if ($supplierId < 1 || $items === [] || count($items) > 100) {
            throw new RuntimeException('Fornecedor e itens válidos são obrigatórios.');
        }
        $quantities = [];
        $costs = [];
        $lots = [];
        foreach ($items as $item) {
            $productId = filter_var($item['produto_id'] ?? null, FILTER_VALIDATE_INT);
            $quantity = filter_var($item['quantidade'] ?? null, FILTER_VALIDATE_INT);
            $cost = filter_var($item['custo_unitario'] ?? null, FILTER_VALIDATE_FLOAT);
            if (!$productId || !$quantity || $quantity < 1 || $quantity > 100000 || $cost === false || $cost < 0 || $cost > 10000000) {
                throw new RuntimeException('Item da compra inválido.');
            }
            if (isset($quantities[$productId])) {
                throw new RuntimeException('Informe no máximo uma linha por produto em cada compra.');
            }
            $quantities[$productId] = ($quantities[$productId] ?? 0) + $quantity;
            $costs[$productId] = (float) $cost;
            $lotNumber = trim((string) ($item['numero_lote'] ?? ''));
            $serialNumber = trim((string) ($item['serie'] ?? ''));
            $expiry = isset($item['validade']) && $item['validade'] !== '' ? (string) $item['validade'] : null;
            $parsedExpiry = $expiry !== null ? \DateTimeImmutable::createFromFormat('!Y-m-d', $expiry) : null;
            if (mb_strlen($lotNumber) > 100 || mb_strlen($serialNumber) > 120 || ($expiry !== null && (!$parsedExpiry || $parsedExpiry->format('Y-m-d') !== $expiry)) || ($serialNumber !== '' && $quantity !== 1)) {
                throw new RuntimeException('Lote, série ou validade inválida. Itens serializados devem ser recebidos individualmente.');
            }
            $lots[$productId] = ['number' => $lotNumber, 'serial' => $serialNumber, 'expiry' => $expiry];
        }

        $this->db->beginTransaction();
        try {
            $supplier = $this->db->prepare('SELECT id, nome FROM fornecedores WHERE id = :id AND ativo = 1 FOR UPDATE');
            $supplier->execute(['id' => $supplierId]);
            $supplierData = $supplier->fetch();
            if (!$supplierData) {
                throw new RuntimeException('Fornecedor não encontrado ou inativo.');
            }
            if ($warehouseId === null) {
                $defaultWarehouse = $this->db->query("SELECT id FROM armazens WHERE codigo = 'PRINCIPAL' AND ativo = 1 FOR UPDATE");
                $warehouseId = (int) $defaultWarehouse->fetchColumn();
            } else {
                $warehouse = $this->db->prepare('SELECT id FROM armazens WHERE id = :id AND ativo = 1 FOR UPDATE');
                $warehouse->execute(['id' => $warehouseId]);
                if (!$warehouse->fetchColumn()) {
                    throw new RuntimeException('Armazém de recebimento não encontrado ou inativo.');
                }
            }
            if (!$warehouseId) {
                throw new RuntimeException('Armazém principal não encontrado. Aplique a migration do ERP.');
            }
            $activeInventory = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE armazem_id = :warehouse AND status = 'em_contagem' LIMIT 1 FOR UPDATE");
            $activeInventory->execute(['warehouse' => $warehouseId]);
            if ($activeInventory->fetchColumn()) {
                throw new RuntimeException('O armazém está em inventário físico; finalize a contagem antes de receber compras.');
            }
            $productIds = array_keys($quantities);
            sort($productIds);
            $placeholders = implode(',', array_fill(0, count($productIds), '?'));
            $productsQuery = $this->db->prepare("SELECT id, custo FROM produtos WHERE id IN ($placeholders) ORDER BY id FOR UPDATE");
            $productsQuery->execute($productIds);
            $lockedProducts = $productsQuery->fetchAll();
            if (count($lockedProducts) !== count($productIds)) {
                throw new RuntimeException('Produto inexistente na compra.');
            }
            $oldCosts = array_column($lockedProducts, 'custo', 'id');

            $total = 0.0;
            foreach ($productIds as $productId) {
                $total += $quantities[$productId] * $costs[$productId];
            }
            if ($total > 9999999999.99) {
                throw new RuntimeException('O valor da compra excede o limite permitido.');
            }
            $purchase = $this->db->prepare("INSERT INTO compras (fornecedor_id, usuario_id, nota_fiscal, total, status) VALUES (:supplier, :user, :invoice, :total, 'recebida')");
            $purchase->execute(['supplier' => $supplierId, 'user' => $userId, 'invoice' => $invoice !== null ? mb_substr(trim($invoice), 0, 80) : null, 'total' => number_format($total, 2, '.', '')]);
            $purchaseId = (int) $this->db->lastInsertId();
            $itemInsert = $this->db->prepare('INSERT INTO itens_compra (compra_id, produto_id, quantidade, custo_unitario) VALUES (:purchase, :product, :quantity, :cost)');
            $stockUpdate = $this->db->prepare('UPDATE produtos SET estoque = estoque + :quantity, custo = :cost, updated_at = NOW() WHERE id = :id');
            $warehouseStock = $this->db->prepare('INSERT INTO estoque_armazens (armazem_id, produto_id, quantidade) VALUES (:warehouse, :product, :quantity) ON DUPLICATE KEY UPDATE quantidade = quantidade + VALUES(quantidade)');
            $movement = $this->db->prepare("INSERT INTO movimentacoes_estoque (produto_id, usuario_id, armazem_id, lote_id, tipo, quantidade, motivo, compra_id) VALUES (:product, :user, :warehouse, :lot, 'entrada', :quantity, :reason, :purchase)");
            $auditCost = $this->db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'custo_atualizado_compra', 'produto', :product, :details, :ip)");
            foreach ($productIds as $productId) {
                $quantity = $quantities[$productId];
                $cost = $costs[$productId];
                $itemInsert->execute(['purchase' => $purchaseId, 'product' => $productId, 'quantity' => $quantity, 'cost' => $cost]);
                $stockUpdate->execute(['quantity' => $quantity, 'cost' => $cost, 'id' => $productId]);
                $warehouseStock->execute(['warehouse' => $warehouseId, 'product' => $productId, 'quantity' => $quantity]);
                $lotNumber = $lots[$productId]['number'] !== '' ? $lots[$productId]['number'] : 'COMPRA-' . $purchaseId . '-' . $productId;
                $lotId = $this->addLot($warehouseId, $productId, $lotNumber, $lots[$productId]['serial'] !== '' ? $lots[$productId]['serial'] : null, $quantity, $lots[$productId]['expiry']);
                $movement->execute(['product' => $productId, 'user' => $userId, 'warehouse' => $warehouseId, 'lot' => $lotId, 'quantity' => $quantity, 'reason' => 'Compra recebida #' . $purchaseId, 'purchase' => $purchaseId]);
                if ((float) $oldCosts[$productId] !== $cost) {
                    $auditCost->execute(['user' => $userId, 'product' => $productId, 'details' => json_encode(['anterior' => (float) $oldCosts[$productId], 'novo' => $cost, 'compra_id' => $purchaseId]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
                }
            }
            $account = $this->db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, status, usuario_id) VALUES ('pagar', 'compra', :purchase, :description, :supplier, :amount, DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY), 'aberta', :user)");
            $account->execute(['purchase' => $purchaseId, 'description' => 'Compra #' . $purchaseId, 'supplier' => $supplierData['nome'], 'amount' => number_format($total, 2, '.', ''), 'user' => $userId]);
            $this->db->commit();
            return $purchaseId;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    private function addLot(int $warehouseId, int $productId, string $number, ?string $serial, int $quantity, ?string $expires): int
    {
        $serialCondition = $serial === null ? 'serie IS NULL' : 'serie = :serial';
        $query = $this->db->prepare("SELECT id FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND numero_lote = :lot AND {$serialCondition} LIMIT 1 FOR UPDATE");
        $parameters = ['warehouse' => $warehouseId, 'product' => $productId, 'lot' => $number];
        if ($serial !== null) {
            $parameters['serial'] = $serial;
        }
        $query->execute($parameters);
        $lotId = $query->fetchColumn();
        if ($lotId) {
            $update = $this->db->prepare('UPDATE lotes_estoque SET quantidade = quantidade + :quantity, validade = COALESCE(validade, :expiry) WHERE id = :id');
            $update->execute(['quantity' => $quantity, 'expiry' => $expires, 'id' => $lotId]);
            return (int) $lotId;
        }
        $insert = $this->db->prepare('INSERT INTO lotes_estoque (armazem_id, produto_id, numero_lote, serie, quantidade, validade) VALUES (:warehouse, :product, :lot, :serial, :quantity, :expiry)');
        $insert->execute(['warehouse' => $warehouseId, 'product' => $productId, 'lot' => $number, 'serial' => $serial, 'quantity' => $quantity, 'expiry' => $expires]);
        return (int) $this->db->lastInsertId();
    }
}