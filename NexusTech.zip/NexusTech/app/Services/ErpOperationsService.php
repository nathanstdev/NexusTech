<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class ErpOperationsService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function warehouses(): array
    {
        $query = $this->db->query('SELECT a.id, a.nome, a.codigo, a.descricao, a.ativo, COUNT(DISTINCT s.produto_id) AS produtos, COALESCE(SUM(s.quantidade), 0) AS unidades FROM armazens a LEFT JOIN estoque_armazens s ON s.armazem_id = a.id GROUP BY a.id ORDER BY a.nome');
        return $query->fetchAll();
    }

    public function createWarehouse(int $userId, string $name, string $code, ?string $description): int
    {
        $name = trim($name);
        $code = strtoupper(trim($code));
        if ($name === '' || mb_strlen($name) > 120 || !preg_match('/^[A-Z0-9][A-Z0-9_-]{1,39}$/', $code)) {
            throw new RuntimeException('Informe um nome e um código de armazém válido.');
        }
        $this->db->beginTransaction();
        try {
            $query = $this->db->prepare('INSERT INTO armazens (nome, codigo, descricao) VALUES (:name, :code, :description)');
            $query->execute(['name' => $name, 'code' => $code, 'description' => $description !== null ? mb_substr(trim($description), 0, 500) : null]);
            $id = (int) $this->db->lastInsertId();
            $this->audit($userId, 'armazem_criado', 'armazem', $id, ['codigo' => $code]);
            $this->db->commit();
            return $id;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function warehouseStock(?int $warehouseId = null): array
    {
        $sql = 'SELECT a.id AS armazem_id, a.nome AS armazem, p.id AS produto_id, p.nome AS produto, p.sku, COALESCE(s.quantidade, 0) AS quantidade, p.estoque_minimo FROM armazens a JOIN produtos p ON p.ativo = 1 LEFT JOIN estoque_armazens s ON s.armazem_id = a.id AND s.produto_id = p.id WHERE a.ativo = 1';
        $params = [];
        if ($warehouseId !== null) {
            $sql .= ' AND a.id = :warehouse';
            $params['warehouse'] = $warehouseId;
        }
        $sql .= ' ORDER BY a.nome, p.nome';
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetchAll();
    }

    public function lots(?int $warehouseId = null): array
    {
        $sql = 'SELECT l.id, l.numero_lote, l.serie, l.quantidade, l.validade, p.nome AS produto, p.sku, a.nome AS armazem FROM lotes_estoque l JOIN produtos p ON p.id = l.produto_id JOIN armazens a ON a.id = l.armazem_id WHERE l.quantidade > 0';
        $params = [];
        if ($warehouseId !== null) {
            $sql .= ' AND l.armazem_id = :warehouse';
            $params['warehouse'] = $warehouseId;
        }
        $sql .= ' ORDER BY l.validade IS NULL, l.validade, a.nome, p.nome LIMIT 500';
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetchAll();
    }

    public function transfer(int $sourceId, int $destinationId, int $userId, array $items, string $reason): int
    {
        $reason = trim($reason);
        if ($sourceId < 1 || $destinationId < 1 || $sourceId === $destinationId || $items === [] || count($items) > 100 || $reason === '' || mb_strlen($reason) > 255) {
            throw new RuntimeException('Informe armazéns diferentes, itens e um motivo válido.');
        }
        $quantities = $this->normalizeItems($items);
        $this->db->beginTransaction();
        try {
            $warehouses = $this->db->prepare('SELECT id FROM armazens WHERE id IN (?, ?) AND ativo = 1 ORDER BY id FOR UPDATE');
            $warehouses->execute([$sourceId, $destinationId]);
            if (count($warehouses->fetchAll()) !== 2) {
                throw new RuntimeException('Armazém de origem ou destino inválido.');
            }
            $activeInventory = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE armazem_id IN (?, ?) AND status = 'em_contagem' LIMIT 1 FOR UPDATE");
            $activeInventory->execute([$sourceId, $destinationId]);
            if ($activeInventory->fetchColumn()) {
                throw new RuntimeException('Finalize o inventário físico antes de transferir produtos.');
            }
            $productIds = array_keys($quantities);
            $placeholders = implode(',', array_fill(0, count($productIds), '?'));
            $products = $this->db->prepare("SELECT id FROM produtos WHERE id IN ($placeholders) ORDER BY id FOR UPDATE");
            $products->execute($productIds);
            if (count($products->fetchAll()) !== count($productIds)) {
                throw new RuntimeException('Um produto da transferência não existe.');
            }
            $insert = $this->db->prepare("INSERT INTO transferencias_estoque (origem_id, destino_id, usuario_id, motivo, status) VALUES (:source, :destination, :user, :reason, 'concluida')");
            $insert->execute(['source' => $sourceId, 'destination' => $destinationId, 'user' => $userId, 'reason' => $reason]);
            $transferId = (int) $this->db->lastInsertId();
            $transferItem = $this->db->prepare('INSERT INTO itens_transferencia (transferencia_id, produto_id, lote_id, quantidade) VALUES (:transfer, :product, :lot, :quantity)');
            foreach ($quantities as $productId => $quantity) {
                $this->changeWarehouseStock($sourceId, $productId, -$quantity);
                $allocations = $this->consumeLots($sourceId, $productId, $quantity);
                foreach ($allocations as $lot) {
                    $destinationLotId = $this->addLot($destinationId, $productId, (string) $lot['numero_lote'], $lot['serie'], (int) $lot['quantity'], $lot['validade']);
                    $transferItem->execute(['transfer' => $transferId, 'product' => $productId, 'lot' => $lot['id'], 'quantity' => $lot['quantity']]);
                    $reasonText = 'Transferência #' . $transferId . ': ' . $reason;
                    $this->logMovement($productId, $userId, $sourceId, 'saida', -(int) $lot['quantity'], $reasonText, (int) $lot['id']);
                    $this->logMovement($productId, $userId, $destinationId, 'entrada', (int) $lot['quantity'], $reasonText, $destinationLotId);
                }
                $this->changeWarehouseStock($destinationId, $productId, $quantity);
            }
            $this->syncProductTotals(array_keys($quantities));
            $this->audit($userId, 'estoque_transferido', 'transferencia', $transferId, ['origem' => $sourceId, 'destino' => $destinationId, 'itens' => count($quantities)]);
            $this->db->commit();
            return $transferId;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function startInventory(int $warehouseId, int $userId, ?string $note = null): int
    {
        $this->db->beginTransaction();
        try {
            $warehouse = $this->db->prepare('SELECT id FROM armazens WHERE id = :id AND ativo = 1 FOR UPDATE');
            $warehouse->execute(['id' => $warehouseId]);
            if (!$warehouse->fetchColumn()) {
                throw new RuntimeException('Armazém não encontrado ou inativo.');
            }
            $active = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE armazem_id = :warehouse AND status = 'em_contagem' LIMIT 1 FOR UPDATE");
            $active->execute(['warehouse' => $warehouseId]);
            if ($active->fetchColumn()) {
                throw new RuntimeException('Já existe um inventário físico em andamento neste armazém.');
            }
            $insert = $this->db->prepare("INSERT INTO inventarios_fisicos (armazem_id, usuario_id, observacao, status) VALUES (:warehouse, :user, :note, 'em_contagem')");
            $insert->execute(['warehouse' => $warehouseId, 'user' => $userId, 'note' => $note !== null ? mb_substr(trim($note), 0, 500) : null]);
            $inventoryId = (int) $this->db->lastInsertId();
            $snapshot = $this->db->prepare('INSERT INTO itens_inventario_fisico (inventario_id, produto_id, quantidade_sistema) SELECT :inventory, p.id, COALESCE(s.quantidade, 0) FROM produtos p LEFT JOIN estoque_armazens s ON s.produto_id = p.id AND s.armazem_id = :warehouse WHERE p.ativo = 1');
            $snapshot->execute(['inventory' => $inventoryId, 'warehouse' => $warehouseId]);
            $this->audit($userId, 'inventario_iniciado', 'inventario', $inventoryId, ['armazem_id' => $warehouseId, 'itens' => $snapshot->rowCount()]);
            $this->db->commit();
            return $inventoryId;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function countInventory(int $inventoryId, int $productId, int $counted): void
    {
        if ($counted < 0 || $counted > 100000000) {
            throw new RuntimeException('Quantidade contada inválida.');
        }
        $this->db->beginTransaction();
        try {
            $lookup = $this->db->prepare("SELECT armazem_id FROM inventarios_fisicos WHERE id = :id AND status = 'em_contagem'");
            $lookup->execute(['id' => $inventoryId]);
            $warehouseId = $lookup->fetchColumn();
            if (!$warehouseId) {
                throw new RuntimeException('Item não pertence a um inventário em andamento.');
            }
            $warehouse = $this->db->prepare('SELECT id FROM armazens WHERE id = :id FOR UPDATE');
            $warehouse->execute(['id' => $warehouseId]);
            if (!$warehouse->fetchColumn()) {
                throw new RuntimeException('Armazém do inventário não encontrado.');
            }
            $inventory = $this->db->prepare("SELECT id FROM inventarios_fisicos WHERE id = :id AND status = 'em_contagem' FOR UPDATE");
            $inventory->execute(['id' => $inventoryId]);
            if (!$inventory->fetchColumn()) {
                throw new RuntimeException('Item não pertence a um inventário em andamento.');
            }
            $query = $this->db->prepare('UPDATE itens_inventario_fisico SET quantidade_contada = :counted, contado_em = NOW() WHERE inventario_id = :inventory AND produto_id = :product');
            $query->execute(['counted' => $counted, 'inventory' => $inventoryId, 'product' => $productId]);
            if ($query->rowCount() < 1) {
                $check = $this->db->prepare('SELECT 1 FROM itens_inventario_fisico WHERE inventario_id = :inventory AND produto_id = :product');
                $check->execute(['inventory' => $inventoryId, 'product' => $productId]);
                if (!$check->fetchColumn()) {
                    throw new RuntimeException('Item não pertence a este inventário.');
                }
            }
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function completeInventory(int $inventoryId, int $userId): void
    {
        $this->db->beginTransaction();
        try {
            $lookup = $this->db->prepare("SELECT armazem_id FROM inventarios_fisicos WHERE id = :id AND status = 'em_contagem'");
            $lookup->execute(['id' => $inventoryId]);
            $warehouseId = $lookup->fetchColumn();
            if (!$warehouseId) {
                throw new RuntimeException('Inventário em andamento não encontrado.');
            }
            $warehouseLock = $this->db->prepare('SELECT id FROM armazens WHERE id = :id FOR UPDATE');
            $warehouseLock->execute(['id' => $warehouseId]);
            if (!$warehouseLock->fetchColumn()) {
                throw new RuntimeException('Armazém do inventário não encontrado.');
            }
            $query = $this->db->prepare("SELECT id, armazem_id FROM inventarios_fisicos WHERE id = :id AND status = 'em_contagem' FOR UPDATE");
            $query->execute(['id' => $inventoryId]);
            $inventory = $query->fetch();
            if (!$inventory || (int) $inventory['armazem_id'] !== (int) $warehouseId) {
                throw new RuntimeException('Inventário em andamento não encontrado.');
            }
            $items = $this->db->prepare('SELECT produto_id, quantidade_sistema, quantidade_contada FROM itens_inventario_fisico WHERE inventario_id = :id ORDER BY produto_id FOR UPDATE');
            $items->execute(['id' => $inventoryId]);
            $productIds = [];
            foreach ($items->fetchAll() as $item) {
                if ($item['quantidade_contada'] === null) {
                    throw new RuntimeException('Conte todos os produtos antes de concluir o inventário.');
                }
                $productId = (int) $item['produto_id'];
                $delta = (int) $item['quantidade_contada'] - (int) $item['quantidade_sistema'];
                if ($delta !== 0) {
                    $this->changeWarehouseStock((int) $inventory['armazem_id'], $productId, $delta);
                    if ($delta > 0) {
                        $allocations = [['id' => $this->addLot((int) $inventory['armazem_id'], $productId, 'CONTAGEM-' . $inventoryId, null, $delta, null), 'quantity' => $delta]];
                    } else {
                        $allocations = $this->consumeLots((int) $inventory['armazem_id'], $productId, abs($delta));
                    }
                    foreach ($allocations as $lot) {
                        $this->logMovement($productId, $userId, (int) $inventory['armazem_id'], 'ajuste', ($delta > 0 ? 1 : -1) * (int) $lot['quantity'], 'Inventário físico #' . $inventoryId, (int) $lot['id']);
                    }
                    $productIds[] = $productId;
                }
            }
            $this->syncProductTotals($productIds);
            $finish = $this->db->prepare("UPDATE inventarios_fisicos SET status = 'concluido', concluido_em = NOW() WHERE id = :id");
            $finish->execute(['id' => $inventoryId]);
            $this->audit($userId, 'inventario_concluido', 'inventario', $inventoryId, ['armazem_id' => (int) $inventory['armazem_id'], 'ajustes' => count($productIds)]);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function inventories(): array
    {
        $query = $this->db->query('SELECT f.id, f.status, f.observacao, f.iniciado_em, f.concluido_em, a.nome AS armazem, u.nome AS operador, SUM(i.quantidade_contada IS NULL) AS pendentes, COUNT(i.id) AS itens FROM inventarios_fisicos f JOIN armazens a ON a.id = f.armazem_id JOIN usuarios u ON u.id = f.usuario_id LEFT JOIN itens_inventario_fisico i ON i.inventario_id = f.id GROUP BY f.id ORDER BY f.iniciado_em DESC LIMIT 50');
        return $query->fetchAll();
    }

    public function inventoryItems(int $inventoryId): array
    {
        $query = $this->db->prepare('SELECT i.produto_id, p.nome AS produto, p.sku, i.quantidade_sistema, i.quantidade_contada, i.contado_em FROM itens_inventario_fisico i JOIN produtos p ON p.id = i.produto_id WHERE i.inventario_id = :id ORDER BY p.nome');
        $query->execute(['id' => $inventoryId]);
        return $query->fetchAll();
    }

    public function financialAccounts(string $type = ''): array
    {
        if ($type !== '' && !in_array($type, ['receber', 'pagar'], true)) {
            throw new RuntimeException('Filtro financeiro inválido.');
        }
        $sql = 'SELECT id, tipo, origem_tipo, descricao, contraparte, valor, vencimento, pago_em, status, created_at FROM contas_financeiras';
        if ($type !== '') {
            $sql .= ' WHERE tipo = :type';
        }
        $sql .= ' ORDER BY status = \'aberta\' DESC, vencimento, id DESC LIMIT 200';
        $query = $this->db->prepare($sql);
        $query->execute($type !== '' ? ['type' => $type] : []);
        return $query->fetchAll();
    }

    public function financialSummary(): array
    {
        $query = $this->db->query("SELECT tipo, status, COUNT(*) AS quantidade, COALESCE(SUM(valor), 0) AS valor FROM contas_financeiras GROUP BY tipo, status ORDER BY tipo, status");
        $rows = $query->fetchAll();
        $overdue = $this->db->query("SELECT id, tipo, descricao, contraparte, valor, vencimento, status FROM contas_financeiras WHERE status = 'aberta' AND vencimento < CURRENT_DATE ORDER BY vencimento LIMIT 50")->fetchAll();
        return ['resumo' => $rows, 'atrasadas' => $overdue];
    }

    public function createFinancialAccount(int $userId, array $data): int
    {
        $type = (string) ($data['tipo'] ?? '');
        $description = trim((string) ($data['descricao'] ?? ''));
        $counterparty = trim((string) ($data['contraparte'] ?? ''));
        $amount = filter_var($data['valor'] ?? null, FILTER_VALIDATE_FLOAT);
        $due = (string) ($data['vencimento'] ?? '');
        $dueDate = \DateTimeImmutable::createFromFormat('!Y-m-d', $due);
        if (!in_array($type, ['receber', 'pagar'], true) || $description === '' || mb_strlen($description) > 255 || mb_strlen($counterparty) > 190 || $amount === false || $amount <= 0 || $amount > 9999999999.99 || !$dueDate || $dueDate->format('Y-m-d') !== $due) {
            throw new RuntimeException('Informe tipo, descrição, valor positivo e vencimento válido.');
        }
        $this->db->beginTransaction();
        try {
            $query = $this->db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, descricao, contraparte, valor, vencimento, usuario_id) VALUES (:type, 'manual', :description, :counterparty, :amount, :due, :user)");
            $query->execute(['type' => $type, 'description' => $description, 'counterparty' => $counterparty !== '' ? $counterparty : null, 'amount' => number_format((float) $amount, 2, '.', ''), 'due' => $due, 'user' => $userId]);
            $id = (int) $this->db->lastInsertId();
            $this->audit($userId, 'conta_financeira_criada', 'conta_financeira', $id, ['tipo' => $type, 'valor' => (float) $amount]);
            $this->db->commit();
            return $id;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function settleFinancialAccount(int $accountId, int $userId): void
    {
        $this->db->beginTransaction();
        try {
            $query = $this->db->prepare('SELECT id, tipo, origem_tipo, origem_id FROM contas_financeiras WHERE id = :id');
            $query->execute(['id' => $accountId]);
            $account = $query->fetch();
            if (!$account) {
                throw new RuntimeException('Conta aberta não encontrada.');
            }
            if ($account['tipo'] === 'receber' && $account['origem_tipo'] === 'pedido' && $account['origem_id'] !== null) {
                $order = $this->db->prepare('SELECT status FROM pedidos WHERE id = :id FOR UPDATE');
                $order->execute(['id' => $account['origem_id']]);
                if ($order->fetchColumn() !== 'pendente') {
                    throw new RuntimeException('O pedido associado não está pendente de pagamento.');
                }
            }
            $lock = $this->db->prepare("SELECT id FROM contas_financeiras WHERE id = :id AND status = 'aberta' FOR UPDATE");
            $lock->execute(['id' => $accountId]);
            if (!$lock->fetchColumn()) {
                throw new RuntimeException('Conta aberta não encontrada.');
            }
            if ($account['tipo'] === 'receber' && $account['origem_tipo'] === 'pedido' && $account['origem_id'] !== null) {
                $order = $this->db->prepare("UPDATE pedidos SET status = 'pago', updated_at = NOW() WHERE id = :id AND status = 'pendente'");
                $order->execute(['id' => $account['origem_id']]);
                if ($order->rowCount() !== 1) {
                    throw new RuntimeException('O pedido associado não está pendente de pagamento.');
                }
            }
            $mark = $this->db->prepare("UPDATE contas_financeiras SET status = 'paga', pago_em = NOW() WHERE id = :id");
            $mark->execute(['id' => $accountId]);
            $this->audit($userId, 'conta_financeira_paga', 'conta_financeira', $accountId, []);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    public function operationalInsights(): array
    {
        $lowStock = $this->db->query('SELECT p.id, p.nome, p.sku, p.estoque, p.estoque_minimo FROM produtos p WHERE p.ativo = 1 AND p.estoque <= p.estoque_minimo ORDER BY p.estoque ASC, p.nome LIMIT 10')->fetchAll();
        $stagnant = $this->db->query("SELECT p.id, p.nome, p.sku, COALESCE(MAX(o.created_at), p.created_at) AS ultima_venda FROM produtos p LEFT JOIN itens_pedido i ON i.produto_id = p.id LEFT JOIN pedidos o ON o.id = i.pedido_id AND o.status NOT IN ('cancelado','pendente') WHERE p.ativo = 1 GROUP BY p.id, p.nome, p.sku, p.created_at HAVING ultima_venda < DATE_SUB(NOW(), INTERVAL 30 DAY) ORDER BY ultima_venda LIMIT 10")->fetchAll();
        $overdue = $this->db->query("SELECT COUNT(*) AS total, COALESCE(SUM(valor), 0) AS valor FROM contas_financeiras WHERE status = 'aberta' AND vencimento < CURRENT_DATE")->fetch();
        $expiring = $this->db->query('SELECT l.id, l.numero_lote, l.validade, l.quantidade, p.nome AS produto, a.nome AS armazem FROM lotes_estoque l JOIN produtos p ON p.id = l.produto_id JOIN armazens a ON a.id = l.armazem_id WHERE l.quantidade > 0 AND l.validade IS NOT NULL AND l.validade <= DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY) ORDER BY l.validade LIMIT 10')->fetchAll();
        $insights = [];
        if ($lowStock !== []) {
            $insights[] = ['tipo' => 'estoque_baixo', 'prioridade' => 'alta', 'resumo' => count($lowStock) . ' produto(s) no limite ou abaixo do estoque mínimo.', 'itens' => $lowStock];
        }
        if ((int) $overdue['total'] > 0) {
            $insights[] = ['tipo' => 'contas_atrasadas', 'prioridade' => 'alta', 'resumo' => (int) $overdue['total'] . ' conta(s) em atraso, total de R$ ' . number_format((float) $overdue['valor'], 2, ',', '.') . '.'];
        }
        if ($expiring !== []) {
            $insights[] = ['tipo' => 'lotes_proximos_validade', 'prioridade' => 'media', 'resumo' => count($expiring) . ' lote(s) vencem nos próximos 30 dias ou já venceram.', 'itens' => $expiring];
        }
        if ($stagnant !== []) {
            $insights[] = ['tipo' => 'produtos_sem_venda', 'prioridade' => 'baixa', 'resumo' => count($stagnant) . ' produto(s) sem venda há mais de 30 dias.', 'itens' => $stagnant];
        }
        return ['gerado_em' => date(DATE_ATOM), 'origem' => 'regras_operacionais', 'insights' => $insights];
    }

    private function normalizeItems(array $items): array
    {
        $quantities = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                throw new RuntimeException('Item inválido.');
            }
            $productId = filter_var($item['produto_id'] ?? null, FILTER_VALIDATE_INT);
            $quantity = filter_var($item['quantidade'] ?? null, FILTER_VALIDATE_INT);
            if (!$productId || !$quantity || $quantity < 1 || $quantity > 100000) {
                throw new RuntimeException('Produto ou quantidade inválida.');
            }
            $quantities[$productId] = ($quantities[$productId] ?? 0) + $quantity;
            if ($quantities[$productId] > 100000) {
                throw new RuntimeException('Quantidade máxima por produto excedida.');
            }
        }
        ksort($quantities);
        return $quantities;
    }

    private function changeWarehouseStock(int $warehouseId, int $productId, int $delta): void
    {
        $query = $this->db->prepare('SELECT quantidade FROM estoque_armazens WHERE armazem_id = :warehouse AND produto_id = :product FOR UPDATE');
        $query->execute(['warehouse' => $warehouseId, 'product' => $productId]);
        $current = $query->fetchColumn();
        if ($current === false) {
            if ($delta < 0) {
                throw new RuntimeException('Estoque insuficiente no armazém de origem.');
            }
            $insert = $this->db->prepare('INSERT INTO estoque_armazens (armazem_id, produto_id, quantidade) VALUES (:warehouse, :product, :quantity)');
            $insert->execute(['warehouse' => $warehouseId, 'product' => $productId, 'quantity' => $delta]);
            return;
        }
        $updated = (int) $current + $delta;
        if ($updated < 0) {
            throw new RuntimeException('Estoque insuficiente no armazém selecionado.');
        }
        $update = $this->db->prepare('UPDATE estoque_armazens SET quantidade = :quantity WHERE armazem_id = :warehouse AND produto_id = :product');
        $update->execute(['quantity' => $updated, 'warehouse' => $warehouseId, 'product' => $productId]);
    }

    private function consumeLots(int $warehouseId, int $productId, int $quantity): array
    {
        $query = $this->db->prepare('SELECT id, numero_lote, serie, validade, quantidade FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND quantidade > 0 ORDER BY validade IS NULL, validade, id FOR UPDATE');
        $query->execute(['warehouse' => $warehouseId, 'product' => $productId]);
        $remaining = $quantity;
        $allocations = [];
        foreach ($query->fetchAll() as $lot) {
            if ($remaining === 0) {
                break;
            }
            $taken = min($remaining, (int) $lot['quantidade']);
            $update = $this->db->prepare('UPDATE lotes_estoque SET quantidade = quantidade - :quantity WHERE id = :id');
            $update->execute(['quantity' => $taken, 'id' => $lot['id']]);
            $lot['quantity'] = $taken;
            $allocations[] = $lot;
            $remaining -= $taken;
        }
        if ($remaining > 0) {
            throw new RuntimeException('Os lotes não reconciliam com o saldo do armazém; execute uma conferência antes de movimentar.');
        }
        return $allocations;
    }

    private function addLot(int $warehouseId, int $productId, string $number, ?string $serial, int $quantity, ?string $expires): int
    {
        $serialCondition = $serial === null ? 'serie IS NULL' : 'serie = :serial';
        $query = $this->db->prepare("SELECT id FROM lotes_estoque WHERE armazem_id = :warehouse AND produto_id = :product AND numero_lote = :lot AND {$serialCondition} LIMIT 1 FOR UPDATE");
        $parameters = ['warehouse' => $warehouseId, 'product' => $productId, 'lot' => $number];
        if ($serial !== null) {
            $parameters['serial'] = $serial;
        }
        $query->execute($parameters);
        $lotId = $query->fetchColumn();
        if ($lotId) {
            $update = $this->db->prepare('UPDATE lotes_estoque SET quantidade = quantidade + :quantity, validade = COALESCE(validade, :expires) WHERE id = :id');
            $update->execute(['quantity' => $quantity, 'expires' => $expires, 'id' => $lotId]);
            return (int) $lotId;
        }
        $insert = $this->db->prepare('INSERT INTO lotes_estoque (armazem_id, produto_id, numero_lote, serie, quantidade, validade) VALUES (:warehouse, :product, :lot, :serial, :quantity, :expires)');
        $insert->execute(['warehouse' => $warehouseId, 'product' => $productId, 'lot' => $number, 'serial' => $serial, 'quantity' => $quantity, 'expires' => $expires]);
        return (int) $this->db->lastInsertId();
    }

    private function syncProductTotals(array $productIds): void
    {
        if ($productIds === []) {
            return;
        }
        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        $update = $this->db->prepare("UPDATE produtos p SET p.estoque = (SELECT COALESCE(SUM(s.quantidade), 0) FROM estoque_armazens s WHERE s.produto_id = p.id), p.updated_at = NOW() WHERE p.id IN ($placeholders)");
        $update->execute(array_values($productIds));
    }

    private function logMovement(int $productId, int $userId, int $warehouseId, string $type, int $quantity, string $reason, ?int $lotId = null): void
    {
        $query = $this->db->prepare('INSERT INTO movimentacoes_estoque (produto_id, usuario_id, armazem_id, lote_id, tipo, quantidade, motivo) VALUES (:product, :user, :warehouse, :lot, :type, :quantity, :reason)');
        $query->execute(['product' => $productId, 'user' => $userId, 'warehouse' => $warehouseId, 'lot' => $lotId, 'type' => $type, 'quantity' => $quantity, 'reason' => $reason]);
    }

    private function audit(int $userId, string $action, string $entity, int $entityId, array $details): void
    {
        $query = $this->db->prepare('INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, :action, :entity, :id, :details, :ip)');
        $query->execute(['user' => $userId, 'action' => $action, 'entity' => $entity, 'id' => $entityId, 'details' => json_encode($details, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    }
}
