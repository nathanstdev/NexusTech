<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use RuntimeException;

final class AuthService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function register(string $name, string $email, string $password): array
    {
        $name = trim($name);
        $email = mb_strtolower(trim($email));
        if (mb_strlen($name) < 2 || mb_strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Informe nome e e-mail válidos.');
        }
        if (strlen($password) < 12 || strlen($password) > 200) {
            throw new RuntimeException('A senha deve conter entre 12 e 200 caracteres.');
        }

        $this->db->beginTransaction();
        try {
            $insert = $this->db->prepare("INSERT INTO usuarios (nome, email, senha, role) VALUES (:name, :email, :password, 'cliente')");
            $insert->execute(['name' => $name, 'email' => $email, 'password' => password_hash($password, PASSWORD_ARGON2ID)]);
            $userId = (int) $this->db->lastInsertId();
            $this->audit($userId, 'cadastro', 'usuario', $userId);
            $this->db->commit();
        } catch (\PDOException $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            if ($error->getCode() === '23000') {
                throw new RuntimeException('Este e-mail já está cadastrado.');
            }
            throw $error;
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }

        return ['id' => $userId, 'nome' => $name, 'email' => $email, 'role' => 'cliente', 'auth_version' => 1];
    }

    public function login(string $email, string $password): array
    {
        $email = mb_strtolower(trim($email));
        $ip = substr((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45);
        $attempts = $this->db->prepare('SELECT COUNT(*) FROM login_tentativas WHERE ip = :ip AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)');
        $attempts->execute(['ip' => $ip]);
        if ((int) $attempts->fetchColumn() >= 5) {
            throw new RuntimeException('Muitas tentativas. Aguarde 15 minutos antes de tentar novamente.');
        }

        $query = $this->db->prepare('SELECT id, nome, email, senha, role, ativo, auth_version FROM usuarios WHERE email = :email LIMIT 1');
        $query->execute(['email' => $email]);
        $user = $query->fetch();
        if (!$user || !(bool) $user['ativo'] || !password_verify($password, $user['senha'])) {
            $failure = $this->db->prepare('INSERT INTO login_tentativas (email, ip) VALUES (:email, :ip)');
            $failure->execute(['email' => mb_substr($email, 0, 190), 'ip' => $ip]);
            $this->audit(isset($user['id']) ? (int) $user['id'] : null, 'login_falhou', 'usuario', isset($user['id']) ? (int) $user['id'] : null);
            throw new RuntimeException('E-mail ou senha inválidos.');
        }

        $clear = $this->db->prepare('DELETE FROM login_tentativas WHERE email = :email AND ip = :ip');
        $clear->execute(['email' => mb_substr($email, 0, 190), 'ip' => $ip]);
        if (password_needs_rehash($user['senha'], PASSWORD_ARGON2ID)) {
            $rehash = $this->db->prepare('UPDATE usuarios SET senha = :password WHERE id = :id');
            $rehash->execute(['password' => password_hash($password, PASSWORD_ARGON2ID), 'id' => $user['id']]);
        }

        unset($user['senha'], $user['ativo']);
        $this->audit((int) $user['id'], 'login', 'usuario', (int) $user['id']);
        return $user;
    }

    public function requestPasswordReset(string $email): void
    {
        $query = $this->db->prepare('SELECT id, nome FROM usuarios WHERE email = :email AND ativo = 1 LIMIT 1');
        $query->execute(['email' => mb_strtolower(trim($email))]);
        $user = $query->fetch();
        if (!$user) {
            return;
        }

        $limited = $this->db->prepare('SELECT COUNT(*) FROM password_resets WHERE usuario_id = :user AND expira_em > NOW()');
        $limited->execute(['user' => $user['id']]);
        if ((int) $limited->fetchColumn() >= 3) {
            return;
        }

        $appUrl = rtrim((string) ($_ENV['APP_URL'] ?? ''), '/');
        $from = trim((string) ($_ENV['MAIL_FROM'] ?? ''));
        if (filter_var($appUrl, FILTER_VALIDATE_URL) === false
            || !in_array(parse_url($appUrl, PHP_URL_SCHEME), ['http', 'https'], true)
            || filter_var($from, FILTER_VALIDATE_EMAIL) === false) {
            error_log(sprintf('[NexusTech] Configuração de APP_URL ou MAIL_FROM inválida para recuperação de senha do usuário %d.', (int) $user['id']));
            return;
        }

        $token = bin2hex(random_bytes(32));
        $save = $this->db->prepare('INSERT INTO password_resets (usuario_id, token_hash, expira_em) VALUES (:user, :token, DATE_ADD(NOW(), INTERVAL 1 HOUR))');
        $save->execute(['user' => $user['id'], 'token' => hash('sha256', $token)]);
        $url = $appUrl . '/redefinir-senha?token=' . urlencode($token);
        if (!mail((string) $email, 'Redefinição de senha NexusTech', "Olá, {$user['nome']}. Use este link em até uma hora: {$url}", "From: {$from}\r\nContent-Type: text/plain; charset=UTF-8")) {
            error_log(sprintf('[NexusTech] Falha ao enviar e-mail de redefinição para o usuário %d.', (int) $user['id']));
            $discard = $this->db->prepare('DELETE FROM password_resets WHERE token_hash = :token');
            $discard->execute(['token' => hash('sha256', $token)]);
        }
    }

    public function resetPassword(string $token, string $password): void
    {
        if (strlen($password) < 12 || strlen($password) > 200 || !preg_match('/^[a-f0-9]{64}$/i', $token)) {
            throw new RuntimeException('Token ou senha inválidos.');
        }
        $this->db->beginTransaction();
        try {
            $query = $this->db->prepare('SELECT id, usuario_id FROM password_resets WHERE token_hash = :token AND usado_em IS NULL AND expira_em > NOW() FOR UPDATE');
            $query->execute(['token' => hash('sha256', $token)]);
            $reset = $query->fetch();
            if (!$reset) {
                throw new RuntimeException('Link de recuperação inválido ou expirado.');
            }
            $update = $this->db->prepare('UPDATE usuarios SET senha = :password, auth_version = auth_version + 1 WHERE id = :id');
            $update->execute(['password' => password_hash($password, PASSWORD_ARGON2ID), 'id' => $reset['usuario_id']]);
            $consume = $this->db->prepare('UPDATE password_resets SET usado_em = NOW() WHERE usuario_id = :user AND usado_em IS NULL');
            $consume->execute(['user' => $reset['usuario_id']]);
            $this->audit((int) $reset['usuario_id'], 'senha_redefinida', 'usuario', (int) $reset['usuario_id']);
            $this->db->commit();
        } catch (\Throwable $error) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $error;
        }
    }

    private function audit(?int $userId, string $action, string $entity, ?int $entityId): void
    {
        $query = $this->db->prepare('INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, ip) VALUES (:user, :action, :entity, :entity_id, :ip)');
        $query->execute(['user' => $userId, 'action' => $action, 'entity' => $entity, 'entity_id' => $entityId, 'ip' => substr((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45)]);
    }
}