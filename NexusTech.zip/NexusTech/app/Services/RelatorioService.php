<?php
declare(strict_types=1);

namespace App\Services;

use DateTimeImmutable;
use PDO;

final class RelatorioService
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function dashboard(int $days = 30, ?string $from = null, ?string $to = null): array
    {
        $days = max(1, min($days, 365));
        $endDate = new DateTimeImmutable('today');
        $startDate = $endDate->modify('-' . ($days - 1) . ' days');
        if ($from !== null && $to !== null) {
            $parsedFrom = DateTimeImmutable::createFromFormat('!Y-m-d', $from);
            $parsedTo = DateTimeImmutable::createFromFormat('!Y-m-d', $to);
            if (!$parsedFrom || !$parsedTo || $parsedFrom->format('Y-m-d') !== $from || $parsedTo->format('Y-m-d') !== $to || $parsedTo < $parsedFrom || $parsedFrom < $endDate->modify('-366 days') || $parsedTo > $endDate) {
                throw new \InvalidArgumentException('Intervalo personalizado inválido.');
            }
            $startDate = $parsedFrom;
            $endDate = $parsedTo;
        }

        $start = $startDate->format('Y-m-d 00:00:00');
        $end = $endDate->modify('+1 day')->format('Y-m-d 00:00:00');
        $cacheKey = hash('sha256', $start . '|' . $end);
        $cacheDirectory = dirname(__DIR__, 2) . '/storage/cache';
        $cacheFile = $cacheDirectory . '/dashboard-' . $cacheKey . '.json';
        if (is_file($cacheFile) && filemtime($cacheFile) >= time() - 60) {
            $cached = json_decode(file_get_contents($cacheFile) ?: '', true);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $kpis = $this->rangeQuery("SELECT COUNT(*) AS pedidos, COALESCE(SUM(total), 0) AS faturamento, COALESCE(AVG(total), 0) AS ticket_medio FROM pedidos WHERE status NOT IN ('cancelado','pendente') AND created_at >= :start AND created_at < :end", $start, $end);
        $lowStockQuery = $this->db->prepare('SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND estoque <= estoque_minimo');
        $lowStockQuery->execute();
        $lowStock = (int) $lowStockQuery->fetchColumn();

        $sales = $this->rangeQuery("SELECT DATE(created_at) AS dia, SUM(total) AS valor FROM pedidos WHERE status NOT IN ('cancelado','pendente') AND created_at >= :start AND created_at < :end GROUP BY DATE(created_at) ORDER BY dia", $start, $end);
        $topProducts = $this->rangeQuery("SELECT p.nome, SUM(i.quantidade) AS quantidade FROM itens_pedido i JOIN pedidos o ON o.id = i.pedido_id JOIN produtos p ON p.id = i.produto_id WHERE o.status NOT IN ('cancelado','pendente') AND o.created_at >= :start AND o.created_at < :end GROUP BY p.id, p.nome ORDER BY quantidade DESC LIMIT 8", $start, $end);
        $categories = $this->rangeQuery("SELECT COALESCE(c.nome, 'Sem categoria') AS nome, SUM(i.quantidade * i.preco_unitario) AS valor FROM itens_pedido i JOIN pedidos o ON o.id = i.pedido_id JOIN produtos p ON p.id = i.produto_id LEFT JOIN categorias c ON c.id = p.categoria_id WHERE o.status NOT IN ('cancelado','pendente') AND o.created_at >= :start AND o.created_at < :end GROUP BY c.id, c.nome", $start, $end);
        $movement = $this->rangeQuery("SELECT DATE(created_at) AS dia, SUM(CASE WHEN quantidade > 0 THEN quantidade ELSE 0 END) AS entradas, SUM(CASE WHEN quantidade < 0 THEN ABS(quantidade) ELSE 0 END) AS saidas FROM movimentacoes_estoque WHERE created_at >= :start AND created_at < :end GROUP BY DATE(created_at) ORDER BY dia", $start, $end);
        $profit = $this->rangeQuery("SELECT DATE(o.created_at) AS dia, SUM(i.quantidade * (i.preco_unitario - i.custo_unitario)) AS lucro FROM itens_pedido i JOIN pedidos o ON o.id = i.pedido_id WHERE o.status NOT IN ('cancelado','pendente') AND o.created_at >= :start AND o.created_at < :end GROUP BY DATE(o.created_at) ORDER BY dia", $start, $end);
        $heat = $this->rangeQuery("SELECT WEEKDAY(created_at) AS dia_semana, HOUR(created_at) AS hora, COUNT(*) AS pedidos FROM pedidos WHERE status NOT IN ('cancelado','pendente') AND created_at >= :start AND created_at < :end GROUP BY WEEKDAY(created_at), HOUR(created_at)", $start, $end);
        $abc = $this->rangeQuery("SELECT p.nome, SUM(i.quantidade * i.preco_unitario) AS receita, SUM(i.quantidade) AS unidades FROM produtos p JOIN itens_pedido i ON i.produto_id = p.id JOIN pedidos o ON o.id = i.pedido_id WHERE o.status NOT IN ('cancelado','pendente') AND o.created_at >= :start AND o.created_at < :end GROUP BY p.id, p.nome ORDER BY receita DESC", $start, $end);
        $turnover = $this->rangeQuery('SELECT p.id, p.nome, p.estoque, COALESCE(sold.unidades, 0) AS vendidos, COALESCE(sold.receita, 0) AS receita FROM produtos p LEFT JOIN (SELECT i.produto_id, SUM(i.quantidade) AS unidades, SUM(i.quantidade * i.preco_unitario) AS receita FROM itens_pedido i JOIN pedidos o ON o.id = i.pedido_id WHERE o.status NOT IN (\'cancelado\',\'pendente\') AND o.created_at >= :start AND o.created_at < :end GROUP BY i.produto_id) sold ON sold.produto_id = p.id WHERE p.ativo = 1 ORDER BY receita DESC, p.nome', $start, $end);
        $turnoverRows = $turnover->fetchAll();
        foreach ($turnoverRows as &$turnoverRow) {
            $turnoverRow['giro'] = (int) $turnoverRow['estoque'] > 0 ? round((float) $turnoverRow['vendidos'] / (int) $turnoverRow['estoque'], 3) : null;
        }
        unset($turnoverRow);
        $abcRows = $abc->fetchAll();
        $revenue = array_sum(array_map(static fn (array $row): float => (float) $row['receita'], $abcRows));
        $running = 0.0;
        foreach ($abcRows as &$row) {
            $share = $revenue > 0 ? (float) $row['receita'] / $revenue : 0;
            $row['classe'] = $running < 0.8 ? 'A' : ($running < 0.95 ? 'B' : 'C');
            $running += $share;
        }
        unset($row);

        $report = [
            'kpis' => array_merge($kpis->fetch() ?: [], ['estoque_baixo' => $lowStock]),
            'vendas' => $sales->fetchAll(),
            'mais_vendidos' => $topProducts->fetchAll(),
            'categorias' => $categories->fetchAll(),
            'estoque' => $movement->fetchAll(),
            'lucro' => $profit->fetchAll(),
            'calor' => $heat->fetchAll(),
            'curva_abc' => $abcRows,
            'giro' => $turnoverRows,
            'parados' => array_values(array_filter($turnoverRows, static fn (array $row): bool => (int) $row['vendidos'] === 0)),
            'gerado_em' => (new DateTimeImmutable())->format(DATE_ATOM),
        ];
        if (!is_dir($cacheDirectory)) {
            @mkdir($cacheDirectory, 0700, true);
        }
        if (is_dir($cacheDirectory)) {
            $temporary = $cacheFile . '.' . bin2hex(random_bytes(4)) . '.tmp';
            if (file_put_contents($temporary, json_encode($report, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), LOCK_EX) !== false) {
                @rename($temporary, $cacheFile);
            }
        }
        return $report;
    }

    private function rangeQuery(string $sql, string $start, string $end): \PDOStatement
    {
        $query = $this->db->prepare($sql);
        $query->execute(['start' => $start, 'end' => $end]);
        return $query;
    }
}