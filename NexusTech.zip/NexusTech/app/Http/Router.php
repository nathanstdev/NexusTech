<?php
declare(strict_types=1);

namespace App\Http;

use App\Api\Response;

final class Router
{
    /** @var list<array{method: string, pattern: string, handler: callable}> */
    private array $routes = [];

    public function get(string $path, callable $handler): void
    {
        $this->add('GET', $path, $handler);
    }

    public function post(string $path, callable $handler): void
    {
        $this->add('POST', $path, $handler);
    }

    public function patch(string $path, callable $handler): void
    {
        $this->add('PATCH', $path, $handler);
    }

    public function delete(string $path, callable $handler): void
    {
        $this->add('DELETE', $path, $handler);
    }

    public function dispatch(string $method, string $path): void
    {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method || preg_match($route['pattern'], $path, $matches) !== 1) {
                continue;
            }
            $parameters = array_values(array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY));
            ($route['handler'])(...$parameters);
            return;
        }

        if (str_starts_with($path, '/api/')) {
            Response::error('Endpoint não encontrado.', 404);
        }
        http_response_code(404);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Não encontrado</title><h1>404 · Página não encontrada</h1>';
    }

    private function add(string $method, string $path, callable $handler): void
    {
        $segments = preg_split('/(\{[a-zA-Z][a-zA-Z0-9_]*\})/', $path, -1, PREG_SPLIT_DELIM_CAPTURE) ?: [];
        $pattern = '';
        foreach ($segments as $segment) {
            if (preg_match('/^\{([a-zA-Z][a-zA-Z0-9_]*)\}$/', $segment, $parameter)) {
                $pattern .= '(?P<' . $parameter[1] . '>[^/]+)';
            } else {
                $pattern .= preg_quote($segment, '#');
            }
        }
        $this->routes[] = ['method' => $method, 'pattern' => '#^' . $pattern . '$#D', 'handler' => $handler];
    }
}