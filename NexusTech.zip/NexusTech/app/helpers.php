<?php
declare(strict_types=1);

function e(string|null $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string
{
    if (!isset($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function verify_csrf(?string $token): bool
{
    return is_string($token) && isset($_SESSION['_csrf']) && hash_equals($_SESSION['_csrf'], $token);
}

function base_path(): string
{
    if (array_key_exists('APP_BASE_PATH', $_ENV)) {
        $configured = trim((string) $_ENV['APP_BASE_PATH']);
        return $configured === '' || $configured === '/' ? '' : '/' . trim($configured, '/');
    }
    $directory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    return $directory === '/' || $directory === '.' ? '' : rtrim($directory, '/');
}

function app_url(string $path = ''): string
{
    return base_path() . '/' . ltrim($path, '/');
}

function request_data(): array
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json')) {
        $decoded = json_decode(file_get_contents('php://input') ?: '', true);
        if (!is_array($decoded)) {
            \App\Api\Response::error('Corpo JSON inválido.', 400);
        }
        return $decoded;
    }
    return $_POST;
}

function sanitize_address(array $address): array
{
    $limits = ['destinatario' => 120, 'cep' => 9, 'logradouro' => 180, 'numero' => 20, 'complemento' => 100, 'bairro' => 100, 'cidade' => 100, 'estado' => 2];
    $clean = [];
    foreach ($limits as $field => $limit) {
        $value = trim((string) ($address[$field] ?? ''));
        if ($field !== 'complemento' && $value === '') {
            throw new InvalidArgumentException('Preencha todos os campos obrigatórios do endereço.');
        }
        if (mb_strlen($value) > $limit) {
            throw new InvalidArgumentException('Um dos campos do endereço ultrapassa o tamanho permitido.');
        }
        $clean[$field] = $field === 'estado' ? strtoupper($value) : $value;
    }
    if (!preg_match('/^\d{5}-?\d{3}$/', $clean['cep']) || !preg_match('/^[A-Z]{2}$/', $clean['estado'])) {
        throw new InvalidArgumentException('CEP ou estado inválido.');
    }
    return $clean;
}