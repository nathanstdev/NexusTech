<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Api\Response;
use App\Database;

final class AuthMiddleware
{
    public static function user(?string $role = null): array
    {
        $user = $_SESSION['user'] ?? null;
        if (!is_array($user) || !isset($user['id'])) {
            Response::error('Autenticação necessária.', 401);
        }
        $query = Database::connection()->prepare('SELECT id, nome, email, role, ativo, auth_version FROM usuarios WHERE id = :id');
        $query->execute(['id' => (int) $user['id']]);
        $current = $query->fetch();
        if (!$current || !(bool) $current['ativo'] || !isset($user['auth_version']) || (int) $user['auth_version'] !== (int) $current['auth_version']) {
            $_SESSION = [];
            session_destroy();
            Response::error('Sessão encerrada. Faça login novamente.', 401);
        }
        unset($current['ativo']);
        $current['auth_version'] = (int) $current['auth_version'];
        $_SESSION['user'] = $current;
        $user = $current;
        if ($role !== null && ($user['role'] ?? null) !== $role) {
            Response::error('Acesso não autorizado.', 403);
        }
        return $user;
    }

    public static function csrf(): void
    {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['_csrf'] ?? null;
        if (!verify_csrf(is_string($token) ? $token : null)) {
            Response::error('Token CSRF inválido ou expirado.', 419);
        }
    }
}