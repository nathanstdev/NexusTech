<?php
declare(strict_types=1);

use App\Database;

$composerAutoload = dirname(__DIR__) . '/vendor/autoload.php';
if (is_file($composerAutoload)) {
    require_once $composerAutoload;
}

if (!class_exists(\Dotenv\Dotenv::class)) {
    throw new RuntimeException('Dependência vlucas/phpdotenv indisponível. Execute composer install.');
}

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

\Dotenv\Dotenv::createImmutable(dirname(__DIR__))->safeLoad();

date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'America/Sao_Paulo');
ini_set('display_errors', (($_ENV['APP_ENV'] ?? 'production') !== 'production' && ($_ENV['APP_DEBUG'] ?? 'false') === 'true') ? '1' : '0');

if (PHP_SAPI !== 'cli') {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');
    if (session_status() !== PHP_SESSION_ACTIVE) {
        $basePath = trim((string) ($_ENV['APP_BASE_PATH'] ?? ''));
        $sessionPath = $basePath !== '' && $basePath !== '/' ? '/' . trim($basePath, '/') . '/' : '/';
        session_set_cookie_params([
            'httponly' => true,
            'secure' => ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_ENV['APP_ENV'] ?? 'production') === 'production'),
            'samesite' => 'Lax',
            'path' => $sessionPath,
        ]);
        session_start();
    }

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('Cache-Control: no-store, private');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data: https://fonts.gstatic.com; script-src 'self' https://cdn.jsdelivr.net; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
}

require_once __DIR__ . '/helpers.php';
require_once dirname(__DIR__) . '/api/helpers/response.php';

if (PHP_SAPI !== 'cli') {
    set_exception_handler(static function (Throwable $error): void {
        error_log(sprintf('[NexusTech] %s: %s in %s:%d', $error::class, $error->getMessage(), $error->getFile(), $error->getLine()));
        if (headers_sent()) {
            exit;
        }
        $requestPath = (string) (parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
        $basePath = base_path();
        if ($basePath !== '' && ($requestPath === $basePath || str_starts_with($requestPath, $basePath . '/'))) {
            $requestPath = substr($requestPath, strlen($basePath)) ?: '/';
        }
        if (str_starts_with($requestPath, '/api/')) {
            \App\Api\Response::error('Erro interno. Consulte o log da aplicação.', 500);
        }
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Erro interno</title><h1>Não foi possível concluir a solicitação.</h1>';
    });
}