<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Api\Response;
use App\Database;
use App\Middleware\AuthMiddleware;
use App\Services\OrderService;
use PDO;
use RuntimeException;

final class OrderController
{
    public static function index(): never
    {
        $user = AuthMiddleware::user();
        $db = Database::connection();
        $conditions = [];
        $params = [];
        if ($user['role'] !== 'admin') {
            $conditions[] = 'o.usuario_id = :user';
            $params['user'] = (int) $user['id'];
        }
        $status = (string) ($_GET['status'] ?? '');
        if ($status !== '') {
            if (!in_array($status, ['pendente', 'pago', 'separado', 'enviado', 'entregue', 'cancelado'], true)) {
                Response::error('Filtro de status inválido.', 422);
            }
            $conditions[] = 'o.status = :status';
            $params['status'] = $status;
        }
        $where = $conditions === [] ? '1 = 1' : implode(' AND ', $conditions);
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = max(1, min(100, (int) ($_GET['per_page'] ?? 100)));
        $count = $db->prepare("SELECT COUNT(*) FROM pedidos o WHERE $where");
        $count->execute($params);
        $total = (int) $count->fetchColumn();
        $statement = $db->prepare("SELECT o.id, o.status, o.total, o.metodo_pagamento, o.created_at, u.nome AS cliente FROM pedidos o JOIN usuarios u ON u.id = o.usuario_id WHERE $where ORDER BY o.created_at DESC LIMIT :limit OFFSET :offset");
        foreach ($params as $key => $value) {
            $statement->bindValue(':' . $key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $statement->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $statement->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
        $statement->execute();
        Response::success($statement->fetchAll(), 200, ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => (int) ceil($total / $perPage)]);
    }

    public static function create(): never
    {
        $user = AuthMiddleware::user();
        AuthMiddleware::csrf();
        $data = request_data();
        try {
            $orderId = (new OrderService(Database::connection()))->create((int) $user['id'], is_array($data['itens'] ?? null) ? $data['itens'] : [], $data);
            Response::success(['id' => $orderId, 'status' => 'pendente'], 201);
        } catch (RuntimeException $error) {
            Response::error($error->getMessage(), 422);
        }
    }

    public static function show(string $id): never
    {
        $user = AuthMiddleware::user();
        $db = Database::connection();
        $orderQuery = $db->prepare('SELECT id, usuario_id, status, total, metodo_pagamento, created_at FROM pedidos WHERE id = :id');
        $orderQuery->execute(['id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0]);
        $order = $orderQuery->fetch();
        if (!$order || ($user['role'] !== 'admin' && (int) $order['usuario_id'] !== (int) $user['id'])) {
            Response::error('Pedido não encontrado.', 404);
        }
        $items = $db->prepare('SELECT i.quantidade, i.preco_unitario, p.nome FROM itens_pedido i JOIN produtos p ON p.id = i.produto_id WHERE i.pedido_id = :id');
        $items->execute(['id' => $order['id']]);
        $order['itens'] = $items->fetchAll();
        Response::success($order);
    }

    public static function cancel(string $id): never
    {
        $user = AuthMiddleware::user();
        AuthMiddleware::csrf();
        try {
            (new OrderService(Database::connection()))->cancel((int) $id, (int) $user['id'], $user['role'] === 'admin');
            Response::success(['id' => (int) $id, 'status' => 'cancelado']);
        } catch (RuntimeException $error) {
            Response::error($error->getMessage(), 422);
        }
    }
}