<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Api\Response;
use App\Database;
use App\Middleware\AuthMiddleware;
use App\Services\AuthService;
use RuntimeException;

final class AuthController
{
    public static function register(): never
    {
        AuthMiddleware::csrf();
        $data = request_data();
        try {
            $user = (new AuthService(Database::connection()))->register((string) ($data['nome'] ?? ''), (string) ($data['email'] ?? ''), (string) ($data['senha'] ?? ''));
            unset($_SESSION['_csrf']);
            session_regenerate_id(true);
            $_SESSION['user'] = $user;
            Response::success(['user' => $user, 'csrf' => csrf_token()], 201);
        } catch (RuntimeException $error) {
            Response::error($error->getMessage(), 422);
        }
    }

    public static function login(): never
    {
        AuthMiddleware::csrf();
        $data = request_data();
        try {
            $user = (new AuthService(Database::connection()))->login((string) ($data['email'] ?? ''), (string) ($data['senha'] ?? ''));
            unset($_SESSION['_csrf']);
            session_regenerate_id(true);
            $_SESSION['user'] = $user;
            Response::success(['user' => $user, 'csrf' => csrf_token()]);
        } catch (RuntimeException $error) {
            $status = str_starts_with($error->getMessage(), 'Muitas tentativas') ? 429 : 401;
            Response::error($error->getMessage(), $status);
        }
    }

    public static function me(): void
    {
        Response::success($_SESSION['user'] ?? null);
    }

    public static function logout(): never
    {
        AuthMiddleware::csrf();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $params['path'],
                'domain' => $params['domain'],
                'secure' => $params['secure'],
                'httponly' => $params['httponly'],
                'samesite' => $params['samesite'] ?? 'Lax',
            ]);
        }
        session_destroy();
        Response::success(['logged_out' => true]);
    }

    public static function recover(): never
    {
        AuthMiddleware::csrf();
        $data = request_data();
        (new AuthService(Database::connection()))->requestPasswordReset((string) ($data['email'] ?? ''));
        Response::success(['message' => 'Se o e-mail estiver cadastrado, você receberá instruções para redefinir sua senha.']);
    }

    public static function resetPassword(): never
    {
        AuthMiddleware::csrf();
        $data = request_data();
        try {
            (new AuthService(Database::connection()))->resetPassword((string) ($data['token'] ?? ''), (string) ($data['senha'] ?? ''));
            Response::success(['message' => 'Senha atualizada. Você já pode entrar na sua conta.']);
        } catch (RuntimeException $error) {
            Response::error($error->getMessage(), 422);
        }
    }
}