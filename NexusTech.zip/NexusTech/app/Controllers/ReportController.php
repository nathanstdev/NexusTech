<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Api\Response;
use App\Database;
use App\Middleware\AuthMiddleware;
use App\Services\RelatorioService;
use InvalidArgumentException;

final class ReportController
{
    public static function dashboard(): never
    {
        AuthMiddleware::user('admin');
        $days = max(1, min(365, (int) ($_GET['periodo'] ?? 30)));
        $from = isset($_GET['de']) ? (string) $_GET['de'] : null;
        $to = isset($_GET['ate']) ? (string) $_GET['ate'] : null;
        try {
            Response::success((new RelatorioService(Database::connection()))->dashboard($days, $from, $to));
        } catch (InvalidArgumentException $error) {
            Response::error($error->getMessage(), 422);
        }
    }
}