<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Middleware\AuthMiddleware;

final class PageController
{
    public static function storefront(): void
    {
        require dirname(__DIR__, 2) . '/view/storefront.php';
    }

    public static function product(string $id): void
    {
        $productId = filter_var($id, FILTER_VALIDATE_INT);
        if (!$productId) {
            http_response_code(404);
            require dirname(__DIR__, 2) . '/view/not-found.php';
            return;
        }
        $_GET['id'] = $productId;
        require dirname(__DIR__, 2) . '/view/product.php';
    }

    public static function login(): void
    {
        require dirname(__DIR__, 2) . '/view/login.php';
    }

    public static function register(): void
    {
        require dirname(__DIR__, 2) . '/view/register.php';
    }

    public static function recover(): void
    {
        require dirname(__DIR__, 2) . '/view/recover.php';
    }

    public static function resetPassword(): void
    {
        require dirname(__DIR__, 2) . '/view/reset-password.php';
    }

    public static function admin(): void
    {
        AuthMiddleware::user('admin');
        require dirname(__DIR__, 2) . '/view/admin.php';
    }

    public static function orders(): void
    {
        self::requireAuthenticated();
        require dirname(__DIR__, 2) . '/view/orders.php';
    }

    public static function checkout(): void
    {
        self::requireAuthenticated();
        require dirname(__DIR__, 2) . '/view/checkout.php';
    }

    public static function account(): void
    {
        self::requireAuthenticated();
        require dirname(__DIR__, 2) . '/view/account.php';
    }

    private static function requireAuthenticated(): void
    {
        if (!isset($_SESSION['user'])) {
            header('Location: ' . app_url('login'));
            exit;
        }
        AuthMiddleware::user();
    }
}