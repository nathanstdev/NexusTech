<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Api\Response;
use App\Database;
use App\Middleware\AuthMiddleware;
use PDO;

final class ProductController
{
    private const RATING_JOINS = '
        LEFT JOIN (
            SELECT produto_id, COUNT(*) AS total, SUM(estrelas) AS estrelas
            FROM avaliacoes
            GROUP BY produto_id
        ) cr ON cr.produto_id = p.id
        LEFT JOIN (
            SELECT produto_id, COUNT(*) AS total, SUM(estrelas) AS estrelas
            FROM avaliacoes_demo
            GROUP BY produto_id
        ) dr ON dr.produto_id = p.id';

    private static function ratingFields(): string
    {
        return '
            COALESCE(cr.total, 0) AS avaliacoes_clientes,
            COALESCE(dr.total, 0) AS avaliacoes_demo,
            COALESCE(cr.total, 0) + COALESCE(dr.total, 0) AS avaliacoes_total,
            CASE
                WHEN COALESCE(cr.total, 0) + COALESCE(dr.total, 0) = 0 THEN 0
                ELSE (COALESCE(cr.estrelas, 0) + COALESCE(dr.estrelas, 0))
                    / (COALESCE(cr.total, 0) + COALESCE(dr.total, 0))
            END AS avaliacao_media';
    }

    public static function index(): never
    {
        $db = Database::connection();
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = max(1, min(48, (int) ($_GET['per_page'] ?? 12)));
        $conditions = ['p.ativo = 1', '(c.ativo = 1 OR c.id IS NULL)'];
        $params = [];
        $search = trim((string) ($_GET['q'] ?? ''));
        if ($search !== '') {
            $pattern = '%' . mb_substr($search, 0, 100) . '%';
            $conditions[] = '(p.nome LIKE :search_name OR p.sku LIKE :search_sku)';
            $params['search_name'] = $pattern;
            $params['search_sku'] = $pattern;
        }
        if (isset($_GET['categoria']) && $_GET['categoria'] !== '') {
            $conditions[] = 'c.slug = :category';
            $params['category'] = substr((string) $_GET['categoria'], 0, 120);
        }
        if (isset($_GET['disponivel']) && $_GET['disponivel'] === '1') {
            $conditions[] = 'p.estoque > 0';
        }
        foreach (['min' => '>=', 'max' => '<='] as $key => $operator) {
            if (isset($_GET[$key]) && is_numeric($_GET[$key])) {
                $conditions[] = 'p.preco ' . $operator . ' :' . $key;
                $params[$key] = max(0, (float) $_GET[$key]);
            }
        }
        $sortColumns = ['preco' => 'p.preco', 'nome' => 'p.nome', 'recentes' => 'p.created_at'];
        $sort = $sortColumns[(string) ($_GET['ordenar'] ?? 'recentes')] ?? 'p.created_at';
        $direction = strtolower((string) ($_GET['direcao'] ?? 'desc')) === 'asc' ? 'ASC' : 'DESC';
        $where = implode(' AND ', $conditions);
        $count = $db->prepare("SELECT COUNT(*) FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE $where");
        $count->execute($params);
        $total = (int) $count->fetchColumn();
        $list = $db->prepare("SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.imagem_url, p.imagens, c.nome AS categoria, c.slug AS categoria_slug, " . self::ratingFields() . " FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id " . self::RATING_JOINS . " WHERE $where ORDER BY $sort $direction LIMIT :limit OFFSET :offset");
        foreach ($params as $key => $value) {
            $list->bindValue(':' . $key, $value, PDO::PARAM_STR);
        }
        $list->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $list->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
        $list->execute();
        Response::success($list->fetchAll(), 200, ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => (int) ceil($total / $perPage)]);
    }

    public static function show(string $id): never
    {
        $query = Database::connection()->prepare('SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.imagem_url, p.imagens, c.nome AS categoria, ' . self::ratingFields() . ' FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id ' . self::RATING_JOINS . ' WHERE p.id = :id AND p.ativo = 1 AND (c.ativo = 1 OR c.id IS NULL)');
        $query->execute(['id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0]);
        $product = $query->fetch();
        if (!$product) {
            Response::error('Produto não encontrado.', 404);
        }
        $product['imagens'] = is_string($product['imagens']) ? (json_decode($product['imagens'], true) ?: []) : [];
        Response::success($product);
    }

    public static function related(string $id): never
    {
        $query = Database::connection()->prepare('SELECT p.id, p.nome, p.descricao, p.preco, p.estoque, p.imagem_url, c.nome AS categoria, ' . self::ratingFields() . ' FROM produtos current_product JOIN categorias category ON category.id = current_product.categoria_id AND category.ativo = 1 JOIN produtos p ON p.categoria_id = current_product.categoria_id AND p.id <> current_product.id AND p.ativo = 1 JOIN categorias c ON c.id = p.categoria_id ' . self::RATING_JOINS . ' WHERE current_product.id = :id ORDER BY p.estoque DESC, p.nome LIMIT 4');
        $query->execute(['id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0]);
        Response::success($query->fetchAll());
    }

    public static function reviews(string $id): never
    {
        $productId = filter_var($id, FILTER_VALIDATE_INT);
        if (!$productId) {
            Response::error('Produto não encontrado.', 404);
        }

        $db = Database::connection();
        $product = $db->prepare('SELECT p.id FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE p.id = :id AND p.ativo = 1 AND (c.ativo = 1 OR c.id IS NULL)');
        $product->execute(['id' => $productId]);
        if (!$product->fetchColumn()) {
            Response::error('Produto não encontrado.', 404);
        }

        $summary = $db->prepare('
            SELECT COALESCE(SUM(total), 0) AS total,
                   COALESCE(SUM(estrelas) / NULLIF(SUM(total), 0), 0) AS media,
                   COALESCE(SUM(clientes), 0) AS clientes,
                   COALESCE(SUM(demonstracoes), 0) AS demonstracoes
            FROM (
                SELECT COUNT(*) AS total, SUM(estrelas) AS estrelas, COUNT(*) AS clientes, 0 AS demonstracoes
                FROM avaliacoes WHERE produto_id = :customer_id
                UNION ALL
                SELECT COUNT(*) AS total, SUM(estrelas) AS estrelas, 0 AS clientes, COUNT(*) AS demonstracoes
                FROM avaliacoes_demo WHERE produto_id = :demo_id
            ) rating_totals');
        $summary->execute(['customer_id' => $productId, 'demo_id' => $productId]);
        $reviews = $db->prepare("
            SELECT a.estrelas, a.comentario, a.created_at, u.nome AS autor, 0 AS demonstracao
            FROM avaliacoes a JOIN usuarios u ON u.id = a.usuario_id WHERE a.produto_id = :customer_id
            UNION ALL
            SELECT d.estrelas, d.comentario, d.created_at, 'Exemplo demonstrativo' AS autor, 1 AS demonstracao
            FROM avaliacoes_demo d WHERE d.produto_id = :demo_id
            ORDER BY created_at DESC LIMIT 50");
        $reviews->execute(['customer_id' => $productId, 'demo_id' => $productId]);
        Response::success(['resumo' => $summary->fetch(), 'itens' => $reviews->fetchAll()]);
    }

    public static function submitReview(string $id): never
    {
        $user = AuthMiddleware::user();
        AuthMiddleware::csrf();
        $productId = filter_var($id, FILTER_VALIDATE_INT);
        $data = request_data();
        $stars = filter_var($data['estrelas'] ?? null, FILTER_VALIDATE_INT);
        $comment = trim((string) ($data['comentario'] ?? ''));
        if (!$productId || $stars === false || $stars < 1 || $stars > 5 || mb_strlen($comment) > 1500) {
            Response::error('Informe uma nota de 1 a 5 e um comentário de até 1.500 caracteres.', 422);
        }

        $db = Database::connection();
        $product = $db->prepare('SELECT p.id FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE p.id = :id AND p.ativo = 1 AND (c.ativo = 1 OR c.id IS NULL)');
        $product->execute(['id' => $productId]);
        if (!$product->fetchColumn()) {
            Response::error('Produto não encontrado.', 404);
        }

        $purchase = $db->prepare("SELECT 1 FROM itens_pedido i JOIN pedidos p ON p.id = i.pedido_id WHERE p.usuario_id = :user AND i.produto_id = :product AND p.status = 'entregue' LIMIT 1");
        $purchase->execute(['user' => (int) $user['id'], 'product' => $productId]);
        if (!$purchase->fetchColumn()) {
            Response::error('A avaliação fica disponível após a entrega do produto.', 403);
        }

        $save = $db->prepare('INSERT INTO avaliacoes (usuario_id, produto_id, estrelas, comentario) VALUES (:user, :product, :stars, :comment) ON DUPLICATE KEY UPDATE estrelas = VALUES(estrelas), comentario = VALUES(comentario), updated_at = NOW()');
        $save->execute(['user' => (int) $user['id'], 'product' => $productId, 'stars' => $stars, 'comment' => $comment]);
        Response::success(['salva' => true]);
    }

    public static function categories(): never
    {
        $query = Database::connection()->prepare('SELECT id, nome, slug FROM categorias WHERE ativo = 1 ORDER BY nome');
        $query->execute();
        Response::success($query->fetchAll());
    }
}