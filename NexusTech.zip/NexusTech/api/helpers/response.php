<?php
declare(strict_types=1);

namespace App\Api;

final class Response
{
    public static function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        exit;
    }

    public static function success(mixed $data = null, int $status = 200, array $meta = []): never
    {
        self::json(['success' => true, 'data' => $data, 'meta' => $meta], $status);
    }

    public static function error(string $message, int $status = 400, array $details = []): never
    {
        self::json(['success' => false, 'error' => ['message' => $message, 'details' => $details]], $status);
    }
}