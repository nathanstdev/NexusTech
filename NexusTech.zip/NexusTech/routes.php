<?php
declare(strict_types=1);

use App\Api\Response;
use App\Controllers\AuthController;
use App\Controllers\OrderController;
use App\Controllers\PageController;
use App\Controllers\ProductController;
use App\Controllers\ReportController;
use App\Database;
use App\Middleware\AuthMiddleware;
use App\Services\AuthService;
use App\Services\InventoryService;
use App\Services\OrderService;
use App\Services\PurchaseService;
use App\Services\ErpOperationsService;

$router->get('/', [PageController::class, 'storefront']);

$router->get('/produto/{id}', [PageController::class, 'product']);

$router->get('/api/v1/csrf', static function (): void { Response::success(['token' => csrf_token()]); });
$router->get('/api/v1/produtos', [ProductController::class, 'index']);

$router->get('/api/v1/produtos/{id}', [ProductController::class, 'show']);

$router->get('/api/v1/produtos/{id}/relacionados', [ProductController::class, 'related']);

$router->get('/api/v1/produtos/{id}/avaliacoes', [ProductController::class, 'reviews']);
$router->post('/api/v1/produtos/{id}/avaliacoes', [ProductController::class, 'submitReview']);

$router->get('/api/v1/categorias', [ProductController::class, 'categories']);

$router->get('/login', [PageController::class, 'login']);
$router->get('/cadastro', [PageController::class, 'register']);
$router->get('/recuperar-senha', [PageController::class, 'recover']);
$router->get('/redefinir-senha', [PageController::class, 'resetPassword']);

$router->post('/api/v1/auth/register', [AuthController::class, 'register']);
$router->post('/api/v1/auth/login', [AuthController::class, 'login']);
$router->get('/api/v1/auth/me', [AuthController::class, 'me']);
$router->post('/api/v1/auth/logout', [AuthController::class, 'logout']);

$router->get('/api/v1/pedidos', [OrderController::class, 'index']);
$router->post('/api/v1/pedidos', [OrderController::class, 'create']);
$router->get('/api/v1/pedidos/{id}', [OrderController::class, 'show']);
$router->post('/api/v1/pedidos/{id}/cancelar', [OrderController::class, 'cancel']);

$router->get('/api/v1/admin/dashboard', [ReportController::class, 'dashboard']);

$router->get('/api/v1/admin/produtos', static function (): never {
    AuthMiddleware::user('admin');
    $query = Database::connection()->prepare('SELECT p.*, c.nome AS categoria FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id ORDER BY p.nome');
    $query->execute();
    Response::success($query->fetchAll());
});

$router->post('/api/v1/admin/produtos', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $name = trim((string) ($data['nome'] ?? ''));
    $sku = trim((string) ($data['sku'] ?? ''));
    $price = filter_var($data['preco'] ?? null, FILTER_VALIDATE_FLOAT);
    $cost = filter_var($data['custo'] ?? 0, FILTER_VALIDATE_FLOAT);
    $minimum = filter_var($data['estoque_minimo'] ?? 0, FILTER_VALIDATE_INT);
    $image = trim((string) ($data['imagem_url'] ?? ''));
    if (mb_strlen($name) < 1 || mb_strlen($name) > 180 || mb_strlen($sku) < 1 || mb_strlen($sku) > 80 || $price === false || $price < 0 || $price > 10000000 || $cost === false || $cost < 0 || $cost > 10000000 || $minimum === false || $minimum < 0 || ($image !== '' && (filter_var($image, FILTER_VALIDATE_URL) === false || !in_array(parse_url($image, PHP_URL_SCHEME), ['http', 'https'], true)))) {
        Response::error('Nome, SKU e preço válido são obrigatórios.', 422);
    }
    $gallery = $data['imagens'] ?? [];
    if (!is_array($gallery) || count($gallery) > 5) {
        Response::error('A galeria pode conter até 5 URLs.', 422);
    }
    foreach ($gallery as $galleryImage) {
        if (!is_string($galleryImage) || filter_var($galleryImage, FILTER_VALIDATE_URL) === false || !in_array(parse_url($galleryImage, PHP_URL_SCHEME), ['http', 'https'], true)) {
            Response::error('URL de galeria inválida.', 422);
        }
    }
    $db = Database::connection();
    $insert = $db->prepare('INSERT INTO produtos (categoria_id, fornecedor_id, sku, codigo_barras, nome, descricao, custo, preco, estoque, estoque_minimo, imagem_url, imagens) VALUES (:category, :supplier, :sku, :barcode, :name, :description, :cost, :price, 0, :minimum, :image, :gallery)');
    $insert->execute(['category' => filter_var($data['categoria_id'] ?? null, FILTER_VALIDATE_INT) ?: null, 'supplier' => filter_var($data['fornecedor_id'] ?? null, FILTER_VALIDATE_INT) ?: null, 'sku' => $sku, 'barcode' => $data['codigo_barras'] ?? null, 'name' => $name, 'description' => mb_substr((string) ($data['descricao'] ?? ''), 0, 5000), 'cost' => $cost, 'price' => $price, 'minimum' => $minimum, 'image' => $image !== '' ? $image : null, 'gallery' => json_encode(array_values($gallery), JSON_THROW_ON_ERROR)]);
    $id = (int) $db->lastInsertId();
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'produto_criado', 'produto', :id, :details, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => $id, 'details' => json_encode(['sku' => $sku, 'preco' => $price]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => $id], 201);
});

$router->patch('/api/v1/admin/produtos/{id}', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $fields = ['nome' => 'nome', 'sku' => 'sku', 'preco' => 'preco', 'custo' => 'custo', 'estoque_minimo' => 'estoque_minimo', 'descricao' => 'descricao', 'categoria_id' => 'categoria_id', 'fornecedor_id' => 'fornecedor_id', 'imagem_url' => 'imagem_url', 'imagens' => 'imagens', 'ativo' => 'ativo'];
    $updates = [];
    $params = ['id' => (int) $id];
    foreach ($fields as $key => $column) {
        if (array_key_exists($key, $data)) {
            $value = $data[$key];
            if (in_array($key, ['preco', 'custo'], true)) {
                $value = filter_var($value, FILTER_VALIDATE_FLOAT);
                if ($value === false || $value < 0 || $value > 10000000) {
                    Response::error("Valor inválido para {$key}.", 422);
                }
            } elseif (in_array($key, ['estoque_minimo', 'categoria_id', 'fornecedor_id'], true)) {
                if ($value === null || $value === '') {
                    if ($key === 'estoque_minimo') {
                        Response::error('Estoque mínimo inválido.', 422);
                    }
                    $value = null;
                } else {
                    $value = filter_var($value, FILTER_VALIDATE_INT);
                    if ($value === false || $value < ($key === 'estoque_minimo' ? 0 : 1)) {
                        Response::error("Valor inválido para {$key}.", 422);
                    }
                }
            } elseif ($key === 'ativo') {
                $value = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($value === null) {
                    Response::error('Estado do produto inválido.', 422);
                }
                $value = (int) $value;
            } elseif (in_array($key, ['nome', 'sku', 'descricao'], true)) {
                $value = trim((string) $value);
                $maxLength = ['nome' => 180, 'sku' => 80, 'descricao' => 5000][$key];
                if (($key !== 'descricao' && $value === '') || mb_strlen($value) > $maxLength) {
                    Response::error("Valor inválido para {$key}.", 422);
                }
            } elseif ($key === 'imagem_url' && $value !== null && $value !== '') {
                $value = trim((string) $value);
                if (mb_strlen($value) > 500 || filter_var($value, FILTER_VALIDATE_URL) === false || !in_array(parse_url($value, PHP_URL_SCHEME), ['http', 'https'], true)) {
                    Response::error('URL da imagem inválida.', 422);
                }
            } elseif ($key === 'imagem_url') {
                $value = null;
            } elseif ($key === 'imagens') {
                if (!is_array($value) || count($value) > 5) {
                    Response::error('A galeria pode conter até 5 URLs.', 422);
                }
                foreach ($value as $galleryImage) {
                    if (!is_string($galleryImage) || mb_strlen($galleryImage) > 500 || filter_var($galleryImage, FILTER_VALIDATE_URL) === false || !in_array(parse_url($galleryImage, PHP_URL_SCHEME), ['http', 'https'], true)) {
                        Response::error('URL de galeria inválida.', 422);
                    }
                }
                $value = json_encode(array_values($value), JSON_THROW_ON_ERROR);
            }
            $updates[] = "$column = :$key";
            $params[$key] = $value;
        }
    }
    if ($updates === []) {
        Response::error('Nenhum campo para atualizar.', 422);
    }
    $db = Database::connection();
    $update = $db->prepare('UPDATE produtos SET ' . implode(', ', $updates) . ', updated_at = NOW() WHERE id = :id');
    $update->execute($params);
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'produto_atualizado', 'produto', :id, :details, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => (int) $id, 'details' => json_encode($data), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => (int) $id, 'updated' => $update->rowCount()]);
});

$router->delete('/api/v1/admin/produtos/{id}', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $productId = filter_var($id, FILTER_VALIDATE_INT) ?: 0;
    $db = Database::connection();
    $update = $db->prepare('UPDATE produtos SET ativo = 0, updated_at = NOW() WHERE id = :id AND ativo = 1');
    $update->execute(['id' => $productId]);
    if ($update->rowCount() < 1) {
        Response::error('Produto não encontrado ou já inativo.', 404);
    }
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'produto_desativado', 'produto', :id, NULL, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => $productId, 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => $productId, 'ativo' => false]);
});

$router->post('/api/v1/admin/estoque/{id}', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        (new InventoryService(Database::connection()))->change((int) $id, (int) ($data['quantidade'] ?? 0), trim((string) ($data['motivo'] ?? '')), (int) $user['id'], (string) ($data['tipo'] ?? 'ajuste'));
        Response::success(['produto_id' => (int) $id]);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->post('/api/v1/admin/pedidos/{id}/status', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $status = (string) (request_data()['status'] ?? '');
    if ($status === 'cancelado') {
        try {
            (new OrderService(Database::connection()))->cancel((int) $id, (int) $user['id'], true);
            Response::success(['id' => (int) $id, 'status' => $status]);
        } catch (RuntimeException $error) {
            Response::error($error->getMessage(), 422);
        }
    }
    if (!in_array($status, ['pago', 'separado', 'enviado', 'entregue'], true)) {
        Response::error('Status inválido.', 422);
    }
    $db = Database::connection();
    $db->beginTransaction();
    try {
        $query = $db->prepare('SELECT status FROM pedidos WHERE id = :id FOR UPDATE');
        $query->execute(['id' => (int) $id]);
        $current = $query->fetchColumn();
        $transitions = ['pendente' => ['pago'], 'pago' => ['separado'], 'separado' => ['enviado'], 'enviado' => ['entregue']];
        if (!is_string($current) || ($current !== $status && !in_array($status, $transitions[$current] ?? [], true))) {
            throw new RuntimeException('Transição de status inválida para este pedido.');
        }
        if ($current !== $status) {
            $update = $db->prepare('UPDATE pedidos SET status = :status, updated_at = NOW() WHERE id = :id');
            $update->execute(['status' => $status, 'id' => (int) $id]);
            if ($status === 'pago') {
                $receivable = $db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, pago_em, status, usuario_id) SELECT 'receber', 'pedido', p.id, CONCAT('Pedido #', p.id), u.nome, p.total, CURRENT_DATE, NOW(), 'paga', p.usuario_id FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = :order ON DUPLICATE KEY UPDATE status = 'paga', pago_em = NOW()");
                $receivable->execute(['order' => (int) $id]);
            }
            $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'pedido_status', 'pedido', :id, :details, :ip)");
            $audit->execute(['user' => $user['id'], 'id' => (int) $id, 'details' => json_encode(['status_anterior' => $current, 'status' => $status]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
        }
        $db->commit();
    } catch (RuntimeException $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        Response::error($error->getMessage(), 422);
    }
    Response::success(['id' => (int) $id, 'status' => $status]);
});

$router->post('/api/v1/webhooks/pagamento', static function (): never {
    $timestampHeader = (string) ($_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '');
    $timestamp = ctype_digit($timestampHeader) ? (int) $timestampHeader : 0;
    $signature = (string) ($_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '');
    $body = file_get_contents('php://input') ?: '';
    $secret = $_ENV['WEBHOOK_SECRET'] ?? '';
    if ($secret === '' || abs(time() - $timestamp) > 300 || !hash_equals(hash_hmac('sha256', $timestamp . '.' . $body, $secret), $signature)) {
        Response::error('Assinatura inválida ou timestamp expirado.', 401);
    }
    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['event_id']) || empty($data['pedido_id'])) {
        Response::error('Evento inválido.', 400);
    }
    $db = Database::connection();
    try {
        $db->beginTransaction();
        $event = $db->prepare('INSERT INTO webhook_eventos (evento_id) VALUES (:id)');
        $event->execute(['id' => substr((string) $data['event_id'], 0, 120)]);
        if (($data['status'] ?? '') === 'pago') {
            $update = $db->prepare("UPDATE pedidos SET status = 'pago', updated_at = NOW() WHERE id = :id AND status = 'pendente'");
            $update->execute(['id' => (int) $data['pedido_id']]);
            if ($update->rowCount() === 1) {
                $receivable = $db->prepare("INSERT INTO contas_financeiras (tipo, origem_tipo, origem_id, descricao, contraparte, valor, vencimento, pago_em, status, usuario_id) SELECT 'receber', 'pedido', p.id, CONCAT('Pedido #', p.id), u.nome, p.total, CURRENT_DATE, NOW(), 'paga', p.usuario_id FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id WHERE p.id = :order ON DUPLICATE KEY UPDATE status = 'paga', pago_em = NOW()");
                $receivable->execute(['order' => (int) $data['pedido_id']]);
            }
        }
        $mark = $db->prepare('UPDATE webhook_eventos SET processado_em = NOW() WHERE evento_id = :id');
        $mark->execute(['id' => $data['event_id']]);
        $db->commit();
    } catch (PDOException $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        if ($error->getCode() === '23000') {
            Response::success(['duplicado' => true]);
        }
        throw $error;
    }
    Response::success(['recebido' => true]);
});

$router->get('/admin', [PageController::class, 'admin']);

$router->get('/meus-pedidos', [PageController::class, 'orders']);

$router->post('/api/v1/auth/recover', [AuthController::class, 'recover']);
$router->post('/api/v1/auth/reset-password', [AuthController::class, 'resetPassword']);

$router->get('/checkout', [PageController::class, 'checkout']);

$router->post('/api/v1/cupons/validar', static function (): never {
    AuthMiddleware::user();
    AuthMiddleware::csrf();
    $data = request_data();
    $code = strtoupper(substr(trim((string) ($data['codigo'] ?? '')), 0, 40));
    $subtotal = max(0, (float) ($data['subtotal'] ?? 0));
    $query = Database::connection()->prepare('SELECT tipo, valor, minimo_pedido, usos_maximos, usos FROM cupons WHERE codigo = :code AND ativo = 1 AND (expira_em IS NULL OR expira_em > NOW())');
    $query->execute(['code' => $code]);
    $coupon = $query->fetch();
    if (!$coupon || $subtotal < (float) $coupon['minimo_pedido'] || ($coupon['usos_maximos'] !== null && (int) $coupon['usos'] >= (int) $coupon['usos_maximos'])) {
        Response::error('Cupom inválido ou indisponível para este pedido.', 422);
    }
    $discount = $coupon['tipo'] === 'percentual' ? $subtotal * (float) $coupon['valor'] / 100 : (float) $coupon['valor'];
    Response::success(['desconto' => min($subtotal, $discount)]);
});

$router->get('/api/v1/admin/usuarios', static function (): never {
    AuthMiddleware::user('admin');
    $db = Database::connection();
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $perPage = max(1, min(100, (int) ($_GET['per_page'] ?? 25)));
    $search = '%' . mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100) . '%';
    $count = $db->prepare('SELECT COUNT(*) FROM usuarios WHERE nome LIKE :name OR email LIKE :email');
    $count->execute(['name' => $search, 'email' => $search]);
    $total = (int) $count->fetchColumn();
    $list = $db->prepare('SELECT id, nome, email, role, ativo, created_at FROM usuarios WHERE nome LIKE :name OR email LIKE :email ORDER BY created_at DESC LIMIT :limit OFFSET :offset');
    $list->bindValue(':name', $search, PDO::PARAM_STR);
    $list->bindValue(':email', $search, PDO::PARAM_STR);
    $list->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $list->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
    $list->execute();
    Response::success($list->fetchAll(), 200, ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => (int) ceil($total / $perPage)]);
});

$router->post('/api/v1/admin/usuarios', static function (): never {
    $admin = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $name = trim((string) ($data['nome'] ?? ''));
    $email = mb_strtolower(trim((string) ($data['email'] ?? '')));
    $password = (string) ($data['senha'] ?? '');
    $role = (string) ($data['role'] ?? 'cliente');
    if (mb_strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12 || !in_array($role, ['cliente', 'admin'], true)) {
        Response::error('Nome, e-mail, senha com 12 caracteres e perfil válido são obrigatórios.', 422);
    }
    $db = Database::connection();
    $insert = $db->prepare('INSERT INTO usuarios (nome, email, senha, role, ativo) VALUES (:name, :email, :password, :role, 1)');
    try {
        $insert->execute(['name' => $name, 'email' => $email, 'password' => password_hash($password, PASSWORD_ARGON2ID), 'role' => $role]);
    } catch (PDOException $error) {
        if ($error->getCode() === '23000') {
            Response::error('Este e-mail já está cadastrado.', 409);
        }
        throw $error;
    }
    $id = (int) $db->lastInsertId();
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:admin, 'usuario_criado', 'usuario', :id, :details, :ip)");
    $audit->execute(['admin' => $admin['id'], 'id' => $id, 'details' => json_encode(['role' => $role]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => $id], 201);
});

$router->patch('/api/v1/admin/usuarios/{id}', static function (string $id): never {
    $admin = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    if (isset($data['role']) && !in_array($data['role'], ['cliente', 'admin'], true)) {
        Response::error('Perfil inválido.', 422);
    }
    if (isset($data['ativo']) && !in_array((string) $data['ativo'], ['0', '1'], true)) {
        Response::error('Estado de usuário inválido.', 422);
    }
    $targetId = filter_var($id, FILTER_VALIDATE_INT) ?: 0;
    $db = Database::connection();
    $db->beginTransaction();
    try {
        $query = $db->prepare('SELECT id, role, ativo FROM usuarios WHERE id = :id FOR UPDATE');
        $query->execute(['id' => $targetId]);
        $target = $query->fetch();
        if (!$target) {
            throw new RuntimeException('Usuário não encontrado.');
        }
        $willRemoveAdmin = $target['role'] === 'admin' && ($data['role'] ?? 'admin') !== 'admin';
        $willDisableAdmin = $target['role'] === 'admin' && (string) ($data['ativo'] ?? '1') === '0';
        if ((int) $admin['id'] === $targetId && ($willRemoveAdmin || $willDisableAdmin)) {
            throw new RuntimeException('Você não pode remover o próprio acesso administrativo.');
        }
        if ($willRemoveAdmin || $willDisableAdmin) {
            $adminQuery = $db->prepare("SELECT id FROM usuarios WHERE role = 'admin' AND ativo = 1 FOR UPDATE");
            $adminQuery->execute();
            $admins = $adminQuery->fetchAll();
            if (count($admins) <= 1) {
                throw new RuntimeException('O sistema precisa manter ao menos um administrador ativo.');
            }
        }
        $fields = [];
        $params = ['id' => $targetId];
        if (isset($data['nome'])) {
            $fields[] = 'nome = :name';
            $params['name'] = mb_substr(trim((string) $data['nome']), 0, 120);
        }
        if (isset($data['email']) && filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $fields[] = 'email = :email';
            $params['email'] = mb_strtolower(trim((string) $data['email']));
        } elseif (isset($data['email'])) {
            throw new RuntimeException('E-mail inválido.');
        }
        foreach (['role', 'ativo'] as $field) {
            if (array_key_exists($field, $data)) {
                $fields[] = "$field = :$field";
                $params[$field] = $data[$field];
            }
        }
        if ($fields === []) {
            throw new RuntimeException('Nenhum campo para atualizar.');
        }
        $update = $db->prepare('UPDATE usuarios SET ' . implode(', ', $fields) . ' WHERE id = :id');
        $update->execute($params);
        $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:admin, 'usuario_atualizado', 'usuario', :id, :details, :ip)");
        $audit->execute(['admin' => $admin['id'], 'id' => $targetId, 'details' => json_encode($data), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
        $db->commit();
    } catch (RuntimeException $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        Response::error($error->getMessage(), 422);
    }
    Response::success(['id' => $targetId, 'updated' => true]);
});

$router->post('/api/v1/admin/usuarios/{id}/recuperar-senha', static function (string $id): never {
    AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $query = Database::connection()->prepare('SELECT email FROM usuarios WHERE id = :id AND ativo = 1');
    $query->execute(['id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0]);
    $email = $query->fetchColumn();
    if (!is_string($email)) {
        Response::error('Usuário não encontrado.', 404);
    }
    (new AuthService(Database::connection()))->requestPasswordReset($email);
    Response::success(['sent' => true]);
});

$router->get('/api/v1/admin/fornecedores', static function (): never {
    AuthMiddleware::user('admin');
    $query = Database::connection()->prepare('SELECT id, nome, documento, email, telefone, ativo, created_at FROM fornecedores ORDER BY nome');
    $query->execute();
    Response::success($query->fetchAll());
});

$router->post('/api/v1/admin/fornecedores', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $name = trim((string) ($data['nome'] ?? ''));
    $email = trim((string) ($data['email'] ?? ''));
    if ($name === '' || mb_strlen($name) > 160 || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))) {
        Response::error('Nome e e-mail válido do fornecedor são obrigatórios.', 422);
    }
    $db = Database::connection();
    $insert = $db->prepare('INSERT INTO fornecedores (nome, documento, email, telefone) VALUES (:name, :document, :email, :phone)');
    $insert->execute(['name' => $name, 'document' => $data['documento'] ?? null, 'email' => $email !== '' ? $email : null, 'phone' => $data['telefone'] ?? null]);
    $id = (int) $db->lastInsertId();
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'fornecedor_criado', 'fornecedor', :id, NULL, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => $id, 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => $id], 201);
});

$router->patch('/api/v1/admin/fornecedores/{id}', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $active = filter_var($data['ativo'] ?? null, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($active === null) {
        Response::error('Informe o estado ativo do fornecedor.', 422);
    }
    $db = Database::connection();
    $supplierId = filter_var($id, FILTER_VALIDATE_INT) ?: 0;
    $db->beginTransaction();
    try {
        $update = $db->prepare('UPDATE fornecedores SET ativo = :active WHERE id = :id');
        $update->execute(['active' => (int) $active, 'id' => $supplierId]);
        $updated = $update->rowCount() > 0;
        if ($updated) {
            $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'fornecedor_status', 'fornecedor', :id, :details, :ip)");
            $audit->execute([
                'user' => $user['id'],
                'id' => $supplierId,
                'details' => json_encode(['ativo' => (bool) $active], JSON_THROW_ON_ERROR),
                'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
        }
        $db->commit();
    } catch (Throwable $error) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        throw $error;
    }
    Response::success(['updated' => $updated]);
});

$router->post('/api/v1/admin/compras', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        $warehouseId = isset($data['armazem_id']) && $data['armazem_id'] !== '' ? filter_var($data['armazem_id'], FILTER_VALIDATE_INT) : null;
        if ($warehouseId === false) {
            Response::error('Armazém inválido.', 422);
        }
        $purchaseId = (new PurchaseService(Database::connection()))->receive((int) ($data['fornecedor_id'] ?? 0), (int) $user['id'], is_array($data['itens'] ?? null) ? $data['itens'] : [], isset($data['nota_fiscal']) ? (string) $data['nota_fiscal'] : null, $warehouseId);
        Response::success(['id' => $purchaseId], 201);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->get('/api/v1/admin/estoque/movimentacoes', static function (): never {
    AuthMiddleware::user('admin');
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $perPage = max(1, min(100, (int) ($_GET['per_page'] ?? 50)));
    $query = Database::connection()->prepare('SELECT m.id, m.tipo, m.quantidade, m.motivo, m.created_at, p.nome AS produto, p.sku, u.nome AS usuario, a.nome AS armazem, l.numero_lote, l.serie FROM movimentacoes_estoque m JOIN produtos p ON p.id = m.produto_id JOIN usuarios u ON u.id = m.usuario_id LEFT JOIN armazens a ON a.id = m.armazem_id LEFT JOIN lotes_estoque l ON l.id = m.lote_id ORDER BY m.created_at DESC LIMIT :limit OFFSET :offset');
    $query->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $query->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
    $query->execute();
    $countQuery = Database::connection()->prepare('SELECT COUNT(*) FROM movimentacoes_estoque');
    $countQuery->execute();
    $total = (int) $countQuery->fetchColumn();
    Response::success($query->fetchAll(), 200, ['page' => $page, 'per_page' => $perPage, 'total' => $total, 'pages' => (int) ceil($total / $perPage)]);
});

$router->get('/api/v1/conta', static function (): never {
    $user = AuthMiddleware::user();
    $query = Database::connection()->prepare('SELECT id, nome, email, created_at FROM usuarios WHERE id = :id');
    $query->execute(['id' => $user['id']]);
    Response::success($query->fetch());
});

$router->patch('/api/v1/conta', static function (): never {
    $user = AuthMiddleware::user();
    AuthMiddleware::csrf();
    $data = request_data();
    $name = trim((string) ($data['nome'] ?? ''));
    $email = mb_strtolower(trim((string) ($data['email'] ?? '')));
    if (mb_strlen($name) < 2 || mb_strlen($name) > 120 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        Response::error('Informe nome e e-mail válidos.', 422);
    }
    $db = Database::connection();
    $update = $db->prepare('UPDATE usuarios SET nome = :name, email = :email WHERE id = :id');
    try {
        $update->execute(['name' => $name, 'email' => $email, 'id' => $user['id']]);
    } catch (PDOException $error) {
        if ($error->getCode() === '23000') {
            Response::error('Este e-mail já está em uso.', 409);
        }
        throw $error;
    }
    $_SESSION['user']['nome'] = $name;
    $_SESSION['user']['email'] = $email;
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'perfil_atualizado', 'usuario', :id, NULL, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => $user['id'], 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['nome' => $name, 'email' => $email]);
});

$router->get('/api/v1/enderecos', static function (): never {
    $user = AuthMiddleware::user();
    $query = Database::connection()->prepare('SELECT id, apelido, destinatario, cep, logradouro, numero, complemento, bairro, cidade, estado FROM enderecos WHERE usuario_id = :user ORDER BY created_at DESC');
    $query->execute(['user' => $user['id']]);
    Response::success($query->fetchAll());
});

$router->post('/api/v1/enderecos', static function (): never {
    $user = AuthMiddleware::user();
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        $address = sanitize_address($data);
    } catch (InvalidArgumentException $error) {
        Response::error($error->getMessage(), 422);
    }
    $query = Database::connection()->prepare('INSERT INTO enderecos (usuario_id, apelido, destinatario, cep, logradouro, numero, complemento, bairro, cidade, estado) VALUES (:user, :label, :recipient, :zip, :street, :number, :complement, :district, :city, :state)');
    $query->execute(['user' => $user['id'], 'label' => mb_substr(trim((string) ($data['apelido'] ?? 'Principal')), 0, 60), 'recipient' => $address['destinatario'], 'zip' => $address['cep'], 'street' => $address['logradouro'], 'number' => $address['numero'], 'complement' => $address['complemento'] !== '' ? $address['complemento'] : null, 'district' => $address['bairro'], 'city' => $address['cidade'], 'state' => $address['estado']]);
    Response::success(['id' => (int) Database::connection()->lastInsertId()], 201);
});

$router->delete('/api/v1/enderecos/{id}', static function (string $id): never {
    $user = AuthMiddleware::user();
    AuthMiddleware::csrf();
    $query = Database::connection()->prepare('DELETE FROM enderecos WHERE id = :id AND usuario_id = :user');
    $query->execute(['id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0, 'user' => $user['id']]);
    if ($query->rowCount() < 1) {
        Response::error('Endereço não encontrado.', 404);
    }
    Response::success(['deleted' => true]);
});

$router->get('/conta', [PageController::class, 'account']);

$router->get('/api/v1/admin/categorias', static function (): never {
    AuthMiddleware::user('admin');
    $query = Database::connection()->prepare('SELECT id, nome, slug, descricao, ativo FROM categorias ORDER BY nome');
    $query->execute();
    Response::success($query->fetchAll());
});

$router->post('/api/v1/admin/categorias', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $name = trim((string) ($data['nome'] ?? ''));
    $slug = strtolower(trim((string) ($data['slug'] ?? '')));
    if ($name === '' || mb_strlen($name) > 100 || !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug) || mb_strlen($slug) > 120) {
        Response::error('Nome e slug válido são obrigatórios.', 422);
    }
    $db = Database::connection();
    try {
        $insert = $db->prepare('INSERT INTO categorias (nome, slug, descricao) VALUES (:name, :slug, :description)');
        $insert->execute(['name' => $name, 'slug' => $slug, 'description' => mb_substr(trim((string) ($data['descricao'] ?? '')), 0, 500)]);
    } catch (PDOException $error) {
        if ($error->getCode() === '23000') {
            Response::error('Nome ou slug já cadastrado.', 409);
        }
        throw $error;
    }
    $id = (int) $db->lastInsertId();
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'categoria_criada', 'categoria', :id, :details, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => $id, 'details' => json_encode(['nome' => $name, 'slug' => $slug]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => $id], 201);
});

$router->patch('/api/v1/admin/categorias/{id}', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $active = filter_var($data['ativo'] ?? null, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($active === null) {
        Response::error('Informe o estado ativo da categoria.', 422);
    }
    $db = Database::connection();
    $update = $db->prepare('UPDATE categorias SET ativo = :active WHERE id = :id');
    $update->execute(['active' => (int) $active, 'id' => filter_var($id, FILTER_VALIDATE_INT) ?: 0]);
    if ($update->rowCount() < 1) {
        Response::error('Categoria não encontrada ou sem alterações.', 404);
    }
    $audit = $db->prepare("INSERT INTO logs_auditoria (usuario_id, acao, entidade, entidade_id, detalhes, ip) VALUES (:user, 'categoria_status', 'categoria', :id, :details, :ip)");
    $audit->execute(['user' => $user['id'], 'id' => (int) $id, 'details' => json_encode(['ativo' => (bool) $active]), 'ip' => $_SERVER['REMOTE_ADDR'] ?? null]);
    Response::success(['id' => (int) $id, 'ativo' => (bool) $active]);
});

$router->get('/api/v1/admin/compras', static function (): never {
    AuthMiddleware::user('admin');
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $perPage = max(1, min(100, (int) ($_GET['per_page'] ?? 50)));
    $db = Database::connection();
    $countQuery = $db->prepare('SELECT COUNT(*) FROM compras');
    $countQuery->execute();
    $count = (int) $countQuery->fetchColumn();
    $query = $db->prepare('SELECT c.id, c.nota_fiscal, c.total, c.status, c.created_at, f.nome AS fornecedor, u.nome AS operador FROM compras c JOIN fornecedores f ON f.id = c.fornecedor_id JOIN usuarios u ON u.id = c.usuario_id ORDER BY c.created_at DESC LIMIT :limit OFFSET :offset');
    $query->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $query->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
    $query->execute();
    Response::success($query->fetchAll(), 200, ['page' => $page, 'per_page' => $perPage, 'total' => $count, 'pages' => (int) ceil($count / $perPage)]);
});

$router->get('/admin/gerar_pdf.php', static function (): void {
    AuthMiddleware::user('admin');
    require __DIR__ . '/admin/gerar_pdf.php';
});

$router->get('/api/v1/admin/armazens', static function (): never {
    AuthMiddleware::user('admin');
    Response::success((new ErpOperationsService(Database::connection()))->warehouses());
});

$router->post('/api/v1/admin/armazens', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        $id = (new ErpOperationsService(Database::connection()))->createWarehouse((int) $user['id'], (string) ($data['nome'] ?? ''), (string) ($data['codigo'] ?? ''), isset($data['descricao']) ? (string) $data['descricao'] : null);
        Response::success(['id' => $id], 201);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->get('/api/v1/admin/armazens/estoque', static function (): never {
    AuthMiddleware::user('admin');
    $warehouse = isset($_GET['armazem_id']) ? filter_var($_GET['armazem_id'], FILTER_VALIDATE_INT) : null;
    if ($warehouse === false) {
        Response::error('Armazém inválido.', 422);
    }
    Response::success((new ErpOperationsService(Database::connection()))->warehouseStock($warehouse));
});

$router->get('/api/v1/admin/lotes', static function (): never {
    AuthMiddleware::user('admin');
    $warehouse = isset($_GET['armazem_id']) ? filter_var($_GET['armazem_id'], FILTER_VALIDATE_INT) : null;
    if ($warehouse === false) {
        Response::error('Armazém inválido.', 422);
    }
    Response::success((new ErpOperationsService(Database::connection()))->lots($warehouse));
});

$router->post('/api/v1/admin/armazens/transferencias', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        $id = (new ErpOperationsService(Database::connection()))->transfer((int) ($data['origem_id'] ?? 0), (int) ($data['destino_id'] ?? 0), (int) $user['id'], is_array($data['itens'] ?? null) ? $data['itens'] : [], (string) ($data['motivo'] ?? ''));
        Response::success(['id' => $id], 201);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->get('/api/v1/admin/inventarios', static function (): never {
    AuthMiddleware::user('admin');
    $service = new ErpOperationsService(Database::connection());
    if (isset($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
        if (!$id) {
            Response::error('Inventário inválido.', 422);
        }
        Response::success(['inventarios' => $service->inventories(), 'itens' => $service->inventoryItems($id)]);
    }
    Response::success($service->inventories());
});

$router->post('/api/v1/admin/inventarios', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    try {
        $id = (new ErpOperationsService(Database::connection()))->startInventory((int) ($data['armazem_id'] ?? 0), (int) $user['id'], isset($data['observacao']) ? (string) $data['observacao'] : null);
        Response::success(['id' => $id], 201);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->patch('/api/v1/admin/inventarios/{id}/itens/{produto}', static function (string $id, string $product): never {
    AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $data = request_data();
    $inventoryId = filter_var($id, FILTER_VALIDATE_INT);
    $productId = filter_var($product, FILTER_VALIDATE_INT);
    $quantity = filter_var($data['quantidade_contada'] ?? null, FILTER_VALIDATE_INT);
    if (!$inventoryId || !$productId || $quantity === false) {
        Response::error('Inventário, produto ou quantidade inválida.', 422);
    }
    try {
        (new ErpOperationsService(Database::connection()))->countInventory($inventoryId, $productId, $quantity);
        Response::success(['contado' => true]);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->post('/api/v1/admin/inventarios/{id}/concluir', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $inventoryId = filter_var($id, FILTER_VALIDATE_INT);
    if (!$inventoryId) {
        Response::error('Inventário inválido.', 422);
    }
    try {
        (new ErpOperationsService(Database::connection()))->completeInventory($inventoryId, (int) $user['id']);
        Response::success(['concluido' => true]);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->get('/api/v1/admin/financeiro', static function (): never {
    AuthMiddleware::user('admin');
    $service = new ErpOperationsService(Database::connection());
    $type = (string) ($_GET['tipo'] ?? '');
    try {
        Response::success(['contas' => $service->financialAccounts($type), ...$service->financialSummary()]);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->post('/api/v1/admin/financeiro', static function (): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    try {
        $id = (new ErpOperationsService(Database::connection()))->createFinancialAccount((int) $user['id'], request_data());
        Response::success(['id' => $id], 201);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->post('/api/v1/admin/financeiro/{id}/pagar', static function (string $id): never {
    $user = AuthMiddleware::user('admin');
    AuthMiddleware::csrf();
    $accountId = filter_var($id, FILTER_VALIDATE_INT);
    if (!$accountId) {
        Response::error('Conta financeira inválida.', 422);
    }
    try {
        (new ErpOperationsService(Database::connection()))->settleFinancialAccount($accountId, (int) $user['id']);
        Response::success(['paga' => true]);
    } catch (RuntimeException $error) {
        Response::error($error->getMessage(), 422);
    }
});

$router->get('/api/v1/admin/insights', static function (): never {
    AuthMiddleware::user('admin');
    Response::success((new ErpOperationsService(Database::connection()))->operationalInsights());
});