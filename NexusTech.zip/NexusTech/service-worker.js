const cacheName = 'nexus-static-v2';
const assets = ['assets/css/style.css', 'assets/css/app.css', 'assets/css/refinements.css', 'assets/css/navbar.css', 'assets/js/main.js', 'assets/js/api-client.js', 'assets/js/navbar.js'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(cacheName).then((cache) => Promise.all(assets.map((asset) => cache.add(new URL(asset, self.registration.scope).href)))).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== cacheName).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.includes('/api/')) return;
  if (assets.some((asset) => url.pathname.endsWith(`/${asset}`))) {
    event.respondWith(caches.match(request).then((cached) => cached ?? fetch(request)));
  }
});