<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';

use App\Http\Router;

$router = new Router();
require __DIR__ . '/routes.php';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$basePath = base_path();
if ($basePath !== '' && strcasecmp(substr($path, 0, strlen($basePath)), $basePath) === 0 && ($path === $basePath || ($path[strlen($basePath)] ?? '') === '/')) {
	$path = substr($path, strlen($basePath)) ?: '/';
}
$path = rtrim($path, '/') ?: '/';
$router->dispatch($_SERVER['REQUEST_METHOD'] ?? 'GET', $path);
