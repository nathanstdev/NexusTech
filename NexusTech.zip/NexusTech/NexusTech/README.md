# NexusTech ERP + Loja

Aplicação PHP 8.2+ com loja e ERP no mesmo banco MySQL/MariaDB. A loja é pública; toda rota e todo endpoint administrativo verifica o perfil atual no banco, e uma conta `cliente` recebe `403` ao tentar acessá-los. O estoque só muda dentro de transações que também registram o pedido, a compra ou o motivo do ajuste.

## Estrutura

```text
index.php                 Front controller
routes.php                Rotas web e /api/v1
app/                      Controllers, serviços, PDO, middleware e helpers
api/helpers/response.php  Envelope JSON padronizado
admin/gerar_pdf.php       Geração do relatório Dompdf, incluída após RBAC
view/                     Templates PHP da loja, conta, pedidos e ERP
assets/css/               Design system responsivo
assets/js/                Módulos ES para loja, conta, checkout e ERP
database/                 Migrations SQL numeradas e dados do catálogo
tools/                    Migrations e seeds locais
storage/cache/            Cache privado das consultas analíticas
```

## Requisitos

- PHP 8.2 ou superior com `pdo_mysql` e `mbstring` habilitados.
- MySQL 8+ ou MariaDB compatível com InnoDB, JSON e `SELECT ... FOR UPDATE`.
- Composer 2.
- Apache com `mod_rewrite` no XAMPP ou PHP built-in server.

## Instalação com XAMPP

1. Inicie Apache e MySQL pelo painel do XAMPP; confirme que `pdo_mysql` e `mbstring` estão habilitados no `php.ini` usado pelo Apache e pelo CLI.
2. No diretório do projeto, copie `.env.example` para `.env` e ajuste host, porta, banco, usuário e senha. Para este XAMPP, use `DB_PORT=3406`, `DB_DATABASE=nexustech_erp`, `APP_BASE_PATH=/NexusTech` e `APP_URL=http://localhost:8080/NexusTech`; configure também um `WEBHOOK_SECRET` aleatório. Troque as duas senhas de demonstração antes de criar usuários.
3. Instale as dependências: `composer install`.
4. Crie o banco vazio configurado: `php tools/create-database.php`. O script usa `CREATE DATABASE IF NOT EXISTS` e não altera outros bancos.
5. Aplique as migrations: `php tools/migrate.php`.
6. Crie as contas locais de demonstração: `php tools/seed-users.php`.
7. Popule as análises com 30 pedidos distribuídos no último mês: `php tools/seed-demo-orders.php`.
8. Abra `http://localhost:8080/NexusTech/`.

As credenciais locais são as definidas por `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD`, `SEED_CUSTOMER_EMAIL` e `SEED_CUSTOMER_PASSWORD` no `.env`. O script de contas recusa senhas com menos de 12 caracteres e só executa quando `APP_ENV=local`. Não use essas contas/senhas em produção.

## Servidor PHP local

Ajuste `APP_BASE_PATH=` (vazio) e `APP_URL=http://127.0.0.1:8000`, rode `composer serve` e acesse essa URL. O roteador do servidor local publica apenas assets; arquivos internos, migrations e scripts utilitários não são servidos diretamente.

## Fluxos para validar

- Loja: busque por nome/SKU, filtre categoria/preço/disponibilidade, abra um produto, adicione ao carrinho e confirme a persistência ao recarregar.
- Conta cliente: cadastre-se ou entre, atualize perfil/endereço, faça checkout e veja a linha do tempo em **Meus pedidos**.
- Consistência: tente comprar mais unidades que o estoque. A API deve rejeitar sem criar pedido nem movimentação parcial. Cancele pedido pendente e valide a reposição no ERP.
- RBAC: entre como cliente e solicite `/admin` e `/api/v1/admin/dashboard`; deve receber `403` sem dados administrativos. Desative uma conta já conectada e valide que a próxima chamada autenticada encerra a sessão.
- ERP: entre com a conta admin; ajuste estoque com motivo, cadastre produto/fornecedor, receba compra, altere o status do pedido e confira auditoria/histórico.
- Análises: abra o dashboard, teste hoje/7/30/90 dias e datas personalizadas, exporte gráficos PNG, listas CSV e o relatório PDF.
- Checkout/pagamento: Pix, cartão e boleto são simulados. O frete também é simulado (R$ 19,90 ou grátis acima de R$ 500). Pedidos permanecem pendentes até atualização administrativa ou webhook assinado.

O webhook `POST /api/v1/webhooks/pagamento` valida `X-Webhook-Timestamp` e `X-Webhook-Signature`. A assinatura é `HMAC-SHA256(timestamp + "." + corpo JSON, WEBHOOK_SECRET)`; timestamps fora de cinco minutos e `event_id` repetidos são rejeitados/ignorados.

## API principal

- Pública: `GET /api/v1/produtos`, `GET /api/v1/produtos/{id}`, `GET /api/v1/categorias`.
- Sessão: `GET /api/v1/csrf`, `POST /api/v1/auth/register`, `POST /api/v1/auth/login`, `POST /api/v1/auth/logout`, recuperação e redefinição de senha.
- Cliente: `GET/PATCH /api/v1/conta`, `GET/POST/DELETE /api/v1/enderecos`, `GET/POST /api/v1/pedidos`, cancelamento e validação de cupom.
- Administrativa: `/api/v1/admin/*`, sempre limitada a `role=admin` no servidor.

Respostas JSON seguem `success/data/meta` ou `success/error`. Escritas por sessão exigem `X-CSRF-Token`; o cliente ES module busca o token em `/api/v1/csrf`.

## Notas operacionais

- A recuperação envia e-mail pela função `mail()` do PHP. Configure SMTP/sendmail no XAMPP ou substitua o transporte para seu provedor antes de produção.
- Chart.js e a tipografia são carregados de CDNs definidos na Content Security Policy. Para operação sem internet, sirva essas bibliotecas localmente.
- Os pagamentos e o cálculo de frete são deliberadamente simulados; nenhum dado de cartão real é coletado. Integre um gateway real antes de aceitar pagamentos.
- As migrations SQL do MySQL fazem commits implícitos em DDL. Se uma migration falhar, corrija o ambiente e reaplique; os objetos usam `IF NOT EXISTS` e os seeds são idempotentes.
- Antes de publicar, configure HTTPS, `APP_DEBUG=false`, segredos fortes, transporte de e-mail, backups, rotação/limpeza de logs e políticas de retenção. Não use o servidor embutido do PHP em produção.
