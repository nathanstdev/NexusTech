# Diagnóstico inicial — NexusTech

**Escopo:** diagnóstico da Etapa 1 e registro do progresso. As alterações desta etapa não incluem o redesign.

> As observações da seção **Achados** abaixo registram a fotografia inicial da Etapa 1.1. As mudanças posteriores e as pendências atuais estão registradas em **Atualização da Etapa 1**, ao final deste relatório.

## Resumo executivo

O projeto já tem uma aplicação PHP funcional em formato de monólito: `index.php` é o front controller, `routes.php` declara rotas web e `/api/v1`, os controllers e serviços ficam em `app/`, e as telas em `view/`. Há uma base de loja, pedidos, autenticação, cadastro administrativo e relatórios.

Na comparação estática das chamadas feitas pelos módulos JavaScript com as rotas declaradas, não encontrei URLs de API chamadas pela interface sem uma rota correspondente. Isso não comprova disponibilidade em execução: o banco não foi conectado nem as rotas foram exercitadas por HTTP neste diagnóstico.

Os principais itens ainda pendentes são a validação em execução contra MySQL e Apache e a implementação de recursos ainda ausentes do escopo de estoque/loja. Configuração e proteções básicas estão implementadas, mas exigem a validação local antes da publicação.

## Achados

| Prioridade | Problema e evidência | Causa | Correção necessária |
|---|---|---|---|
| Alta | **Scripts de manutenção podem ser invocados por HTTP sob Apache.** O README orienta servir o projeto pelo XAMPP/Apache; não há `.htaccess` no projeto. `tools/migrate.php`, `tools/seed-users.php` e `tools/create-database.php` carregam o bootstrap e executam operações sem exigir `PHP_SAPI === 'cli'`. | O roteador `tools/router.php` restringe arquivos apenas quando se usa o servidor embutido; o Apache não passa por esse roteador. No arranjo documentado, os diretórios `tools/`, `database/`, `app/` e `vendor/` não têm bloqueio definido pelo projeto. | Manter o document root fora do código interno ou negar acesso HTTP a diretórios e arquivos internos; exigir execução CLI nos scripts de manutenção. |
| Alta | **Arquivos potencialmente sensíveis na raiz pública.** [cookies.txt](./cookies.txt) está no document root. O projeto também instrui criar `.env` na raiz, mas não contém regra para negar acesso a arquivos ocultos. | O projeto não traz `.htaccess` nem outra configuração local de negação. `cookies.txt` pode conter material de sessão; seu conteúdo não foi lido nem incluído neste relatório. | Isolar/remover o arquivo se contiver cookies reais e revogar as sessões correspondentes. Colocar `.env` fora do document root ou bloquear acesso HTTP antes de criá-lo. |
| Alta | **Configuração prometida não existe e o padrão de nomes diverge.** O [README.md](./README.md) instrui copiar `.env.example`, mas não há `.env.example`; também não há `.gitignore`. `composer.json` não declara `vlucas/phpdotenv`. [app/bootstrap.php](./app/bootstrap.php#L25) interpreta `.env` com um parser próprio. [app/Database.php](./app/Database.php#L21) lê `DB_DATABASE`, `DB_USERNAME` e `DB_PASSWORD`, enquanto o pedido especifica `DB_NAME`, `DB_USER` e `DB_PASS`. | A documentação, o formato efetivamente lido pela aplicação e a configuração solicitada não estão alinhados. | Adotar uma única convenção de variáveis, introduzir Dotenv conforme solicitado, criar `.env.example` sem segredos e ignorar `.env` no Git. Definir também como carregar e proteger os demais segredos exigidos. |
| Alta | **Migration 003 não é segura para retomada após falha parcial.** [database/003_perfil_avaliacoes.sql](./database/003_perfil_avaliacoes.sql#L1) adiciona colunas com `ALTER TABLE ... ADD COLUMN` sem guarda de existência. [tools/migrate.php](./tools/migrate.php#L28) executa os comandos em sequência e grava a migration como aplicada somente ao final. | DDL no MySQL pode persistir mesmo se uma instrução posterior falhar; uma nova execução pode falhar ao tentar adicionar coluna já criada. | Tornar as migrations repetíveis ou registrar e recuperar cada operação de forma segura; validar a reaplicação após interrupção. |
| Alta | **Não há schema consolidado nem cobertura de testes identificada.** Existe `database/001_...sql` a `003_...sql`, mas não `database/schema.sql`; não foram encontrados arquivos de teste nem script de teste no `composer.json`. | O estado inicial do banco e a regressão das operações dependem de executar migrations manualmente, sem verificação automatizada presente no projeto. | Gerar o schema consolidado e estabelecer testes para migrations, autenticação, RBAC, pedidos e movimentações antes de modificar fluxos. |
| Média | **Não foi possível confirmar a conexão nem o schema em execução.** [app/Database.php](./app/Database.php#L17) fornece conexão PDO singleton, exceções, prepared statements nativos, `utf8mb4` e timeout de cinco segundos. Porém não há `.env` disponível para conexão. | Host, porta, banco e credenciais efetivos não podem ser verificados neste ambiente; o schema do servidor também não foi inspecionado. | Executar `php tools/test-connection.php` com configuração local, sem imprimir segredos; conferir collation, índices e chaves no banco real. |
| Média | **Falha de e-mail pode ser silenciosa.** [app/Services/AuthService.php](./app/Services/AuthService.php#L103) suprime erros de `mail()` com `@`. Se `APP_URL` não estiver configurada, o link de redefinição é montado sem origem absoluta. | Transporte de e-mail é um fallback local sem confirmação de entrega e a configuração não é validada na inicialização. | Usar transporte configurável, registrar falhas sem expor tokens e validar `APP_URL`/remetente no ambiente. |
| Média | **Senha mínima inconsistente.** Cadastro público aceita senha de 10 caracteres em [app/Services/AuthService.php](./app/Services/AuthService.php); seeds e criação administrativa exigem 12. | Regras de validação foram implementadas separadamente. | Unificar a política e aplicar a mesma regra em cadastro, redefinição e administração. |
| Média | **A área de perfil tem partes apenas estruturais.** A migration adiciona `avatar_url` e cria `avaliacoes`, mas não há rotas/serviços para avaliações nem fluxo de upload de foto no código de aplicação. | Há schema sem integração funcional correspondente. | Implementar as rotas, autorização, validação e armazenamento seguro, ou remover/documentar campos ainda não utilizados. |
| Média | **O ERP ainda não modela vários requisitos de estoque.** O schema mantém saldo em `produtos.estoque` e registra movimentos separadamente; não há tabelas de armazéns/locais, lotes/séries, inventário físico ou financeiro. | O modelo atual cobre estoque simples por produto, não o modelo multi-armazém e rastreável solicitado. | Planejar migrations e serviços para esses domínios antes de apresentar os módulos como concluídos. |
| Média | **Pagamento e frete são simulados.** O README confirma que Pix, cartão, boleto e frete não usam gateway real; não há integração de gateway nem geração real de QR code. | A implementação atual cria pedidos pendentes e depende de atualização administrativa ou webhook configurado. | Manter o modo simulado explicitamente em ambiente de desenvolvimento; integrar gateway e reconciliar eventos antes de aceitar pagamentos reais. |
| Média | **Funcionalidades requeridas não encontradas na aplicação.** Não foram localizados endpoints de IA, importação, notificações, leitura de código de barras, backup/restauração, SSE/polling, inventário físico ou transferência entre armazéns. A interface tem algumas exportações CSV e relatório PDF. | São funcionalidades fora do escopo atual do código, não integrações quebradas de endpoints existentes. | Tratar como implementação pendente nas etapas correspondentes, sem considerar a presença de telas ou tabelas parciais como entrega funcional. |

## Integrações e rotas verificadas

- O front controller [index.php](./index.php) carrega `app/bootstrap.php`, registra as rotas e remove o `APP_BASE_PATH` antes do dispatch.
- As rotas web/API estão em [routes.php](./routes.php); a API não está organizada em arquivos sob `api/v1/`, apesar de essa estrutura aparecer na especificação. O diretório `api/` contém apenas o envelope JSON.
- As chamadas `api(...)` encontradas em `assets/js/` correspondem às rotas existentes para catálogo, produtos relacionados, conta, endereços, pedidos, cupons, produtos administrativos, usuários, categorias, fornecedores, compras, estoque e dashboard.
- Não identifiquei `require` interno apontando para um caminho inexistente nas entradas examinadas. A disponibilidade em execução ainda depende de Composer, extensões PHP, Apache/base path e banco configurados.
- O webhook de pagamento tem rota própria e valida assinatura HMAC e timestamp. O processamento não foi testado contra um provedor real.
- `tools/router.php` protege o servidor embutido contra servir arquivos internos diretamente; essa proteção não se aplica automaticamente ao Apache.
- A conexão PDO agora aplica timeout de cinco segundos. O novo [tools/test-connection.php](./tools/test-connection.php) testa `SELECT 1`, retorna uma mensagem sem credenciais e registra o erro detalhado no log.
- O novo [database/schema.sql](./database/schema.sql) consolida as migrations 001–003 e registra esses nomes em `schema_migrations`, para que sua importação não seja seguida por alterações duplicadas ao rodar o migrador.

## O que já existe

- PDO singleton, exceções, prepared statements nativos e charset/collation `utf8mb4`.
- Senhas com Argon2id; regeneração do ID de sessão no login/cadastro; flags `HttpOnly` e `SameSite`; token CSRF nas escritas autenticadas; verificação de perfil nas rotas administrativas.
- Catálogo com busca/filtros, sacola no cliente, checkout simulado, pedidos e cancelamento com reposição de estoque, compras/fornecedores, movimentos e relatórios.
- Migrations numeradas e seeds locais; geração de relatório PDF com Dompdf.

## Validação desta etapa

- **Etapa 1.1 — leitura estática:** concluída para os pontos de entrada, rotas, conexão, autenticação, serviços de pedidos/estoque, migrations, ferramentas e chamadas da interface.
- **Etapa 1.2 — implementação:** timeout de conexão, comando CLI de verificação e schema consolidado adicionados.
- **Etapa 1.2 — validação em execução:** pendente; não há configuração `.env` disponível para validar a conexão nem aplicar migrations em um MySQL real.
- **Etapas 1.3 e 1.4:** pendentes; nenhuma alteração de design foi feita.

## Próximos passos

1. Criar `.env` local e rodar o teste de conexão com MySQL, migrations e smoke tests.
2. Verificar no Apache regras de rewrite, acesso negado a arquivos internos e execução de scripts CLI.
3. Validar o schema consolidado e a recuperação de migrations interrompidas em um MySQL real.
4. Executar testes de conexão, migrations, autenticação/RBAC e operações de estoque antes de avançar para o design.

## Atualização da Etapa 1

### Etapa 1.2 — conexão e schema

- Adicionado timeout de cinco segundos à conexão PDO.
- Adicionado `tools/test-connection.php`: testa `SELECT 1` por CLI; apresenta uma mensagem genérica ao operador e deixa o detalhe no log.
- Consolidado o estado das migrations em `database/schema.sql`, incluindo schema de migrations e registro das migrations 001–003.
- O migrador consulta `information_schema` antes de executar `ALTER TABLE ... ADD COLUMN`; se uma coluna alvo já existir após falha parcial de DDL, pula somente aquela operação.
- Atualizado o README para executar o teste de conexão antes das migrations.
- **Pendente:** executar contra um MySQL local e validar a equivalência do schema em runtime. Não há `.env` nem conexão disponível neste ambiente.

### Etapa 1.3 — configuração

- Criados `.env.example` e `.gitignore`; a configuração de banco foi padronizada para `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` e `DB_PASS`.
- Declarado `vlucas/phpdotenv` em `composer.json` e trocado o parser manual por Dotenv no bootstrap.
- `vlucas/phpdotenv` está declarado em `composer.json` e presente no lockfile, `vendor` e autoload gerado; o bootstrap já resolve a classe.
- As variáveis para SMTP, gateway e IA no arquivo de exemplo são apenas placeholders; os respectivos serviços ainda não foram implementados.
- `APP_KEY` e `SESSION_SECRET` também são placeholders reservados, não usados pelo código atual.

### Etapa 1.4 — segurança básica

- Criado `.htaccess` para roteamento Apache, negação de arquivos ocultos e internos, proteção dos diretórios de ferramentas e despacho de URLs PHP ao front controller. Rotas virtuais `/api/v1` continuam no router; o helper físico em `api/helpers` é bloqueado.
- Scripts de criação de banco, migrations e seeds passaram a exigir execução CLI.
- Cookie de sessão é `Secure` em produção, mantendo `HttpOnly`, `SameSite=Lax` e modo estrito. A rotação de ID já existia no login e no cadastro.
- Cadastro e redefinição passaram a exigir a mesma senha mínima de 12 caracteres já usada nos seeds e na administração.
- Formulários de cadastro e redefinição exibem também a política mínima de 12 caracteres no navegador.
- Falhas de `mail()` deixam de ser suprimidas e são registradas sem colocar o token de redefinição no log. `APP_URL` e `MAIL_FROM` são validados antes de criar um token de recuperação.
- Os endpoints de escrita já exigiam CSRF e as saídas de templates já utilizavam `e()` nas áreas verificadas.
- **Pendente:** validar as regras em Apache com `AllowOverride All`/`mod_rewrite`, rodar testes de autenticação e CSRF, e implementar upload seguro junto com o fluxo de imagem (atualmente inexistente).

### Validação realizada após as mudanças

- `vlucas/phpdotenv` está presente no `composer.lock`, `vendor` e autoload gerado do Composer; o diagnóstico de classe desconhecida foi resolvido sem precisar alterar o lockfile.
- O PHP Language Server não apontou problemas nas alterações de `PageController`, `view/account.php`, `tools/migrate.php`, `tools/test-connection.php`, `tools/create-database.php`, `tools/seed-users.php` e `app/bootstrap.php`. Em `routes.php` e `OrderController`, restam apenas alertas de código inalcançável ou otimização para funções globais.
- `php -l` passou para os arquivos PHP alterados, incluindo controllers, middleware, serviços, rotas, views e ferramentas CLI.
- Persistem alertas informativos de otimização para chamadas de funções globais e trechos de código inalcançáveis já existentes.
- **Não executados:** conexão MySQL, migrations e testes HTTP funcionais. A URL local `http://localhost/NexusTech/` retornou 404; portanto, o comportamento da aplicação e as regras Apache permanecem sem validação.
- Naquele ponto do histórico, o design ainda não tinha sido alterado; o início da Etapa 3 está registrado abaixo.

### Etapa 2 — autorização e perfis (ajuste realizado)

- Administradores autenticados podiam entrar no painel e acessar APIs administrativas, mas eram barrados nas telas e APIs de conta/endereço, checkout e criação de pedido, que exigiam estritamente o perfil `cliente`.
- As páginas de conta, pedidos e checkout e os endpoints de conta, endereços, validação de cupom e criação de pedido agora aceitam qualquer sessão autenticada. Os dados pessoais e endereços continuam vinculados ao ID do usuário autenticado. A listagem administrativa de pedidos continua retornando o conjunto necessário ao painel.
- A tela de conta mostra um link para o painel admin quando `role=admin`.
- Alterações administrativas de status de fornecedor agora registram ação, operador, entidade, estado e horário no log de auditoria dentro da mesma transação da alteração.
- A migration `004_auth_version.sql` adiciona uma versão de autenticação por usuário. Sessões autenticadas guardam a versão obtida no login e o middleware compara com o banco; redefinir a senha incrementa a versão e invalida todas as sessões existentes no próximo request. A redefinição também invalida os outros links de recuperação ainda pendentes.
- Se a entrega do e-mail falhar, o token de redefinição recém-criado é removido do banco, evitando armazenar um link que não foi enviado.
- Clientes continuam sem autorização administrativa: guards `AuthMiddleware::user('admin')` não foram relaxados.
- **Pendente:** validar os dois perfis com sessões reais e banco; recuperação de senha ainda depende de transporte de e-mail configurado; upload de avatar ainda não foi implementado. Avaliações foram integradas na Etapa 4.

### Etapa 3 — sistema visual (em andamento)

- Criado `assets/css/tokens.css` para centralizar cores, tipografia, espaçamento, raios, blur e foco nos temas escuro e claro.
- Criado `assets/css/glass.css` para aplicar superfícies com efeito glass quando o navegador suporta `backdrop-filter`, mantendo fundo sólido como fallback.
- O estilo compartilhado estabelece estados de foco visíveis e respeita `prefers-reduced-motion`; os painéis de loja, autenticação e ERP passam a usar a mesma base visual.
- Os tokens também são importados por `app.css`, para que suas regras funcionem em páginas que carregam essa folha junto do estilo principal.
- A navegação da loja mostra o acesso ao ERP somente para sessão administrativa; o painel ganhou navegação responsiva para seus módulos e alvos de seção com margem para o cabeçalho fixo.
- O storefront foi carregado no navegador local e verificado em desktop e mobile sem overflow horizontal. Páginas autenticadas e painel admin ainda precisam de sessão/banco funcional para validação de ponta a ponta.
- A página de produto agora tem avaliações públicas e formulário de envio. O endpoint só aceita avaliação de usuário autenticado que tenha pedido entregue contendo o produto; a restrição de uma avaliação por cliente/produto é garantida pela chave única do schema.
- O checkout agora separa endereço, pagamento e revisão em etapas acessíveis, atualiza os dados dos produtos pela API antes de habilitar a confirmação e mantém pagamentos explicitamente simulados.
- **Pendente:** exercitar as rotas de avaliações e o checkout com MySQL, e validar visualmente o painel admin em sessão autenticada.

### Etapas 4–8 — implementação e limites de ambiente

- Catálogo, carrinho persistente, detalhes/galeria e avaliações estão integrados à API existente; o checkout possui fluxo em etapas, sem coletar dados de cartão.
- A migration 006 acrescenta 45 produtos fictícios ao catálogo-base de cinco produtos, novas categorias e três avaliações demonstrativas por produto. As avaliações de exemplo são identificadas no card e no detalhe e não são misturadas com avaliações reais sem identificação.
- Os cards continuam carregados dinamicamente pela API; agora exibem trecho da descrição, avaliação agregada e atalho para a biografia completa. A consulta também informa quantas notas são de demonstração e quantas vieram de clientes.
- O ERP inclui armazéns e saldos por local, lotes/séries, transferências, inventário físico, contas financeiras, recebimentos e venda/cancelamento integrados ao estoque. A interface administrativa conecta os formulários, filtros, exportação CSV e atualizações desses módulos. A migration 005 também concilia saldos e pedidos/compras existentes.
- Movimentos de recebimento, venda, ajuste, inventário e transferência agora podem ser consultados/exportados com o armazém e o lote/série correspondente, quando aplicável.
- Os insights novos são regras operacionais determinísticas e explicáveis; não são IA generativa. Backup/restauração, gateway de pagamento, frete real, e-mail transacional configurado e inferência de IA continuam dependentes de implementação/provedor e não devem ser considerados entregues.
- Pagamento real, frete real, e-mail configurado e inferência de IA não são ativados por placeholders. Precisam de credenciais, provedor escolhido e validação de integração antes de uso real.
- A conexão (`php tools/test-connection.php`) continua bloqueada: `DB_NAME` não está configurado no `.env`. Portanto, migrations 005/006, APIs e fluxos completos da loja/ERP ainda não foram exercitados contra MySQL.
- Nesta continuação, as alterações recentes de PHP e JavaScript passaram pelas verificações de sintaxe. O storefront retorna HTTP 200; as APIs de catálogo não puderam ser avaliadas funcionalmente sem banco.
- Locks de armazém serializam abertura/conclusão de inventário com compras, ajustes, vendas e transferências; a migração de recebíveis inclui pedidos pendentes existentes. Essas alterações de concorrência e SQL precisam de validação funcional em MySQL, indisponível neste ambiente.
- A verificação anterior no navegador confirmou que a loja não excede a largura da viewport em 390px e 1280px e que o menu recolhe/expande nos breakpoints; o painel autenticado segue sem validação visual funcional até configurar banco/sessão.
- As folhas CSS compartilhadas respondem HTTP 200; não foram observados erros de carregamento CSS. Os HTTP 500 observados são das APIs dependentes do banco, não de assets.
